/*
 * Created on Apr 4, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package nz.ac.vuw.mcs.comp301.controller;

/**
 * @author harrisdavi3
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class CommandBuyGoods extends Command {
	
	int _amount;
	
	public CommandBuyGoods(int amount) {
		this._amount = amount;
	}

	/* (non-Javadoc)
	 * @see nz.ac.vuw.mcs.comp301.controller.Command#execute()
	 */
	public void execute() {
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see nz.ac.vuw.mcs.comp301.controller.Command#addSubCommand(nz.ac.vuw.mcs.comp301.controller.Command)
	 */
	public void addSubCommand(Command subCommand) {
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see nz.ac.vuw.mcs.comp301.controller.Command#removeSubCommand(nz.ac.vuw.mcs.comp301.controller.Command)
	 */
	public void removeSubCommand(Command subCommand) {
		// TODO Auto-generated method stub

	}

}
