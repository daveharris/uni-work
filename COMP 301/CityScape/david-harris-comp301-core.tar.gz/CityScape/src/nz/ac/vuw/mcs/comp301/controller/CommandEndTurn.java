/*
 * Created on Apr 4, 2005
 *
 */
package nz.ac.vuw.mcs.comp301.controller;

import nz.ac.vuw.mcs.comp301.model.CityState;
import nz.ac.vuw.mcs.comp301.model.ModelData;
import nz.ac.vuw.mcs.comp301.model.events.GameStateEvent;
import nz.ac.vuw.mcs.comp301.view.gui.GUIController;

/**
 * Calculates the endturn figures, and checks to see if
 * the player has won or lost
 * @author harrisdavi3
 * @see nz.ac.vuw.mcs.comp301.model.ModelData
 */
public class CommandEndTurn extends Command {
	
	public CommandEndTurn() {
		
	}

	/**
	 * Calculates the various figures
	 */
	public void execute() {
		
		ModelData.calculateEffiency();
		ModelData.calculateIncome();
		ModelData.calculateHealth();
		ModelData.calculateHappiness();
		CityState.update();		
		
		if(ModelData.getBalance() < -1000 || ModelData.getHappiness() < -90) {
			GameStateEvent gameEvent = new GameStateEvent(GameStateEvent.LOST, GUIController.getPlayerName());
			CityScapePlay.getListeners().notifyGameListeners(gameEvent);
		}
		else if(ModelData.getBalance() > 10000 || ModelData.getHappiness() > 90) {
			GameStateEvent gameEvent = new GameStateEvent(GameStateEvent.WON, GUIController.getPlayerName());
			CityScapePlay.getListeners().notifyGameListeners(gameEvent);
		}
	}


	public void addSubCommand(Command subCommand) {

	}


	public void removeSubCommand(Command subCommand) {

	}

}
