/*
This file is part of the SMSCS VUW Comp301 CityScape GUI library.

SMSCS VUW Comp301 CityScape GUI ibrary is free software; you can redistribute it
and/or modify it under the terms of version 2 of the GNU General Public License as
published by the Free Software Foundation.

The SMSCS VUW Comp301 CityScape GUI library is distributed in the hope that it will 
be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General
Public License for more details.

You should have received a copy of the GNU General Public License along with
SMSCS VUW Comp301 CityScape GUI library; if not, write to the Free Software Foundation,
Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
*/


package nz.ac.vuw.mcs.comp301.view.gui.events;

/**
 * <p>
 * Represents a UI request from the player that something be bought or sold.  
 * </p>
 *
 * @version $Revision: 1.1 $
 * @author $Author: harrisdavi3 $, $Date: 2005/04/04 03:41:58 $
 * @see nz.ac.vuw.mcs.comp301.view.gui.MarketView 
 */
public class TradeEvent {

	/**
	 * Constant identifier for the object's target.
	 */
	public static final int FOOD = 1;
	
	/**
	 * Constant identifier for the object's target.
	 */
	public static final int GOODS = 2;
	
	/**
	 * Constant identifier for the object's action.
	 */
	public static final int SELL = 3;
	
	/**
	 * Constant identifier for the object's action.
	 */
	public static final int BUY = 4;
	
	/**
	 * <p>
	 * Represents a request to perform an action on an amount of the target item.
	 * </p>
	 * 
	 * @param amount The amount of the item to buy or sell.
	 * @param action Identifies if this trade is a buy or a sell.
	 * @param target The item that is to be traded for money.
	 */
	public TradeEvent(int amount, int action, int target) {
		this._target = target;
		this._amount = amount;
		this._action = action;
		return;
	}
	
	/**
	 * @return The amount of the item that is to be traded.
	 */
	public int getAmount() {
		return this._amount;
	}
	
	/**
	 * @return Whether the item is to be bought or sold. Should be either the BUY or SELL constants above.
	 */
	public int getAction() {
		return this._action;
	}
	
	/**
	 * @return The name of the item to be traded. Should be either the FOOD or GOODS constants above.
	 */
	public int getTarget() {
		return this._target;
	}
	
	private int _amount;
	private int _target;
	private int _action;
	
}
