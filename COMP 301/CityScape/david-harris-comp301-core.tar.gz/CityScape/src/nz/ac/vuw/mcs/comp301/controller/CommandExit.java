/*
 * Created on Apr 4, 2005
 */
package nz.ac.vuw.mcs.comp301.controller;

/**
 * Class not needed, but kept for consistency
 * @author harrisdavi3
 * @see  nz.ac.vuw.mcs.comp301.view.gui.GUIController
 */
public class CommandExit extends Command {
	
	public CommandExit() {
		
	}

	/* (non-Javadoc)
	 * @see nz.ac.vuw.mcs.comp301.controller.Command#execute()
	 */
	public void execute() {

	}

	/* (non-Javadoc)
	 * @see nz.ac.vuw.mcs.comp301.controller.Command#addSubCommand(nz.ac.vuw.mcs.comp301.controller.Command)
	 */
	public void addSubCommand(Command subCommand) {
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see nz.ac.vuw.mcs.comp301.controller.Command#removeSubCommand(nz.ac.vuw.mcs.comp301.controller.Command)
	 */
	public void removeSubCommand(Command subCommand) {
		// TODO Auto-generated method stub

	}

}
