/*
 * Created on Apr 4, 2005

 */
package nz.ac.vuw.mcs.comp301.controller;

/**
 * Un-implemented
 * @author harrisdavi3
 */
public class CommandSellGoods extends Command {
	
	int _amount;
	
	public CommandSellGoods(int amount) {
		this._amount = amount;
	}


	public void execute() {

	}


	public void addSubCommand(Command subCommand) {

	}


	public void removeSubCommand(Command subCommand) {

	}

}
