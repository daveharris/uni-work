/*
 * Created on Apr 29, 2005
 */
package nz.ac.vuw.mcs.comp301.model.development;

import java.util.HashMap;

import nz.ac.vuw.mcs.comp301.model.CityState;
import nz.ac.vuw.mcs.comp301.model.ModelData;


/**
 * Creates the actual developments and adds then to the hashmap
 * Deals with everything to do with developments being added to the map.
 * @author harrisdavi3
 */
public class DevelopmentFactory {
	
	static Development _development = null;
	private static HashMap _developmentsMap = new HashMap();
	static int level = 1;
	
	/**
	 * Works out what type of development is wanting to be built,
	 * and then checks if its in the hasmap, or needs to be upgraded
	 * and then notifies the listeners 
	 * @param developmentName The name of the new development being built
	 * @return Returns the new Development
	 */
	public static Development store(String developmentName) {
		
		//If development was not found in the map already, create a new one, and add to map
		if (!_developmentsMap.containsKey(developmentName)) {
			level = Integer.parseInt(developmentName.substring(developmentName.length()-1));
			if(developmentName.startsWith("factory")) {
				_development = new IndustrialDevelopment(developmentName, level);
				_developmentsMap.put(developmentName, _development);
				_development.incrementCounter();
				update(_development, level);
				return _development;
			}
			else if (developmentName.startsWith("farm")) {
				_development = new AgriculturalDevelopment(developmentName, level);
				_developmentsMap.put(developmentName, _development);
				_development.incrementCounter();
				update(_development, level);
				return _development;
			}
			else if (developmentName.startsWith("houses")) {
				_development = new ResidentialDevelopment(developmentName, level);
				_developmentsMap.put(developmentName, _development);
				_development.incrementCounter();
				ModelData.calculateLivingSpaces(_development);
				update(_development, level);
				return _development;
			}
			else if (developmentName.startsWith("park")) {
				_development = new RecreationalDevelopment(developmentName, level);
				_developmentsMap.put(developmentName, _development);
				_development.incrementCounter();
				update(_development, level);
				return _development;
			}
			else if (developmentName.startsWith("townhall")) {
				_development = new GovernmentDevelopment(developmentName, level);
				_developmentsMap.put(developmentName, _development);
				_development.incrementCounter();
				update(_development, level);
				return _development;
			}
		}
		else if (developmentName.equals("empty")) {
			_development = new EmptyDevelopment(developmentName, level);
			_developmentsMap.put(developmentName, _development);
			return _development;
		}
		//If development was found in the map already, retrieve and link to the current one.
		else {
			level = Integer.parseInt(developmentName.substring(developmentName.length()-1));
			_development = (Development) _developmentsMap.get(developmentName);
			update(_development, level);
			return _development;
		}		
		return null;
	}
	
	/**
	 * Updates the storeGoods, upkeep and jobs after the addition of the new development
	 * @param development The newly created development
	 * @param level The level of the new development
	 */	
	private static void update(Development development, int level) {
		double randomNum = 1;
		if(ModelData.randomMode()) {
			randomNum = ModelData.randomNumGenerator(30);
		}
		
		ModelData.setStoreGoods((int) (ModelData.getStoreGoods() - ((development.getCost(level))*randomNum)));
		ModelData.setUpkeep((int) (ModelData.getUpkeep() + ((development.getUpkeep(level))*randomNum)));
		ModelData.setJobs((int) (ModelData.getJobs() + ((development.getJobs(level))*randomNum)));
		
		CityState.update();		
	}
	
}
