/*
This file is part of the SMSCS VUW Comp301 CityScape GUI library.

SMSCS VUW Comp301 CityScape GUI ibrary is free software; you can redistribute it
and/or modify it under the terms of version 2 of the GNU General Public License as
published by the Free Software Foundation.

The SMSCS VUW Comp301 CityScape GUI library is distributed in the hope that it will 
be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General
Public License for more details.

You should have received a copy of the GNU General Public License along with
SMSCS VUW Comp301 CityScape GUI library; if not, write to the Free Software Foundation,
Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
*/

package nz.ac.vuw.mcs.comp301.view.gui;

import javax.swing.JSlider;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;

import nz.ac.vuw.mcs.comp301.controller.Command;
import nz.ac.vuw.mcs.comp301.controller.CommandFactory;
import nz.ac.vuw.mcs.comp301.controller.CommandInterpreter;
import nz.ac.vuw.mcs.comp301.view.gui.events.MapListener;
import nz.ac.vuw.mcs.comp301.view.gui.events.MapEvent;
import nz.ac.vuw.mcs.comp301.view.gui.events.FilterListener;
import nz.ac.vuw.mcs.comp301.view.gui.events.FilterEvent;
import nz.ac.vuw.mcs.comp301.view.gui.events.SelectionListener;
import nz.ac.vuw.mcs.comp301.view.gui.events.SelectionEvent;
import nz.ac.vuw.mcs.comp301.view.gui.events.TradeListener;
import nz.ac.vuw.mcs.comp301.view.gui.events.TradeEvent;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.BufferedReader;

import javax.swing.event.ChangeListener;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.event.ChangeEvent;


/**
 * <p>This object reacts to player interaction and ensures that the appropriate 
 * action is initiated. The GUIController implements a variety of listener interfaces, so that 
 * it can be registered to other parts of the interface and be informed when the player selects or 
 * manipulates controls.</p>
 *
 * @version $Revision: 1.7 $
 * @author $Author: harrisdavi3 $, $Date: 2005/05/05 12:33:34 $
 * @see nz.ac.vuw.mcs.comp301.view.gui.MapView
 * @see nz.ac.vuw.mcs.comp301.controller.CommandInterpreter
 * @see nz.ac.vuw.mcs.comp301.controller.CommandFactory
 * @see nz.ac.vuw.mcs.comp301.controller.Command
 */
public class GUIController implements ActionListener, FilterListener, ChangeListener, SelectionListener, MapListener, TradeListener {

	/**
	 * <p>
	 * Constructs an instance of the GUIController.
	 * </p>
	 * 
	 * @param view The interface component that displays the city's map.
	 * @param interpreter An object that can Command objects and ensure that they are used correctly.
	 * @param factory An object that can create new Command objects to encapsulate the player's instructions.
	 */
	public GUIController(MapView view, CommandInterpreter interpreter, CommandFactory factory) {
		this._interpreter = interpreter;
		this._factory = factory;
		this._view = view;
		_playerName = null;
		return;
	}
	
	
	/**
	 * <p>
	 * React to a trade request from the player. Identifies the type of request, constructs the relevant 
	 * command, and passes this command to the interpreter for handling.
	 * </p>
	 * 
	 * @see nz.ac.vuw.mcs.comp301.view.gui.events.TradeListener#tradeRequested(nz.ac.vuw.mcs.comp301.view.gui.events.TradeEvent)
	 */
	public void tradeRequested(TradeEvent event) {
		int target = event.getTarget();
		int amount = event.getAmount();
		int action = event.getAction();
		Command command = null;
		if (target == TradeEvent.GOODS) {
			if (action == TradeEvent.BUY) {
				command = this._factory.createBuyGoodsCommand(amount);
			} else if (action == TradeEvent.SELL) {
				command = this._factory.createSellGoodsCommand(amount);
			} 
		} else if (target == TradeEvent.FOOD) {
			if (action == TradeEvent.BUY) {
				command = this._factory.createBuyFoodCommand(amount);
			} else if (action == TradeEvent.SELL) {
				command = this._factory.createSellFoodCommand(amount);
			}	
		}
		
		if (command != null) {
			int result = JOptionPane.showConfirmDialog(null, "Confirm Trade", "Market", JOptionPane.YES_NO_OPTION);
			if (result == JOptionPane.YES_OPTION) {
				this._interpreter.executeCommand(command);
			}
		}
		return;
	}
	
	/** 
	 * <p>React to the player's request that the pollution or social wh filters be modified.</p>
	 * <p>Identifies the filter to be modified, and the action to be taken, and calls the relevant 
	 * method on the MapView object.</p>
	 * 
	 * @param event An object representing the player's filter change request.
	 * @see nz.ac.vuw.mcs.comp301.view.gui.events.FilterListener#filterModified(nz.ac.vuw.mcs.comp301.view.gui.events.FilterEvent)
	 */
	public void filterModified(FilterEvent event) {
		int action = event.getAction();
		int filter = event.getType();
		if (action == FilterEvent.HIDE) {
			if (filter == FilterEvent.POLLUTION) {
				this._view.showPollution(false);				
			} else if (filter == FilterEvent.SOCIAL_WORTH) {
				this._view.showSocialWorth(false);
			}
		} else if (action == FilterEvent.SHOW) {
			if (filter == FilterEvent.POLLUTION) {
				this._view.showPollution(true);
			} else if (filter == FilterEvent.SOCIAL_WORTH) {
				this._view.showSocialWorth(true);				
			}			
		}
		return;
	}
	
	/** 
	 * <p>
	 * Records the player's new selection in the list of available developments. 
	 * </p>
	 * 
	 * @param event An object representing the player's new development selection.
	 * @see nz.ac.vuw.mcs.comp301.view.gui.events.SelectionListener#selectionMade(nz.ac.vuw.mcs.comp301.view.gui.events.SelectionEvent)
	 */
	public void selectionMade(SelectionEvent event) {
		this._currentSelection = event.getName();
		return;
	}
	
	/**
	 * <p>
	 * Reacts to a player clicking on the map by asking if they want to build a new 
	 * instance of the currently selected development on that land node. 
	 * </p>
	 * <p>
	 * If the player confirms the build request, then the relevant Command object is created and 
	 * handed over to the CommandInterpreter.  
	 * </p>
	 * 
	 * @param event An object representing the location where the player clicked on the map.
	 * @see nz.ac.vuw.mcs.comp301.view.gui.events.MapListener#mapClicked(nz.ac.vuw.mcs.comp301.view.gui.events.MapEvent)
	 */
	public void mapClicked(MapEvent event) {
		if (this._currentSelection != null) {
			int x = event.getX();
			int y = event.getY();
			int result = JOptionPane.showConfirmDialog(null, "Build " + this._currentSelection + " at " + x + ":" + y + "?", "Development", JOptionPane.YES_NO_OPTION);
			if (result == JOptionPane.YES_OPTION) {
				Command command = this._factory.createBuildCommand(event.getX(), event.getY(), this._currentSelection);
				this._interpreter.executeCommand(command);
			}
		}
	}
	
	/**
	 * <p>
	 * Reacts to a player modifying the tax rate slider by building the relevant Command and 
	 * passing that Command to the CommandInterpreter.
	 * </p>
	 * 
	 * @param event 
	 * @see javax.swing.event.ChangeListener#stateChanged(javax.swing.event.ChangeEvent)
	 */
	public void stateChanged(ChangeEvent event) {
		JSlider slider = (JSlider)event.getSource();
		int taxRate = slider.getValue();
		Command command = this._factory.createTaxCommand(taxRate);
		this._interpreter.executeCommand(command);
		return;
	}
	
	
	/**
	 * <p>
	 * React to various requests that the player can make through the menu system.
	 * </p>
	 * <p>
	 * If the player has requested to end the game, then the System.exit() method is 
	 * invoked to clean up the virtual machine.
	 * </p>
	 * 
	 * @param event An object representing a player's interaction - typically through the menu system.
	 * @see java.awt.event.ActionListener#actionPerformed(java.awt.event.ActionEvent)
	 */
	public void actionPerformed(ActionEvent event) {
		Object obj = event.getSource();
		String action = event.getActionCommand();
		if (action.equals("end game")) {
			this.handleExit();
			System.exit(0);
		} else if (action.equals("start game")) {
			this.handleStart();
		} else if (action.equals("end turn")) {
			this.handleEndTurn();
		} else if (action.equals("replay")) {
			this.handleReplay();
		} else if (action.equals("undo")) {
			this.handleUndo();
		} 
		return;
	}
	
	
	/**
	 * @return The name of the player interacting with this user interface.
	 */
	public static String getPlayerName() {
		return _playerName;
	}
	
	/**
	 * <p>
	 * End the player's current turn by creating the relevant Command object and passing it
	 * to the CommandInterpeter.
	 * </p> 
	 */
	private void handleEndTurn() {
		Command command = this._factory.createEndTurnCommand();
		this._interpreter.executeCommand(command);
		return;
	}
	
	/**
	 * <p>
	 * Asks the player for the name of the file that contains the sequence of commands to be replayed.
	 * A new Command is then created that includes all of the instructions in this file, and the 
	 * Command is passed to the CommandInterpreter.
	 * </p> 
	 */
	private void handleReplay() {
		JFileChooser chooser = new JFileChooser();
		int result = chooser.showOpenDialog(null);
		if (result == JFileChooser.APPROVE_OPTION) {
			try {
				File selectedFile = chooser.getSelectedFile();
				BufferedReader reader = new BufferedReader(new FileReader(selectedFile));
				Command command = this._factory.createReplayCommand(reader);
				this._interpreter.executeCommand(command);
			} catch (FileNotFoundException exception) {
				exception.printStackTrace();
				return;
			}
		}
		return;
	}
	
	/**
	 * <p>
	 * Handles the player exiting the current game by creating the relevant Command
	 * object and passing it to the CommandInterpreter.
	 * </p> 
	 */
	private void handleExit() {
		Command command = this._factory.createExitCommand();
		this._interpreter.executeCommand(command);
		return;
	}
	
	/**
	 * <p>
	 * Checks if the player is already playing. If they are, then the player is asked if they 
	 * want to finish the current game. If so, the player's current city is destroyed by temporarily exiting the game. 
	 * </p>
	 * <p>
	 * The player is then asked for a name, and is also asked to supply the name of a file that 
	 * contains the map for the new city. The relevant Command object is then created, and passed
	 * to the CommandInterpreter.
	 * </p>
	 */
	private void handleStart() {
		int result = JOptionPane.showConfirmDialog(null, "Start a New Game?", "Confirm", JOptionPane.YES_NO_OPTION);
		if (result == JOptionPane.YES_OPTION) {
			if (_playerName != null) {
				this.handleExit();
			} 
			_playerName = JOptionPane.showInputDialog("Enter name:");
			JFileChooser chooser = new JFileChooser();
			result = chooser.showOpenDialog(null);
			if (result == JFileChooser.APPROVE_OPTION) {
				String mapName = chooser.getSelectedFile().getPath();
				//String mapName = System.getProperty("user.dir") + "/map.txt";
				Command command = this._factory.createStartCommand(_playerName, mapName);
				this._interpreter.executeCommand(command);
			}
		}
	}
	
	/**
	 * <p>
	 * Handles the player's request to undo the last command by creating the relevant Command 
	 * object and passing it to the CommandInterpreter.
	 * </p> 
	 */
	private void handleUndo() {
		Command command = this._factory.createUndoCommand();
		this._interpreter.executeCommand(command);
		return;
	}
	
	private String _currentSelection;
	private CommandFactory _factory;
	private CommandInterpreter _interpreter;
	private MapView _view;
	private static String _playerName;
	
}
