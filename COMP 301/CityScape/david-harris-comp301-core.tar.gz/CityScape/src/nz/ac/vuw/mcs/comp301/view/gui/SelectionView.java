/*
This file is part of the SMSCS VUW Comp301 CityScape GUI library.

SMSCS VUW Comp301 CityScape GUI ibrary is free software; you can redistribute it
and/or modify it under the terms of version 2 of the GNU General Public License as
published by the Free Software Foundation.

The SMSCS VUW Comp301 CityScape GUI library is distributed in the hope that it will 
be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General
Public License for more details.

You should have received a copy of the GNU General Public License along with
SMSCS VUW Comp301 CityScape GUI library; if not, write to the Free Software Foundation,
Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
*/

package nz.ac.vuw.mcs.comp301.view.gui;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Paint;
import java.awt.Graphics2D;
import java.awt.Graphics;
import java.awt.Dimension;
import java.awt.Rectangle;

import nz.ac.vuw.mcs.comp301.view.gui.events.SelectionEvent;
import nz.ac.vuw.mcs.comp301.view.gui.events.SelectionListener;

import javax.swing.JPanel;
import javax.swing.JButton;
import javax.swing.Scrollable;

import nz.ac.vuw.mcs.comp301.model.events.KnowledgeListener;
import nz.ac.vuw.mcs.comp301.model.events.KnowledgeEvent;

import java.util.Hashtable;
import java.util.List;
import java.util.Iterator;
import java.util.Vector;

/**
 * <p>This view displays the list of developments that the player is currently allowed 
 * to build. Implements the KnowledgeListener interface so that it can be told of changes to the 
 * developments that the player knows about.</p>
 * 
 * <p>
 * This view displays the list of available developments as a vertical sequence of buttons. These buttons can 
 * be pressed to select the current development for building. The view is scrollable, in cases where 
 * the number of developments exceeds the screen size.
 * </p>
 * 
 * <p>
 * This view does not maintain state that documents what development has currently been selected. Instead, 
 * this view will notify all registed SelectionListeners when a selection is made. They are then responsible 
 * for updating the current selection state.
 * </p>
 * 
 * @version $Revision: 1.2 $
 * @author $Author: harrisdavi3 $, $Date: 2005/05/05 09:31:05 $
 * @see nz.ac.vuw.mcs.comp301.model.events.KnowledgeListener
 */
public class SelectionView extends JPanel implements KnowledgeListener, ActionListener, Scrollable {

	public static final long serialVersionUID = 1;
	
	public SelectionView(GUIController controller) {
		super();
		this._controller = controller;
		this._developments = new Hashtable();
		this._listeners = new Vector();
		this.setLayout(new GridBagLayout());
		this.setVisible(true);
		return;
	}
	
	public Dimension getPreferredScrollableViewportSize() {
		return new Dimension(100, 400);
	}

	public int getScrollableUnitIncrement(Rectangle visibleRect,
			int orientation, int direction) {
		return 100;
	}

	public int getScrollableBlockIncrement(Rectangle visibleRect,
			int orientation, int direction) {
		return 100;
	}

	public boolean getScrollableTracksViewportWidth() {
		return false;
	}

	public boolean getScrollableTracksViewportHeight() {
		return false;
	}

	/* 
	 * 
	 * @param event An object representing the player clicking on one of the buttons in the selection view.
	 * @see java.awt.event.ActionListener#actionPerformed(java.awt.event.ActionEvent)
	 */
	public void actionPerformed(ActionEvent event) {
		JButton button = (JButton)event.getSource();
		String name = button.getName();
		SelectionEvent selEvent = new SelectionEvent(name);
		this.notifySelectionListeners(selEvent);
		return;
	}
	
	public void addSelectionListener(SelectionListener listener) {
		this._listeners.add(listener);
		return;
	}
	
	/* 
	 * <p>
	 * Add or remove a development from the displayed list as the player's knowledge changes.
	 * </p>
	 * 
	 * @param event An object representing a single change to the player's development knowledge.
	 * @see nz.ac.vuw.mcs.comp301.model.events.KnowledgeListener#knowledgeModified(nz.ac.vuw.mcs.comp301.model.events.KnowledgeEvent)
	 */
	public void knowledgeModified(KnowledgeEvent event) {
		int eventType = event.getType();
		String development = event.getDevelopment();
		switch (eventType) {
			case KnowledgeEvent.ADD:
				this.addSelectionOption(event.getDevelopment());
				break;
			case KnowledgeEvent.REMOVE:
				this.removeSelectionOption(event.getDevelopment());
				break;
		}
		
		return;
	}
	
	/**
	 * <p>
	 * Adds a new development option to the screen. Creates a ButtonPanel 
         * with a JButton that has the development's name as the text, and
	 * and then adds it to the end of the list. The ButtonPanel is created
	 * so that we can use Paint objects to set the background.
	 * </p>
	 * 
	 * @param name The name of the development that is being added to the displayed list.
	 */
	private void addSelectionOption(String name) {
		Paint paint = GUIUtilities.getGUIUtilities().getPaint(name);
		JPanel buttonPanel = new ButtonPanel(paint);
		JButton button = new JButton();
		button.setName(name);
		button.setText(name);
		button.setContentAreaFilled(false);
		button.setPreferredSize(new Dimension(100, 100));
		button.addActionListener(this);
		
		GridBagLayout layout = (GridBagLayout)this.getLayout();
		GridBagConstraints constraints = new GridBagConstraints();
		
		constraints.fill = GridBagConstraints.BOTH;
		constraints.gridwidth = GridBagConstraints.REMAINDER;
		constraints.weightx = 1.0;
		constraints.weighty = 1.0;
		layout.setConstraints(buttonPanel, constraints);
		this.add(buttonPanel);
		
		buttonPanel.setLayout(new GridLayout(1, 1));
		buttonPanel.add(button);
		buttonPanel.setVisible(true);
		
		this._developments.put(name, buttonPanel);
		this.revalidate();
		return;	
	}
	
	/**
	 * <p>
	 * Removes a development option from the screen. The button is removed from the interface, and 
	 * the SelectionListeners are told of a null event. This may be used to trigger them to clear the 
	 * current selected development state.
	 * </p>
	 * 
	 * @param name The name of the development to remove from the screen.
	 */
	private void removeSelectionOption(String name) {
		JPanel panel = (JPanel)this._developments.get(name);
		GridBagLayout layout = (GridBagLayout)this.getLayout();
		this._developments.remove(name);
		this.remove(panel);
		layout.removeLayoutComponent(panel);
		this.notifySelectionListeners(new SelectionEvent(null));
		this.revalidate();
		return;
	}
	
	private void notifySelectionListeners(SelectionEvent event) {
		Iterator listeners = this._listeners.iterator();
		while (listeners.hasNext()) {
			SelectionListener listener = (SelectionListener)listeners.next();
			listener.selectionMade(event);
		}
		return;
	}
	
	private GUIController _controller;
	private Hashtable _developments;
	private List _listeners; 
	
}

/**
 *  <p>
 *  A panel that uses a Paint object to fill in the background before 
 * deferring painting to any components contained within. This is used as a 
 * means of drawing buttons using Paint objects, since ordinarily you can 
 * only use Color objects. A bit messy, and not hugely efficient, but gets
 * the job done.
 *  </p>
 */
class ButtonPanel extends JPanel {
	
	public static final long serialVersionUID = 1;
	
	ButtonPanel(Paint paint) {
		super();
		this._paint = paint;
		this.setOpaque(true);
		return;
	}

	public void paint(Graphics graphics) {
		Graphics2D graphics2D = (Graphics2D)graphics;
		graphics2D.setPaint(this._paint);
		graphics2D.fillRect(0, 0, this.getWidth(), this.getHeight());
		super.paintChildren(graphics);
		return;
	}
	
	private Paint _paint;
	
}
