/*
 * Created on Apr 4, 2005
 */
package nz.ac.vuw.mcs.comp301.controller;

import nz.ac.vuw.mcs.comp301.model.ModelData;
import nz.ac.vuw.mcs.comp301.model.development.*;
import nz.ac.vuw.mcs.comp301.model.events.DevelopmentEvent;
import nz.ac.vuw.mcs.comp301.model.events.KnowledgeEvent;


/**
 * This class sets up the information to be passed to other classes to create
 *  developements at nodes on the map. 
 * @author harrisdavi3
 * @see nz.ac.vuw.mcs.comp301.controller.Command
 * @see nz.ac.vuw.mcs.comp301.model.development.Development
 * @see nz.ac.vuw.mcs.comp3021.model.DevelopmentFactory
 */
public class CommandBuild extends Command {
	
	private int _x;
	private int _y;
	private String _developmentName;
	private int _type;
	
	private static int _width;
	private static int _height;
		
	private static Development[][] _mapArray = new Development[_width][_height];
	
	/**
	 * Initalises the values of the basic fields of each development on the map.
	 * @param x The x postion of the node
	 * @param y The y position of the node
	 * @param developmentName The name of the development being built 
	 */
	public CommandBuild (int x, int y, String developmentName) {
		this._x = x;
		this._y = y;
		this._developmentName = developmentName;
	}
	
	/**
	 * Calls store method on Development.
	 * Checks to see if a build-over or upgrade occoured.
	 * Notifies knowledge and development listeners
	 */
	public void execute() {
		Development development = DevelopmentFactory.store(this._developmentName);
		overBuild();
		addDevelopment(_x, _y, development);
		development.incrementCounter();
		String newName = development.upgradeDevelopment();
		
		if(!newName.equals(this._developmentName)) {
			KnowledgeEvent event = new KnowledgeEvent(newName, KnowledgeEvent.ADD);
			CityScapePlay.getListeners().notifyKnowledgeListeners(event);
		}		
		DevelopmentEvent dEvent = new DevelopmentEvent(development, _x, _y, DevelopmentEvent.ADDED);
		CityScapePlay.getListeners().notifyDevelopmentListeners(dEvent);				
	}
	

	public void addSubCommand(Command subCommand) {
		
	}
	

	public void removeSubCommand(Command subCommand) {
		
	}
	
	/**
	 * Adds the development to the array representing the map
	 * @param x The x postion of the node
	 * @param y The y postion of the node
	 * @param development The development being built
	 */
	public static void addDevelopment(int x, int y, Development development) {
		_mapArray[x][y] = development;
	}
	
	/**
	 * Sets the size of the array
	 * @param width The maximum width needed
	 * @param height The maximum height needed
	 */
	public static void setSize(int width, int height) {
		_width = width;
		_height = height;
		_mapArray = new Development[_width][_height];
	}
	
	/**
	 * Checks to see the new development is building over a current developement,
	 * if so, replaces and updates balance
	 */
	private void overBuild() {
		if(_mapArray[_x][_y].getName() != "empty") {
			Development development = _mapArray[_x][_y];			
			int level = Integer.parseInt(this._developmentName.substring(this._developmentName.length()-1));	
			ModelData.setBalance((int) (ModelData.getBalance() - (0.1*development.getCost(level))));
		}
	}
}
