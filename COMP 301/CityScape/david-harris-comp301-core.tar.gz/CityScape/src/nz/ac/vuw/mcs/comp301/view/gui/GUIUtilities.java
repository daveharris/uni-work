/*
This file is part of the SMSCS VUW Comp301 CityScape GUI library.

SMSCS VUW Comp301 CityScape GUI ibrary is free software; you can redistribute it
and/or modify it under the terms of version 2 of the GNU General Public License as
published by the Free Software Foundation.

The SMSCS VUW Comp301 CityScape GUI library is distributed in the hope that it will 
be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General
Public License for more details.

You should have received a copy of the GNU General Public License along with
SMSCS VUW Comp301 CityScape GUI library; if not, write to the Free Software Foundation,
Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
*/


package nz.ac.vuw.mcs.comp301.view.gui;

import java.awt.Color;
import java.awt.Font;
import java.awt.Paint;
import java.awt.Rectangle;
import java.awt.TexturePaint;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.image.BufferedImage;
import java.awt.LayoutManager;
import java.util.Hashtable;
import javax.imageio.ImageIO;
import java.io.FileNotFoundException;
import java.io.IOException;
import javax.imageio.IIOException;
import java.io.File;

import nz.ac.vuw.mcs.comp301.model.events.KnowledgeListener;
import nz.ac.vuw.mcs.comp301.model.events.KnowledgeEvent;

import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 * <p>GUIUtilities provides functionality for creating common parts of the user interface.
 * GUIUtilities maintains the colour scheme for the different parts, and maintains the images 
 * that are used in the land nodes of the map.</p>
 * <p>GUIUtilities loads in the image for a particular development when that development becomes
 * available to the player. GUIUtilities implements the KnowledgeListener interface, so that it 
 * can be told when player has learnt to build something new. This ensures that the GUIUtilities class does not need to have 
 * the list of potential developments hardcoded in.
 * </p>
 *
 * @see nz.ac.vuw.mcs.comp301.model.events.KnowledgeListener 
 * @version $Revision: 1.2 $
 * @author $Author: harrisdavi3 $, $Date: 2005/04/27 05:52:39 $
 */
/**
 * @author stuart
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class GUIUtilities implements KnowledgeListener {

	/**
	 * <p>
	 * Sets up the colors for the backgrounds and foregrounds.
	 * </p>
	 * 
	 */
	private GUIUtilities() {
		this._colours = new Hashtable();
		this._images = new Hashtable();
		
		Color yellow = new Color(255, 255, 0);
		this._colours.put("market", yellow);
		this._colours.put("treasury", yellow);
		this._colours.put("population", Color.white);
		this._colours.put("environment", Color.green);
		this._colours.put("store", yellow);
		this._colours.put("background", Color.black);
		
		return;
	}

	/* 
	 * <p>
	 * Once the player has learnt to build something new, load in the image and store it as a TexturePaint for 
	 * later retrieval. Does nothing if the player has lost the ability to construct a development.
	 * </p>
	 * <p>
	 * If no image can be found for the development, then the colour white is used.
	 * </p>
	 * 
	 * @see nz.ac.vuw.mcs.comp301.model.events.KnowledgeListener#knowledgeModified(nz.ac.vuw.mcs.comp301.model.events.KnowledgeEvent)
	 */
	public void knowledgeModified(KnowledgeEvent event) {
		int type = event.getType();
		String name = event.getDevelopment();
		if (type == KnowledgeEvent.ADD) {
			try {
				BufferedImage image = ImageIO.read(new File(this._filePath + name + ".png"));
				TexturePaint paint = new TexturePaint(image, new Rectangle(0, 0, 50, 50));
				this._images.put(name, paint);
			} catch (FileNotFoundException exception) {
				this._images.put(name, Color.white);
			} catch (IIOException exception) {
				this._images.put(name, Color.white);
			} catch (IOException exception) {
				exception.printStackTrace();
			}
		}
		return;
	}
	
	
	/**
	 * <p>
	 * Returns the paint associated with a particular development.
	 * </p>
	 * @param name The name of the development.
	 * @return The paint to be used to display the development. Returns null if no image is stored under the supplied name.
	 */
	public Paint getPaint(String name) {
		return (Paint)this._images.get(name);
	}
	
	/**
	 * <p>
	 * Returns the colour associated with a particular aspect of the user interface.
	 * </p>
	 * @param name The name of the aspect.
	 * @return The colour to be used. Returns null if no colour is stored under the supplied name.
	 */
	public Color getColour(String name) {
		return (Color)this._colours.get(name);
	}
	
	
	/**
	 * @return The only created instance of the GUIUtilities class. This ensures that there 
	 * are not two or more versions accidentally created.
	 */
	public static GUIUtilities getGUIUtilities() {
		return GUIUtilities._utilities;
	}

	
	/**
	 * <p>
	 * Creates a header label for a section of the user interface. The label is 
	 * then added to the panel, with the texted centered horizontally and aligned to the top 
	 * of the available space. The panel must use a GridBagLayout layout. Does nothing if the 
	 * panel uses a different layout manager.
	 * </p>
	 * @param panel The panel that will contain the label.
	 * @param text The text that will go into the label.
	 * @param foreground The colour of the text in the label.
	 */
	public void createHeader(JPanel panel, String text, Color foreground) {
		LayoutManager layoutManager = panel.getLayout();
		if (layoutManager instanceof GridBagLayout) {
			GridBagLayout layout = (GridBagLayout)layoutManager;
			GridBagConstraints constraints = new GridBagConstraints();
		
			JLabel header = new JLabel();
			Font utopia = new Font("Utopia", Font.ITALIC, 15);
			header.setFont(utopia);
			header.setForeground(foreground);
			header.setText(text);
			header.setHorizontalAlignment(JLabel.CENTER);
			header.setVerticalAlignment(JLabel.TOP);
		
		
			constraints.gridwidth = GridBagConstraints.REMAINDER;
			constraints.weightx = 1.0;
			constraints.weighty = 0.0;
			constraints.fill = GridBagConstraints.HORIZONTAL;
			layout.setConstraints(header, constraints);
			panel.add(header);
		}
		return;
	}
	
	/**
	 * <p>
	 * Creates two labels, the first of which contains text that describes an aspect of 
	 * the city, and the second of which shows the value for that associated aspect.
	 * </p>
	 * <p>
	 * The two labels are placed side by side, and packed into the designated panel. 
	 * The panel must use a GridBagLayout layout. The two labels will take up the remaining row in the panel's current layout. 
	 * </p>
	 * @param panel The panel that is to contain the two labels. 
	 * @param text The text that is to go into the first label. 
	 * @param foreground The color for the text of both labels.
	 * @return The second label, which will contain the value associated with the first label. Returns null if the panel does not
	 * use a GridBagLayout layout. 
	 * @see java.awt.GridBagLayout
	 */
	public JLabel createLabel(JPanel panel, String text, Color foreground) {
		
		JLabel valueLabel = null;
		
		LayoutManager layoutManager = panel.getLayout();
		if (layoutManager instanceof GridBagLayout) {
			JLabel textLabel = new JLabel(text);
			textLabel.setForeground(foreground);
			
			valueLabel = new JLabel("0");
			valueLabel.setForeground(foreground);
			valueLabel.setHorizontalAlignment(JLabel.RIGHT);
			
			GridBagLayout layout = (GridBagLayout)layoutManager;
			GridBagConstraints constraints = new GridBagConstraints();
		
			constraints.fill = GridBagConstraints.BOTH;
			constraints.weightx = 1.0;
			constraints.gridwidth = 2;
			layout.setConstraints(textLabel, constraints);
			constraints.gridwidth = GridBagConstraints.REMAINDER;
			layout.setConstraints(valueLabel, constraints);
			panel.add(textLabel);
			panel.add(valueLabel);
		} 
		return valueLabel;
	}

	static {
		GUIUtilities._utilities = new GUIUtilities();
	}
	
	/**
	 * <p>Contains the single accessible instance of the GUIUtilities class.</p>
	 */
	private static GUIUtilities _utilities;
	private Hashtable _images;
	private Hashtable _colours;
	private final String _filePath = System.getProperty("user.dir") + "/images/";
	//private final String _filePath = "";
}
