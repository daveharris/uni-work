/*
This file is part of the SMSCS VUW Comp301 CityScape GUI library.

SMSCS VUW Comp301 CityScape GUI ibrary is free software; you can redistribute it
and/or modify it under the terms of version 2 of the GNU General Public License as
published by the Free Software Foundation.

The SMSCS VUW Comp301 CityScape GUI library is distributed in the hope that it will 
be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General
Public License for more details.

You should have received a copy of the GNU General Public License along with
SMSCS VUW Comp301 CityScape GUI library; if not, write to the Free Software Foundation,
Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
*/

package nz.ac.vuw.mcs.comp301.model.events;

import java.io.Serializable;

/**
 * <p>An object representing a single message regarding the state of a player's turn, 
 * or whether a player has won or lost.</p>
 *
 * @version $Revision: 1.1 $
 * @author $Author: harrisdavi3 $, $Date: 2005/04/04 03:41:58 $
 * @see nz.ac.vuw.mcs.comp301.view.gui.GUIWindow
 * @see nz.ac.vuw.mcs.comp301.model.events.GameStateEvent
 * 
 */
public class GameStateEvent implements Serializable {

	public final static long serialVersionUID = 1;
	
	public final static int WON = 1;
	public final static int LOST = 2;
	public final static int PAUSE = 3;
	public final static int RESUME = 4;
	
	public GameStateEvent(int type, String target) {
		this._type = type;
		this._target = target;
		return;
	}
	
	public int getType() {
		return this._type;
	}
	
	public String getTarget() {
		return this._target;
	}
	
	private int _type;
	private String _target;
	
}
