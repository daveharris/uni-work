/*
This file is part of the SMSCS VUW Comp301 CityScape GUI library.

SMSCS VUW Comp301 CityScape GUI ibrary is free software; you can redistribute it
and/or modify it under the terms of version 2 of the GNU General Public License as
published by the Free Software Foundation.

The SMSCS VUW Comp301 CityScape GUI library is distributed in the hope that it will 
be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General
Public License for more details.

You should have received a copy of the GNU General Public License along with
SMSCS VUW Comp301 CityScape GUI library; if not, write to the Free Software Foundation,
Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
*/


package nz.ac.vuw.mcs.comp301.view.gui;

import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.KeyStroke;
import javax.swing.JEditorPane;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.event.HyperlinkListener;
import javax.swing.event.HyperlinkEvent;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.io.IOException;
import nz.ac.vuw.mcs.comp301.model.events.WonderListener;
import nz.ac.vuw.mcs.comp301.model.events.WonderEvent;
import nz.ac.vuw.mcs.comp301.model.events.GameStateListener;
import nz.ac.vuw.mcs.comp301.model.events.GameStateEvent;

/**
 * <p>GUIWindow implements the top-level frame for the CityScape game. The GUIWindow
 * contains the menu framework, and notifies the user of any events that occur during
 * the game.</p>
 * <p>
 * GUIWindow implements the GameStateListener and the WonderListener interfaces, so that the game
 * can send updates of important events.
 * </p>
 *
 * @see nz.ac.vuw.mcs.comp301.model.events.GameStateListener
 * @see nz.ac.vuw.mcs.comp301.model.events.WonderListener
 * @version $Revision: 1.5 $
 * @author $Author: harrisdavi3 $, $Date: 2005/05/05 12:33:34 $
 */
public class GUIWindow extends JFrame implements GameStateListener, WonderListener {

	public final static long serialVersionUID = 1;
	
	/**
	 * <p>
	 * Sets up the menu framework, and creates the top-level window into which other 
	 * user interface components can be placed.
	 * </p>
	 * @param controller Used by the GUIWindow to shut the game down when the player 
	 * has won or lost.
	 */
	public GUIWindow(GUIController controller) {
		super("CityScape");
		this.setSize(new Dimension(1000, 1000));
		this._controller = controller;
		this.setJMenuBar(this.setupMenu());
		
		 this.addWindowListener(new WindowListener() {
		 	 public void windowClosing(WindowEvent event) {
		 	     System.exit(0);
		 	 }
		 	 public void windowActivated(WindowEvent e) {}
		 	 public void windowClosed(WindowEvent e) {}
		 	 public void windowDeactivated(WindowEvent e) {}
		 	 public void windowDeiconified(WindowEvent e) {}
		 	 public void windowIconified(WindowEvent e) {}
		 	 public void windowOpened(WindowEvent e) {}
		 	}); 
		
		return;
	}
	
	/**
	 * <p>
	 * Reacts to changes in the games state. If the game wants the player to pause, user interaction is
	 * disabled. If the game wants the player to continue playing, then user interaction is enabled.
	 * If a player has won or lost, then the appropriate message is displayed by delegated methods.
	 * </p>
	 * @param event An object representing a message to all current players.
	 */
	public void gameStateModified(GameStateEvent event) {
		int type = event.getType();
		String target = event.getTarget();
		switch (type) {
			case GameStateEvent.PAUSE:
				this.setEnabled(false);
				break;
			case GameStateEvent.RESUME:
				this.setEnabled(true);
				break;
			case GameStateEvent.WON:
				this.handleVictory(target);
				break;
			case GameStateEvent.LOST:
				this.handleDefeat(target);
				break;
		}
	}
	
	/** 
	 * <p>
	 * Display a message to the player telling them that a wonder has occurred. 
	 * </p>
	 * @see nz.ac.vuw.mcs.comp301.model.events.WonderListener#wonderOccurred(nz.ac.vuw.mcs.comp301.model.events.WonderEvent)
	 */
	public void wonderOccurred(WonderEvent event) {
		String message = event.getDescription();
		JOptionPane.showMessageDialog(null, message, "Wonder!", JOptionPane.INFORMATION_MESSAGE);
		return;
	}
	
	
	/**
	 * <p>
	 * Setups the menus, and adds them into a single menubar. 
	 * </p>
	 * @return The menubar for all of the registered menus.
	 */
	private JMenuBar setupMenu() {
		JMenuBar menu = new JMenuBar();
		JMenu fileMenu = new JMenu("File");
		JMenu commandMenu = new JMenu("Command"); 
		JMenu helpMenu = new JMenu("Help");
	
		this.createMenuItem(fileMenu, "start game", 's');
		this.createMenuItem(fileMenu, "end game", 'e');
		this.createMenuItem(commandMenu, "replay", 'r');
		this.createMenuItem(commandMenu, "end turn", 't');
		this.createMenuItem(commandMenu, "undo", 'z');
		this.setupHelpMenuItem(helpMenu);
		
		menu.add(fileMenu);
		menu.add(commandMenu);
		menu.add(helpMenu);
		return menu;
	}

	/**
	 * <p>
	 * Creates a single menu option in a designated menu. Assigns a name with 
	 * that menu option, which is displayed, and also an accelerator key combination.
	 * The key combination is usually ctrl-<key>, but is dependent on the platform the user interface is 
	 * executing on. 
	 * </p>
	 * 
	 * @param menu The menu to place the option into.
	 * @param name The name to assign to the menu option.
	 * @param key The key for the accelerator option.
	 */
	private void createMenuItem(JMenu menu, String name, char key) {
		JMenuItem item = new JMenuItem(name);
		menu.add(item);
		item.setActionCommand(name);
		item.addActionListener(this._controller);
		//int modifier = Toolkit.getDefaultToolkit().getMenuShortcutKeyMask();
		item.setAccelerator(KeyStroke.getKeyStroke(key));//new Character(key), modifier));
		return;
	}
	
	/**
	 * <p>
	 * The help command is treated as a special case since it does not require 
	 * any action on the part of the game engine. This menu item will trigger a 
	 * JEditorPane to fire up, pointing at the online documentation. The documentation
	 * is written in HTML. The help menu item is assigned a DocumentationViewer 
	 * object that will display the HTML, and react to hyperlink activations.
	 * </p> 
	 * <p>
	 * The online documentation is found at the url contained in the constant: GUIWindow.HELP_URL
	 * </p>
	 * 
	 * @param menu The menu that the Help menu item shall be placed into.
	 */
	private void setupHelpMenuItem(JMenu menu) {
		JMenuItem help = new JMenuItem("Documentation");
		menu.add(help);
		help.addActionListener(new DocumentationViewer());
		return;
	}
	
	/**
	 * <p>
	 * If the name of the winner is the same as the name of the player 
	 * playing at this interface, then show a message dialog that informs them of their 
	 * victory. Otherwise, notify the player that the winner has been crowned emperor instead of them.
	 * </p>
	 * <p>
	 * Once the player acknowledges this message, the GUIController is invoked so that the game can finish.
	 * </p>
	 * @param name The name of the winner.
	 */
	private void handleVictory(String name) {
		String playerName = this._controller.getPlayerName();
		if (playerName.equals(name)) {
			JOptionPane.showMessageDialog(null, "The People Have Elected You Emperor.", "Victory!", JOptionPane.INFORMATION_MESSAGE);
			this._controller.actionPerformed(new ActionEvent(this, 1, "end game"));
		} else {
			JOptionPane.showMessageDialog(null, "The People Have Elected " + name + " As Emperor.", "Revolution!", JOptionPane.INFORMATION_MESSAGE);
			this._controller.actionPerformed(new ActionEvent(this, 1, "end game"));
		}
		return;
	}
	
	/**
	 * <p>
	 * If the name of the loser is the same as the name of the player playing at this interface, then show a 
	 * message dialog that informs them of their defeat. Once this message is acknowledge, the GUIController is invoked 
	 * so that the game can exit. 
	 * </p>
	 * <p> 
	 * If this player is not the loser, then notify the player that the loser has been knocked out of the game. The player 
	 * is then free to continue playing.
	 * </p>
	 * @param name The name of the loser.
	 */
	private void handleDefeat(String name) {
		String playerName = this._controller.getPlayerName();
		if (playerName.equals(name)) {
			JOptionPane.showMessageDialog(null, "The People Have Overthrown You.", "Defeat!", JOptionPane.INFORMATION_MESSAGE);
			this._controller.actionPerformed(new ActionEvent(this, 1, "end game"));
		} else {
			JOptionPane.showMessageDialog(null, "The People Have Overthrown " + name, "Revolution!", JOptionPane.INFORMATION_MESSAGE);
		}
		return;
	}
	
	/**
	 * <p>
	 * A reference to the object that handles creating commands that can be sent to the game engine.
	 * </p>
	 */
	private GUIController _controller;
	
	/**
	 * <p>The url where the main page of the online documentation can be found.</p>
	 */
	
}

class DocumentationViewer extends JFrame implements ActionListener {
	
	public final static long serialVersionUID = 1; 
	
	public DocumentationViewer() {
		super("Documentation");
		try {
			this._html = new JEditorPane(DocumentationViewer.HELP_URL);
		} catch (IOException exception) {
			JOptionPane.showMessageDialog(null, "Cannot find online documentation at " + DocumentationViewer.HELP_URL, "Error", JOptionPane.ERROR_MESSAGE);
		}
		JScrollPane pane = new JScrollPane(this._html);
		this.getContentPane().add(pane);
		this.pack();
		return;
	}
		
	public void actionPerformed(ActionEvent event) {
		this.setVisible(true);
		this._html.setEditable(false);
		this._html.addHyperlinkListener(new HyperlinkListener() {
			public void hyperlinkUpdate(HyperlinkEvent event) {
				JEditorPane html = (JEditorPane)event.getSource();
				if (event.getEventType() == HyperlinkEvent.EventType.ACTIVATED) {
					try {
				        html.setPage(event.getURL());
				      } catch(IOException exception) {
				      	return;
				      }	
				 }
			}
		});
	}
	
	private JEditorPane _html;
	private final static String HELP_URL = "file:gamedoc/CityScapeDocumentation.html";  
	
}
