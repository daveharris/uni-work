/*
 * Created on Apr 24, 2005
 */
package nz.ac.vuw.mcs.comp301.model;

import java.util.Iterator;
import java.util.List;
import java.util.Vector;

import nz.ac.vuw.mcs.comp301.model.events.*;

/**
 * Holds a vectors that hold all the listeners for each type of listener
 * Defines the add and notify methods for each type.
 * @author harrisdavi3
 * @see nz.ac.vuw.mcs.comp301.model.events
 */
public class Listeners {
	
	List _landListeners;
	List _knowledgeListeners;
	List _developmentListeners;
	List _financialListeners;
	List _populationListeners;
	List _storeListeners;
	List _gameListeners;
	
	/**
	 * Creates the intially empty vectors
	 */
	public Listeners() {
		_landListeners = new Vector();
		_knowledgeListeners = new Vector();
		_developmentListeners = new Vector();
		_financialListeners = new Vector();
		_populationListeners = new Vector();
		_storeListeners = new Vector();
		_gameListeners = new Vector();
	}
	
	/**
	 * Add the land listener to the vector
	 * @param listener LandListener
	 */
	public void addLandListener(LandListener listener) {
		this._landListeners.add(listener);
		return;
	}
	
	/**
	 * Notifies all the land listeners by calling the modify method
	 * @param event landEvent
	 */
	public void notifyLandListeners(LandEvent event) {
		Iterator listeners = this._landListeners.iterator();
		while (listeners.hasNext()) {
			LandListener listener = (LandListener)listeners.next();
			listener.landModified(event);
		}
		return;
	}
	
	/**
	 * Add the knowledge listener to the vector
	 * @param listener KnowledgeListener
	 */
	public void addKnowledgeListener(KnowledgeListener listener) {
		this._knowledgeListeners.add(listener);
		return;
	}
	
	/**
	 * Notifies all the knowledge listeners by calling the modify method
	 * @param event KnowledgeEvent
	 */
	public void notifyKnowledgeListeners(KnowledgeEvent event) {
		Iterator listeners = this._knowledgeListeners.iterator();
		while (listeners.hasNext()) {
			KnowledgeListener listener = (KnowledgeListener)listeners.next();
			listener.knowledgeModified(event);
		}
		return;
	}
	
	/**
	 * Add the development listener to the vector
	 * @param listener DevelopmentListener
	 */
	public void addDevelopmentListener(DevelopmentListener listener) {
		this._developmentListeners.add(listener);
		return;
	}
	
	/**
	 * Notifies all the development listeners by calling the modify method
	 * @param event DevelopmentEvent
	 */
	public void notifyDevelopmentListeners(DevelopmentEvent event) {
		Iterator listeners = this._developmentListeners.iterator();
		while (listeners.hasNext()) {
			DevelopmentListener listener = (DevelopmentListener)listeners.next();
			listener.developmentModified(event);
		}
		return;
	}
	
	/**
	 * Add the financial listener to the vector
	 * @param listener FinancialListener
	 */
	public void addFinancialListener(FinancialListener listener) {
		this._financialListeners.add(listener);
		return;
	}
	
	/**
	 * Notifies all the financial listeners by calling the modify method
	 * @param event FinancialEvent
	 */
	public void notifyFinancialListeners(FinancialEvent event) {
		Iterator listeners = this._financialListeners.iterator();
		while (listeners.hasNext()) {
			FinancialListener listener = (FinancialListener)listeners.next();
			listener.financesModified(event);
		}
		return;
	}	
	
	/**
	 * Add the population listener to the vector
	 * @param listener PopulationListener
	 */
	public void addPopulationListener(PopulationListener listener) {
		this._populationListeners.add(listener);
		return;
	}
	
	/**
	 * Notifies all the population listeners by calling the modify method
	 * @param event PopulationEvent
	 */
	public void notifyPopulationListeners(PopulationEvent event) {
		Iterator listeners = this._populationListeners.iterator();
		while (listeners.hasNext()) {
			PopulationListener listener = (PopulationListener)listeners.next();
			listener.populationModified(event);
		}
		return;
	}
	
	/**
	 * Add the store listener to the vector
	 * @param listener StoreListener
	 */
	public void addStoreListener(StoreListener listener) {
		this._storeListeners.add(listener);
		return;
	}
	
	/**
	 * Notifies all the store listeners by calling the modify method
	 * @param event StoreEvent
	 */
	public void notifyStoreListeners(StoreEvent event) {
		Iterator listeners = this._storeListeners.iterator();
		while (listeners.hasNext()) {
			StoreListener listener = (StoreListener)listeners.next();
			listener.storeModified(event);
		}
		return;
	}	
	
	/**
	 * Add the game listener to the vector
	 * @param listener GameListener
	 */
	public void addGameListener(GameStateListener listener) {
		this._gameListeners.add(listener);
		return;
	}
	
	/**
	 * Notifies all the store listeners by calling the modify method
	 * @param event StoreEvent
	 */
	public void notifyGameListeners(GameStateEvent event) {
		Iterator listeners = this._gameListeners.iterator();
		while (listeners.hasNext()) {
			GameStateListener listener = (GameStateListener)listeners.next();
			listener.gameStateModified(event);
		}
		return;
	}	
}