/*
 * Created on Apr 4, 2005
 */
package nz.ac.vuw.mcs.comp301.controller;

import nz.ac.vuw.mcs.comp301.model.Listeners;
import nz.ac.vuw.mcs.comp301.model.ModelData;
import nz.ac.vuw.mcs.comp301.model.events.*;
import nz.ac.vuw.mcs.comp301.view.*;
import nz.ac.vuw.mcs.comp301.view.gui.GUIUtilities;

/**
 * This is class holds the main method.
 * It establishes the view and liseners.
 * @author harrisdavi3
 * @see nz.ac.vuw.mcs.comp301.view.CityScapeView
 */
public class CityScapePlay {

	private static Listeners _listeners;
	private static CityScapeView _csv;
	
	/**
	 * Main method. Creates the view and listeners, and checks if random mode enabled.
	 * @param args - used to check if random mode enabled. If random mode is to be enables, 
	 * "-random" is to be put in the arguments at runtime.
	 */
	
	public static void main(String[] args) {
		_csv = new CityScapeView();
		_listeners = new Listeners();
		
		if(args.length > 0 && args[0].equalsIgnoreCase("-random"))
			ModelData.setRandom(true);			
	}
	
	/**
	 * Adds the different views that implement the listeners to the Listeners class.
	 * Needs to draw the map, the developments, developments list and the 
	 */
	public static void registerListeners() {
		_listeners.addLandListener(_csv.getMapView());
		_listeners.addKnowledgeListener(GUIUtilities.getGUIUtilities());
		_listeners.addKnowledgeListener(_csv.getSelectionView());
		_listeners.addDevelopmentListener(_csv.getMapView());
		_listeners.addPopulationListener(_csv.getPopulationView());
		_listeners.addStoreListener(_csv.getStoreView());
		_listeners.addFinancialListener(_csv.getTreasuryView());
		_listeners.addGameListener(_csv.getGUIWindow());
	}
	
	/**
	 * Creates new Knowledge events, and notifies the liseners so that 
	 * the developments can be chosen and created on the map.
	 */
	public static void notifyListeners() {
		KnowledgeEvent kFactory1Event = new KnowledgeEvent("factory1", KnowledgeEvent.ADD);
		_listeners.notifyKnowledgeListeners(kFactory1Event);

		KnowledgeEvent kFarm1Event = new KnowledgeEvent("farm1", KnowledgeEvent.ADD);
		_listeners.notifyKnowledgeListeners(kFarm1Event);

		KnowledgeEvent kHouses1Event = new KnowledgeEvent("houses1", KnowledgeEvent.ADD);
		_listeners.notifyKnowledgeListeners(kHouses1Event);

		KnowledgeEvent kPark1Event = new KnowledgeEvent("park1", KnowledgeEvent.ADD);
		_listeners.notifyKnowledgeListeners(kPark1Event);

		KnowledgeEvent kTownhall1Event = new KnowledgeEvent("townhall1", KnowledgeEvent.ADD);
		_listeners.notifyKnowledgeListeners(kTownhall1Event);

		KnowledgeEvent kEmptyEvent = new KnowledgeEvent("empty", KnowledgeEvent.ADD);
		_listeners.notifyKnowledgeListeners(kEmptyEvent);
		
		//Maximizes the window to redraw
		_csv.maximiseView();		
	}
		
	public static Listeners getListeners() {
		return _listeners;
	}
	
	public static CityScapeView getCSView() {
		return _csv;
	}
}
