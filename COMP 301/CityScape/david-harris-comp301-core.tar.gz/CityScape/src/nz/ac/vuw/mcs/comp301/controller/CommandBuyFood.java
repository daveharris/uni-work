/*
 * Created on Apr 4, 2005
 */
package nz.ac.vuw.mcs.comp301.controller;


import nz.ac.vuw.mcs.comp301.model.CityState;
import nz.ac.vuw.mcs.comp301.model.ModelData;

/**
 * Food can be bought to add to the store if there are more people than there is food
 * @author harrisdavi3
 */
public class CommandBuyFood extends Command {
	
	int _amount;
	
	/**
	 * Initalises the amount
	 * @param amount The amount of food being bought
	 */
	public CommandBuyFood(int amount) {
		this._amount = amount;
	}

	/**
	 * Updates the store and balance after the purchase of food
	 * Updates the model
	 */
	public void execute() {
		if(ModelData.getPopulation() > ModelData.getStoreFood()) {
			ModelData.setStoreFood(0);
			ModelData.setBalance(ModelData.getBalance() - ModelData.getStoreFood());
			CityState.update();
		}
	}


	public void addSubCommand(Command subCommand) {

	}

	public void removeSubCommand(Command subCommand) {

	}

}
