/*
This file is part of the SMSCS VUW Comp301 CityScape GUI library.

SMSCS VUW Comp301 CityScape GUI ibrary is free software; you can redistribute it
and/or modify it under the terms of version 2 of the GNU General Public License as
published by the Free Software Foundation.

The SMSCS VUW Comp301 CityScape GUI library is distributed in the hope that it will 
be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General
Public License for more details.

You should have received a copy of the GNU General Public License along with
SMSCS VUW Comp301 CityScape GUI library; if not, write to the Free Software Foundation,
Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
*/


package nz.ac.vuw.mcs.comp301.view.gui.events;

/**
 * <p>An interface that is implemented by objects that need to be told when 
 * the player selects a new development from the list of available developments.</p>
 *
 * @version $Revision: 1.1 $
 * @author $Author: harrisdavi3 $, $Date: 2005/04/04 03:41:58 $
 * @see nz.ac.vuw.mcs.comp301.view.gui.SelectionView
 * @see nz.ac.vuw.mcs.comp301.view.gui.GUIController
 * 
 */
public interface SelectionListener {

	/**
	 * @param event An object representing the player's new selection.
	 * @see nz.ac.vuw.mcs.comp301.view.gui.events.SelectionEvent
	 */
	public void selectionMade(SelectionEvent event);
	
}
