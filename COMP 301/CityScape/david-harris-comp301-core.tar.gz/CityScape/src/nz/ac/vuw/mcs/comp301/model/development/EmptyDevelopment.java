/*
 * Created on Apr 27, 2005
 */
package nz.ac.vuw.mcs.comp301.model.development;

/**
 * Holds information about the EmptyDevelopment, and the 'empty' object and has get methods
 * to access these fields for some given level
 * @author harrisdavi3
 */
public class EmptyDevelopment implements Development {
	
	private String _name;
	private int _level;

	private static final int[] costArray = {0};
	private static final int[] upkeepArray = {0};
	private static final int[] pollutionArray = {0};
	private static final int[] socialWorthArray = {0};
	private static final int[] jobsArray = {0};	
	
	public EmptyDevelopment(String name, int level) {
		this._name = name;
		this._level = level;
	}


	public String getName() {
		return _name;
	}


	public int getLevel() {
		return _level;
	}
	
	/**
	 * Returns the cost of the development at the given level
	 * @param level The level which this development is at
	 */
	public int getCost(int level) {
		return costArray[level];
	}

	/**
	 * Returns the upkeep of the development at the given level
	 * @param level The level which this development is at
	 */
	public int getUpkeep(int level) {
		return upkeepArray[level];
	}

	/**
	 * Returns the pollution of the development at the given level
	 * @param level The level which this development is at
	 */
	public int getPollution(int level) {
		return pollutionArray[level];
	}

	/**
	 * Returns the social worth of the development at the given level
	 * @param level The level which this development is at
	 */
	public int getSocialWorth(int level) {
		return socialWorthArray[level];
	}

	/**
	 * Returns the jobs of the development at the given level
	 * @param level The level which this development is at
	 */
	public int getJobs(int level) {
		return jobsArray[level];
	}

	/**
	 * Empty, but included to keep consistency
	 */
	public void incrementCounter() {
	}

	/**
	 * Empty, but included to keep consistency
	 */
	public String upgradeDevelopment() {
		return null;
	}
}
