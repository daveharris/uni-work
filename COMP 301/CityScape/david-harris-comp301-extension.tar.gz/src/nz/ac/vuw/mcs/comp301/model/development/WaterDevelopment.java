/*
 * Created on May 14, 2005
 */
package nz.ac.vuw.mcs.comp301.model.development;

/**
 * This class represents water, which is used when reading in the map
 * The only attribute it has is the name, which is water
 * @author harrisdavi3
 */
public class WaterDevelopment implements Development {

	private String _name;

	
	public WaterDevelopment() {
		_name = "water";
	}
	
	public String getName() {
		return _name;
	}


	public int getLevel() {
		return 1;
	}

	public int getCost(int level) {
		return 0;
	}

	public int getUpkeep(int level) {
		return 0;
	}

	public int getPollution(int level) {
		return 0;
	}

	public int getSocialWorth(int level) {
		return 0;
	}

	public int getJobs(int level) {
		return 0;
	}

	public void incrementCounter() {
	}
	
	public void advanceCounter() {
	}

	public String upgradeDevelopment() {
		return null;
	}
	
	public String getClassification() {
		return "development";
	}
	
	public int getHighestLevel() {
		return 1;
	}
}
