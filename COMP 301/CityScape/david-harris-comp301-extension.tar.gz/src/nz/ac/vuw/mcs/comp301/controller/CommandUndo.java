/*
 * Created on Apr 4, 2005
 */
package nz.ac.vuw.mcs.comp301.controller;

/**
 * Un-implemented
 * @author harrisdavi3
 */
public class CommandUndo extends Command {
	
	public CommandUndo() {
		
	}

	public void execute() {

	}
}
