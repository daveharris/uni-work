/*
 * Created on May 15, 2005
 */
package nz.ac.vuw.mcs.comp301.model.development;

/**
 * The interface that represents all wonders. They all have an endturn effect
 * It also implements the Development interface so it has all the methods that it has.
 * The level is always 1
 * @author harrisdavi3
 */
public interface Wonder extends Development {
	
	public void endTurnEffect();
}
