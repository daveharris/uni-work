/*
This file is part of the SMSCS VUW Comp301 CityScape GUI library.

SMSCS VUW Comp301 CityScape GUI ibrary is free software; you can redistribute it
and/or modify it under the terms of version 2 of the GNU General Public License as
published by the Free Software Foundation.

The SMSCS VUW Comp301 CityScape GUI library is distributed in the hope that it will 
be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General
Public License for more details.

You should have received a copy of the GNU General Public License along with
SMSCS VUW Comp301 CityScape GUI library; if not, write to the Free Software Foundation,
Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
*/


package nz.ac.vuw.mcs.comp301.view;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;

import javax.swing.JFrame;
import javax.swing.JScrollPane;

import nz.ac.vuw.mcs.comp301.controller.CommandFactory;
import nz.ac.vuw.mcs.comp301.controller.CommandFactoryImplementation;
import nz.ac.vuw.mcs.comp301.controller.CommandInterpreter;
import nz.ac.vuw.mcs.comp301.view.gui.EnvironmentView;
import nz.ac.vuw.mcs.comp301.view.gui.GUIController;
import nz.ac.vuw.mcs.comp301.view.gui.GUIWindow;
import nz.ac.vuw.mcs.comp301.view.gui.MapView;
import nz.ac.vuw.mcs.comp301.view.gui.MarketView;
import nz.ac.vuw.mcs.comp301.view.gui.PopulationView;
import nz.ac.vuw.mcs.comp301.view.gui.SelectionView;
import nz.ac.vuw.mcs.comp301.view.gui.StoreView;
import nz.ac.vuw.mcs.comp301.view.gui.TreasuryView;

/**
 * <p>The CityScapeView is responsible for initiating the creation of the different parts 
 * of the user interface, and for integrating these parts into a whole.</p>
 *
 * @version $Revision: 1.11 $
 * @author $Author: harrisdavi3 $, $Date: 2005/05/19 06:39:10 $
 * 
 */
public class CityScapeView {

	/**
	 * <p>
	 * This constructor controls the creation, arrangement, and layout of the different parts of the 
	 * user interface. The constructor then registers some components as listeners on events that 
	 * can occur on other components.
	 * </p> 
	 */
	public CityScapeView() {
		this.createComponents();
		this.setupConstraints();
		this.layoutComponents();
		
		this._mapView.addMapListener(this._controller);
		this._selectionPanel.addSelectionListener(this._controller);
		this._marketView.addTradeListener(this._controller);
		this._environmentView.addFilterListener(this._controller);
			
		return;
	}
	
	/**
	 * <p>
	 * Initiates all of the different parts of the interface. 
	 * </p>
	 */
	private void createComponents() {
		this._mapView = new MapView();
		this._commandFactory = new CommandFactoryImplementation();
		this._commandInterpreter = new CommandInterpreter(System.out);
		this._controller = new GUIController(this._mapView, this._commandInterpreter, this._commandFactory);
		this._popView = new PopulationView();
		this._storeView = new StoreView();
		this._marketView = new MarketView();
		this._finView = new TreasuryView(this._controller);
		this._frame = new GUIWindow(this._controller);
		this._selectionPanel = new SelectionView(this._controller);
		this._environmentView = new EnvironmentView();
		
		this._mapScroll = new JScrollPane(this._mapView);
		this._selectionScroll = new JScrollPane(this._selectionPanel);
		
		return;
	}
	
	/**
	 *  <p>Assigns constraints to the different user interface components, so 
	 * that they are laid out in a logical order on the screen.
	 * </p>
	 */
	private void setupConstraints() {
		GridBagLayout layout = new GridBagLayout();
		this._frame.getContentPane().setLayout(layout);
		
		GridBagConstraints constraints = new GridBagConstraints();
		
		constraints.weightx = 0.0;
		constraints.weighty = 1.0;
		constraints.gridwidth = 1;
		constraints.gridy = 0;
		constraints.gridx = 0;
		constraints.fill = GridBagConstraints.BOTH;
		constraints.gridheight = GridBagConstraints.REMAINDER;
		layout.setConstraints(this._selectionScroll, constraints);
		constraints.weightx = 1.0;
		constraints.gridwidth = 1;
		constraints.gridx = 1;
		layout.setConstraints(this._mapScroll, constraints);
			
		constraints.weightx = 0.25;
		constraints.fill = GridBagConstraints.BOTH;
		constraints.gridwidth = 1;
		constraints.gridheight = 1;
		constraints.gridy = 0;
		constraints.gridx = 2;
		layout.setConstraints(this._popView, constraints);
		constraints.gridy = 1;
		layout.setConstraints(this._environmentView, constraints);
		constraints.gridy = 2;
		layout.setConstraints(this._finView, constraints);
		constraints.gridy = 3;
		layout.setConstraints(this._storeView, constraints);
		constraints.gridy = 4;
		layout.setConstraints(this._marketView, constraints);
		
		return;
	}
	
	/**
	 * <p>
	 * Layout the components against the constraints agreed to earlier. Pack them into a frame and make 
	 * them visible on screen.
	 * </p>
	 */
	private void layoutComponents() {
		this._frame.getContentPane().add(this._environmentView);
		this._frame.getContentPane().add(this._selectionScroll);
		this._frame.getContentPane().add(this._mapScroll);
		this._frame.getContentPane().add(this._popView);
		this._frame.getContentPane().add(this._finView);
		this._frame.getContentPane().add(this._storeView);
		this._frame.getContentPane().add(this._marketView);
		
		this._frame.pack();
		this._frame.setVisible(true);
		return;
	}
	
	public MapView getMapView() {
		return this._mapView;
	}
	
	public SelectionView getSelectionView() {
		return this._selectionPanel;
	}
	
	public TreasuryView getTreasuryView() {
		return this._finView;
	}
	
	public PopulationView getPopulationView() {
		return this._popView;
	}
	
	public StoreView getStoreView() {
		return this._storeView;
	}
	
	public GUIWindow getGUIWindow() {
		return this._frame;
	}
	
	public MarketView getMarketView() {
		return this._marketView;
	}
	
	public EnvironmentView getEnvironmentalView() {
		return _environmentView;
	}
	
	public CommandInterpreter getCommandInterpreter() {
		return this._commandInterpreter;
	}
	
	public void maximiseView() {
        _frame.setExtendedState(JFrame.MAXIMIZED_BOTH);
}

	
	
	private MapView _mapView;
	private GUIController _controller;
	private PopulationView _popView;
	private StoreView _storeView;
	private MarketView _marketView;
	private TreasuryView _finView;
	private GUIWindow _frame;
	private SelectionView _selectionPanel;
	private EnvironmentView _environmentView;
	private CommandFactory _commandFactory;
	private CommandInterpreter _commandInterpreter;
	
	private JScrollPane _mapScroll;
	private JScrollPane _selectionScroll;
	
	
}
