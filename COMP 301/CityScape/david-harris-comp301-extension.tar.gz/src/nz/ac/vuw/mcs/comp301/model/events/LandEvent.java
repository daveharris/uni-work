/*
This file is part of the SMSCS VUW Comp301 CityScape GUI library.

SMSCS VUW Comp301 CityScape GUI ibrary is free software; you can redistribute it
and/or modify it under the terms of version 2 of the GNU General Public License as
published by the Free Software Foundation.

The SMSCS VUW Comp301 CityScape GUI library is distributed in the hope that it will 
be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General
Public License for more details.

You should have received a copy of the GNU General Public License along with
SMSCS VUW Comp301 CityScape GUI library; if not, write to the Free Software Foundation,
Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
*/

package nz.ac.vuw.mcs.comp301.model.events;

import java.io.Serializable;

/**
 * <p>An object representing a single piece of land that has either been created or destroyed.</p>
 *
 * @version $Revision: 1.1 $
 * @author $Author: harrisdavi3 $, $Date: 2005/04/04 03:41:58 $
 * @see nz.ac.vuw.mcs.comp301.view.gui.MapView
 * @see nz.ac.vuw.mcs.comp301.model.events.LandListener
 * 
 */
public class LandEvent implements Serializable {

	public final static long serialVersionUID = 1;
	
	public static final int ADDED = 1;
	public static final int REMOVED = 2; 
	
	public LandEvent(int x, int y, int type) {
		this._xLocation = x;
		this._yLocation = y;
		this._type = type;
		return;
	}
	
	public int getXLocation() {
		return this._xLocation;
	}
	
	public int getYLocation() {
		return this._yLocation;
	}
	
	public int getType() {
		return this._type;
	}
	
	private int _xLocation;
	private int _yLocation;
	private int _type;
	
}
