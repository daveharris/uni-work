/*
 * Created on Apr 4, 2005
 */
package nz.ac.vuw.mcs.comp301.controller;

import nz.ac.vuw.mcs.comp301.model.CityState;
import nz.ac.vuw.mcs.comp301.model.KnowledgeWonderStore;
import nz.ac.vuw.mcs.comp301.model.MarketState;
import nz.ac.vuw.mcs.comp301.model.ModelData;
import nz.ac.vuw.mcs.comp301.model.Pollution;
import nz.ac.vuw.mcs.comp301.model.development.*;
import nz.ac.vuw.mcs.comp301.model.events.DevelopmentEvent;
import nz.ac.vuw.mcs.comp301.model.events.KnowledgeEvent;


/**
 * This class sets up the information to be passed to other classes to create
 *  developements at nodes on the map. 
 * @author harrisdavi3
 * @see nz.ac.vuw.mcs.comp301.controller.Command
 * @see nz.ac.vuw.mcs.comp301.model.development.Development
 * @see nz.ac.vuw.mcs.comp301.model.development.DevelopmentFactory
 */
public class CommandBuild extends Command {
	
	private static int _x;
	private static int _y;
	private String _developmentName;
	private int _type;
	
	private static int _width;
	private static int _height;
	
	private static Development[][] _mapArray = new WaterDevelopment[_width][_height];
	
	/**
	 * Initalises the values of the basic fields of each development on the map.
	 * @param x The x postion of the node
	 * @param y The y position of the node
	 * @param developmentName The name of the development being built 
	 */
	public CommandBuild (int x, int y, String developmentName) {
		_x = x;
		_y = y;
		this._developmentName = developmentName;
	}
	
	/**
	 * Calls store method on Development.
	 * Checks to see if a build-over or upgrade occoured.
	 * Notifies knowledge and development listeners
	 */
	public void execute() {
		if(!isWater(_x, _y)) {
			Development development = DevelopmentFactory.store(this._developmentName);
			DevelopmentFactory.update(development);
			Pollution.showPollution(_x, _y, development);
			overBuild();
			addDevelopment(_x, _y, development);
			if(development.getClassification().equals("wonder")) {
				KnowledgeWonderStore kStore = KnowledgeWonderStore.getKnowledgeStore();
				if(!kStore.knowledgeAvailable(this._developmentName)) {
					kStore.addAvailableWonder(this._developmentName);
					System.out.println("added " + _developmentName + " to available wonder");
				}
			}
			else if(!this._developmentName.equals("empty")) {
				development.incrementCounter();
				DevelopmentFactory.store(_developmentName);
				String newName = development.upgradeDevelopment();
				if(!newName.equals(this._developmentName)) {
					KnowledgeEvent event = new KnowledgeEvent(newName, KnowledgeEvent.ADD);
					CityScapePlay.getListeners().notifyKnowledgeListeners(event);
				}
			}
			DevelopmentEvent dEvent = new DevelopmentEvent(development, _x, _y, DevelopmentEvent.ADDED);
			CityScapePlay.getListeners().notifyDevelopmentListeners(dEvent);
			
			CityState.update();
		}
	}
	
	/**
	 * Adds the development to the array representing the map.
	 * Also changes the special feature of each development
	 * @param x The x postion of the node
	 * @param y The y postion of the node
	 * @param development The development being built
	 */
	public static void addDevelopment(int x, int y, Development development) {
		KnowledgeWonderStore kWStore = KnowledgeWonderStore.getKnowledgeStore();
		String developmentName = development.getName();

		_mapArray[x][y] = development;
		
		int level;
		if(development.getClassification().equals("development")) {
			if(developmentName.startsWith("factory")) {
				level = Integer.parseInt(developmentName.substring(developmentName.length()-1));
				IndustrialDevelopment dev = (IndustrialDevelopment) development;
				ModelData.setMaxGoods(ModelData.getMaxGoods() + dev.getGoodsOutput(level));				
			}
			else if (developmentName.startsWith("farm")) {
				level = Integer.parseInt(developmentName.substring(developmentName.length()-1));
				AgriculturalDevelopment dev = (AgriculturalDevelopment) development;
				ModelData.setMaxFood(ModelData.getMaxFood() + dev.getFoodOutput(level));				
			}
			else if (developmentName.startsWith("houses")) {
				level = Integer.parseInt(developmentName.substring(developmentName.length()-1));
				ResidentialDevelopment dev = (ResidentialDevelopment) development;
				ModelData.setLivingSpaces(ModelData.getLivingSpaces() + dev.getLivingSpaces(level));
			}
			else if (developmentName.startsWith("park")) {
				level = Integer.parseInt(developmentName.substring(developmentName.length()-1));
				RecreationalDevelopment dev = (RecreationalDevelopment) development;
				ModelData.setEnjoyment(ModelData.getEnjoyment() + dev.getEnjoyment(level));
			}
			else if (developmentName.startsWith("townhall")) {
				level = Integer.parseInt(developmentName.substring(developmentName.length()-1));
				GovernmentDevelopment dev = (GovernmentDevelopment) development;
				ModelData.setLaw(ModelData.getLaw() + dev.getLawOutput(level));
			}
		}
		else {
			kWStore.removeAvailableWonder(developmentName);
			kWStore.addBuiltWonder((Wonder) development);
		}
		CityState.update();
	}
	
	/**
	 * Sets the size of the array
	 * @param width The maximum width needed
	 * @param height The maximum height needed
	 */
	public static void setSize(int width, int height) {
		_width = width;
		_height = height;
		_mapArray = new Development[_width][_height];
	}
	
	/**
	 * Checks to see the new development is building over a current developement,
	 * if so, replaces and updates balance
	 */
	private void overBuild() {
		if(_mapArray[_x][_y].getName() != "empty") {
			Development oldDevelopment = _mapArray[_x][_y];
			int level;
			if(!this._developmentName.equals("empty")) {
				level = Integer.parseInt(_developmentName.substring(_developmentName.length()-1));
			}
			else
				level = 1;
			ModelData.setBalance((int) (ModelData.getBalance() + (0.1*oldDevelopment.getCost(level))));
			MarketState.setBalance(MarketState.getBalance() + ModelData.getBalance());

			_mapArray[_x][_y] = new WaterDevelopment();
			ModelData.setStoreGoods((int) (ModelData.getStoreGoods() + (oldDevelopment.getCost(oldDevelopment.getLevel()))));
			ModelData.setUpkeep((int) (ModelData.getUpkeep() - (oldDevelopment.getUpkeep(oldDevelopment.getLevel()))));
			ModelData.setJobs((int) (ModelData.getJobs() - ((oldDevelopment.getJobs(oldDevelopment.getLevel())))));	
		}
	}
	
	/**
	 * Checks if the node at position (x, y) on the map is water on not
	 * @param x The x position of the node
	 * @param y The y position of the node
	 * @return True if the node at (x,y) is water, else returns false
	 */
	public static boolean isWater(int x, int y) {
		if(_mapArray[x][y].getName().equals("water")) {
			return true;
		}
		return false;
	}
}
