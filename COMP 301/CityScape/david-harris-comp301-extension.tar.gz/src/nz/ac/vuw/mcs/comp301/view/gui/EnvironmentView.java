/*
This file is part of the SMSCS VUW Comp301 CityScape GUI library.

SMSCS VUW Comp301 CityScape GUI ibrary is free software; you can redistribute it
and/or modify it under the terms of version 2 of the GNU General Public License as
published by the Free Software Foundation.

The SMSCS VUW Comp301 CityScape GUI library is distributed in the hope that it will 
be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General
Public License for more details.

You should have received a copy of the GNU General Public License along with
SMSCS VUW Comp301 CityScape GUI library; if not, write to the Free Software Foundation,
Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
*/

package nz.ac.vuw.mcs.comp301.view.gui;

import java.awt.Color;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;

import javax.swing.JCheckBox;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.border.EtchedBorder;

import nz.ac.vuw.mcs.comp301.view.gui.events.FilterEvent;
import nz.ac.vuw.mcs.comp301.view.gui.events.FilterListener;
import nz.ac.vuw.mcs.comp301.model.events.EnvironmentalListener;
import nz.ac.vuw.mcs.comp301.model.events.EnvironmentalEvent;

import java.awt.event.ItemListener;
import java.awt.event.ItemEvent;

import java.util.List;
import java.util.Iterator;
import java.util.Vector;

/**
 * <p>An EnvironmentView shows information about a city's pollution and social worth.
 * The EnvironmentView prints the average residential pollution, the average agricultural pollution,
 * and the average residential social worth. The EnvironmentView also contains two 
 * check boxes that can be used to turn on or off the pollution and the social worth 
 * displays in the MapView. EnvironmentView implements EnviromentalListener so that 
 * it can told of updates to the city's environment. EnvironmentView notifies any registered
 * FilterListener objects when the player toggles the pollution or social worth displays.</p>
 *
 * @see nz.ac.vuw.mcs.comp301.model.events.EnvironmentalListener
 * @see nz.ac.vuw.mcs.comp301.view.gui.events.FilterListener 
 * @version $Revision: 1.1 $
 * @author $Author: harrisdavi3 $, $Date: 2005/04/04 03:41:58 $
 */
public class EnvironmentView extends JPanel implements ItemListener, EnvironmentalListener {

	public static final long serialVersionUID = 1;
	
	/**
	 * <p>This constructor creates the layout for the consituent components. GUIUtilities
	 * is used to determine what colours should be used for the foreground text and the background.
	 * GUIUtilities is also used to generate a standard layout for a label and a value for each of 
	 * the pollution characteristics that will be displayed.
	 * </p> 
	 * 
	 * @see nz.ac.vuw.mcs.comp301.view.gui.GUIUtilities
	 */
	public EnvironmentView() {
		super();
		this._listeners = new Vector();
		
		GridBagLayout layout = new GridBagLayout();
		GridBagConstraints constraints = new GridBagConstraints();
		GUIUtilities utilities = GUIUtilities.getGUIUtilities();
		Color foreground = utilities.getColour("environment");
		Color background = utilities.getColour("background");
		this.setBorder(new EtchedBorder(Color.black, Color.red));
		this.setBackground(background);
		this.setLayout(layout);
		
		utilities.createHeader(this, "Environment", foreground);
		this._avgAgrPollution = utilities.createLabel(this, "Avg. Agr. Pollution:", foreground);
		this._avgResPollution = utilities.createLabel(this, "Avg. Res. Pollution:", foreground);
		this._avgResSocialWorth = utilities.createLabel(this, "Avg. Res. Social Worth:", foreground);

		this.setupCheckBoxes();
		
		this.setVisible(true);
		return;
	}
	
	/**
	 * <p>
	 * Invoked when a check box has been modified in the interface. Finds which check box
	 * has been changed, and determines the new value. Any FilterListener objects are
	 * then told whether the pollution or the social worth should now be hidden or shown.
	 * </p>
	 * @param event An object representing a change to one of the check boxes.
	 * @see java.awt.event.ItemListener#itemStateChanged(java.awt.event.ItemEvent)
	 */
	public void itemStateChanged(ItemEvent event) {
		FilterEvent filterEvent = null;
		JCheckBox box = (JCheckBox)event.getItem();
		boolean turnOnFilter = (event.getStateChange() == ItemEvent.SELECTED); 
		if (box == this._pollution) {
			if (turnOnFilter) {
				filterEvent = new FilterEvent(FilterEvent.SHOW, FilterEvent.POLLUTION);
			} else {
				filterEvent = new FilterEvent(FilterEvent.HIDE, FilterEvent.POLLUTION);				
			}
		} else if (box == this._socialWorth) {
			if (turnOnFilter) {
				filterEvent = new FilterEvent(FilterEvent.SHOW, FilterEvent.SOCIAL_WORTH);
			} else {
				filterEvent = new FilterEvent(FilterEvent.HIDE, FilterEvent.SOCIAL_WORTH);
			}
		}
		
		if (filterEvent != null) {
			this.notifyListeners(filterEvent);
		}
		return;
	}
	
	/**
	 * <p>
	 * Handles updates from the model regarding changes to the city's pollution or social worth.
	 * </p>
	 * <p>
	 * This object is only interested in events that correspond to changes in the 
	 * average pollution or the average social worth. Events corresponding to changes
	 * at particular nodes are ignored.
	 * </p>
	 * <p>
	 * The relevant part of the display is updated to show the new value.
	 * </p>
	 * @see nz.ac.vuw.mcs.comp301.model.events.EnvironmentalListener#environmentModified(nz.ac.vuw.mcs.comp301.model.events.EnvironmentalEvent)
	 */
	public void environmentModified(EnvironmentalEvent event) {
		int amount = event.getAmount();
		int type = event.getType();
		
		switch (type) {
			case EnvironmentalEvent.AVG_AGR_POLLUTION:
				this._avgAgrPollution.setText(Integer.toString(amount));
				break;
			case EnvironmentalEvent.AVG_RES_POLLUTION:
				this._avgResPollution.setText(Integer.toString(amount));
				break;
			case EnvironmentalEvent.AVG_RES_SOCIAL_WORTH:
				this._avgResSocialWorth.setText(Integer.toString(amount));
				break;
		}
		return;
	}
	
	
	/**
	 * <p>
	 * Registers a new listener, that will the be notified when the user changes 
	 * the filter selections.
	 * </p>
	 * @param listener An object that wishes to know about user modifications to 
	 * the pollution and social worth filters.
	 */
	public void addFilterListener(FilterListener listener) {
		this._listeners.add(listener);
		return;
	}
	
	/**
	 * <p>
	 * Notifies listeners that the user has modified the filter.
	 * </p>
	 * @param event The object to be sent to all registered listeners.
	 */
	private void notifyListeners(FilterEvent event) {
		Iterator listeners = this._listeners.iterator();
		while (listeners.hasNext()) {
			FilterListener listener = (FilterListener)listeners.next();
			listener.filterModified(event);
		}
		return;
	}
	
	/**
	 * <p>
	 * Creates two check boxes for the pollution and the social worth filters.
	 * </p>
	 * <p>
	 * These check boxes are then added to the panel for display, and their background 
	 * is made transparent so that the panel's background shows through. The foreground
	 * text color is that specified by GUIUtilities for this panel. 
	 * </p>
	 * @see nz.ac.vuw.mcs.comp301.gui.view.GUIUtilities
	 */
	private void setupCheckBoxes() {
		GridBagLayout layout = (GridBagLayout)this.getLayout();
		GridBagConstraints constraints = new GridBagConstraints();
		
		Color foreground = GUIUtilities.getGUIUtilities().getColour("environment");
		
		this._pollution = new JCheckBox("Show Pollution");
		this._socialWorth = new JCheckBox("Show Social Worth");
		
		this._pollution.setForeground(foreground);
		this._socialWorth.setForeground(foreground);
		
		this._pollution.setOpaque(false);
		this._socialWorth.setOpaque(false);
		
		this._pollution.addItemListener(this);
		this._socialWorth.addItemListener(this);
		
		constraints.fill = GridBagConstraints.HORIZONTAL;
		constraints.weightx = 1.0;
		constraints.gridwidth = 1;
		
		layout.setConstraints(this._pollution, constraints);
		layout.setConstraints(this._socialWorth, constraints);
		
		this.add(this._pollution);
		this.add(this._socialWorth);
		
		return;
	}
	
	private List _listeners;
	private JLabel _avgResPollution;
	private JLabel _avgAgrPollution;
	private JLabel _avgResSocialWorth;
	private JCheckBox _pollution;
	private JCheckBox _socialWorth;
	
}
