/*
This file is part of the SMSCS VUW Comp301 CityScape GUI library.

SMSCS VUW Comp301 CityScape GUI ibrary is free software; you can redistribute it
and/or modify it under the terms of version 2 of the GNU General Public License as
published by the Free Software Foundation.

The SMSCS VUW Comp301 CityScape GUI library is distributed in the hope that it will 
be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General
Public License for more details.

You should have received a copy of the GNU General Public License along with
SMSCS VUW Comp301 CityScape GUI library; if not, write to the Free Software Foundation,
Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
*/

package nz.ac.vuw.mcs.comp301.model.development;

/**
 * <p>
 * A high level interface that represents the basic features of all possible developments.
 * </p>
 * 
 * @version $Revision: 1.5 $
 * @author $Author: harrisdavi3 $, $Date: 2005/05/18 05:26:53 $
 */
public interface Development {
	
	/**
	 * @return The name of the development.
	 * 
	 * The name should be a unique identifier for this development type and level.
	 */
	public String getName();
	
	public int getLevel();
	
	public int getCost(int level);
	
	public int getUpkeep(int level);
	
	public int getPollution(int level);
	
	public int getSocialWorth(int level);
	
	public int getJobs(int level);
	
	public void incrementCounter();
	
	public void advanceCounter();
	
	public String upgradeDevelopment();
	
	public String getClassification();
	
	public int getHighestLevel();
	
}
