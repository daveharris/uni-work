/*
 * Created on Apr 4, 2005
 */
package nz.ac.vuw.mcs.comp301.controller;

import nz.ac.vuw.mcs.comp301.model.KnowledgeWonderStore;
import nz.ac.vuw.mcs.comp301.model.Listeners;
import nz.ac.vuw.mcs.comp301.model.ModelData;
import nz.ac.vuw.mcs.comp301.model.development.DevelopmentFactory;
import nz.ac.vuw.mcs.comp301.model.events.*;
import nz.ac.vuw.mcs.comp301.view.*;
import nz.ac.vuw.mcs.comp301.view.gui.GUIUtilities;

/**
 * This is class holds the main method.
 * It establishes the view and liseners.
 * @author harrisdavi3
 * @see nz.ac.vuw.mcs.comp301.view.CityScapeView
 */
public class CityScapePlay {

	private static Listeners _listeners;
	private static CityScapeView _csv;
	
	/**
	 * Main method. Creates the view and listeners, and checks if random mode enabled.
	 * @param args - used to check if random mode enabled. If random mode is to be enables, 
	 * "-random" is to be put in the arguments at runtime.
	 */
	
	public static void main(String[] args) {
		_csv = new CityScapeView();
		_listeners = new Listeners();
		
		if(args.length > 0 && args[0].equalsIgnoreCase("-random"))
			ModelData.setRandom(true);			
	}
	
	/**
	 * Adds the different views that implement the listeners to the Listeners class.
	 * Needs to draw the map, the developments, developments list and the 
	 */
	public static void registerListeners() {
		_listeners.addLandListener(_csv.getMapView());
		_listeners.addKnowledgeListener(GUIUtilities.getGUIUtilities());
		_listeners.addKnowledgeListener(_csv.getSelectionView());
		_listeners.addDevelopmentListener(_csv.getMapView());
		_listeners.addPopulationListener(_csv.getPopulationView());
		_listeners.addStoreListener(_csv.getStoreView());
		_listeners.addFinancialListener(_csv.getTreasuryView());
		_listeners.addGameListener(_csv.getGUIWindow());
		_listeners.addWonderListener(_csv.getGUIWindow());
		_listeners.addWonderListener(new DevelopmentFactory());
		_listeners.addMarketListener(_csv.getMarketView());
		_listeners.addEnvironmentalListener(_csv.getMapView());
		_listeners.addEnvironmentalListener(_csv.getEnvironmentalView());
	}
	
	/**
	 * Creates new Knowledge events, and notifies the liseners so that 
	 * the developments can be chosen and created on the map.
	 */
	public static void notifyListeners() {		
		KnowledgeEvent kUniversityEvent = new KnowledgeEvent("University", KnowledgeEvent.ADD);
		_listeners.notifyKnowledgeListeners(kUniversityEvent);
		addToWonderKnowledgeStore("University");
		
		KnowledgeEvent kParliamentEvent = new KnowledgeEvent("Parliament", KnowledgeEvent.ADD);
		_listeners.notifyKnowledgeListeners(kParliamentEvent);
		addToWonderKnowledgeStore("Parliament");
		
		KnowledgeEvent kStadiumEvent = new KnowledgeEvent("Stadium", KnowledgeEvent.ADD);
		_listeners.notifyKnowledgeListeners(kStadiumEvent);
		addToWonderKnowledgeStore("Stadium");
		
		KnowledgeEvent kGardensEvent = new KnowledgeEvent("Gardens", KnowledgeEvent.ADD);
		_listeners.notifyKnowledgeListeners(kGardensEvent);
		addToWonderKnowledgeStore("Gardens");
		
		KnowledgeEvent kHospitalEvent = new KnowledgeEvent("Hospital", KnowledgeEvent.ADD);
		_listeners.notifyKnowledgeListeners(kHospitalEvent);
		addToWonderKnowledgeStore("Hospital");
		
		KnowledgeEvent kApartmentsEvent = new KnowledgeEvent("Apartments", KnowledgeEvent.ADD);
		_listeners.notifyKnowledgeListeners(kApartmentsEvent);
		addToWonderKnowledgeStore("Apartments");
		
		KnowledgeEvent kFactory1Event = new KnowledgeEvent("factory1", KnowledgeEvent.ADD);
		_listeners.notifyKnowledgeListeners(kFactory1Event);
		DevelopmentFactory.store("factory1");

		KnowledgeEvent kFarm1Event = new KnowledgeEvent("farm1", KnowledgeEvent.ADD);
		_listeners.notifyKnowledgeListeners(kFarm1Event);
		DevelopmentFactory.store("farm1");
		
		KnowledgeEvent kHouses1Event = new KnowledgeEvent("houses1", KnowledgeEvent.ADD);
		_listeners.notifyKnowledgeListeners(kHouses1Event);
		DevelopmentFactory.store("houses1");

		KnowledgeEvent kPark1Event = new KnowledgeEvent("park1", KnowledgeEvent.ADD);
		_listeners.notifyKnowledgeListeners(kPark1Event);
		DevelopmentFactory.store("park1");

		KnowledgeEvent kTownhall1Event = new KnowledgeEvent("townhall1", KnowledgeEvent.ADD);
		_listeners.notifyKnowledgeListeners(kTownhall1Event);
		DevelopmentFactory.store("townhall1");

		KnowledgeEvent kEmptyEvent = new KnowledgeEvent("empty", KnowledgeEvent.ADD);
		_listeners.notifyKnowledgeListeners(kEmptyEvent);

		//Maximizes the window to redraw
		_csv.maximiseView();		
	}
		
	public static Listeners getListeners() {
		return _listeners;
	}
	
	public static CityScapeView getCSView() {
		return _csv;
	}
	
	/**
	 * Adds the knowldge to the knowldge store as wonders can only be built once
	 * @param knowledge The knowledge to be added
	 */
	private static void addToWonderKnowledgeStore(String knowledge) {
		KnowledgeWonderStore kStore = KnowledgeWonderStore.getKnowledgeStore();
		kStore.addAvailableWonder(knowledge);
	}	
}
