/*
 * Created on Apr 4, 2005
 */
package nz.ac.vuw.mcs.comp301.controller;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Vector;

import nz.ac.vuw.mcs.comp301.model.CityState;
import nz.ac.vuw.mcs.comp301.model.development.DevelopmentFactory;

/**
 * This reads in a file of formatted commands, that are constructed and run
 * @version $Revision: 1.11 $
 * @author $Author: harrisdavi3 $, $Date: 2005/05/19 05:17:04 $
 */
public class CommandReplay extends Command {
	
	BufferedReader _input;
	boolean isWater;
	Vector commands;
	String dataline;
	int space1;
	
	/**
	 * Initalises the variables
	 * @param input Bufferedreader of the file to read
	 */
	public CommandReplay(BufferedReader input) {
		commands = new Vector();
		this._input = input;
		readFile();		
	}
	
	/**
	 * Reads in the file to replay, and passes the command string to createCommand 
	 *
	 */	
	public void readFile() {
		try {
			dataline = _input.readLine();
			String command;
			while(dataline != null) {
				if(dataline.equalsIgnoreCase("end"))
					command = "end";
				else {
					space1 = dataline.indexOf(' ');
					command = dataline.substring(0, space1);
				}
				createCommand(command);
				dataline = _input.readLine();
			}
			_input.close();
		}
		
		catch (IOException ex) {
			System.out.println("IO Error:  " + ex.getMessage());
			ex.printStackTrace();
		}		
	}
	
	public void execute() {
		CityState.update();
	}
	
	/**
	 * Creates a command based on the command string
	 * @param command The string describing the type of command to make
	 * @return The newly created command object
	 */
	private Command createCommand(String command) {
		Command ans = null;
		if(command.equalsIgnoreCase("build")) {
			int space2 = dataline.indexOf(' ', space1+1);
            int x = Integer.parseInt(dataline.substring(space1+1, space2));
            int space3 = dataline.indexOf(' ', space2+1);
            int y = Integer.parseInt(dataline.substring(space2+1, space3));
            String type = dataline.substring(space3+1);
            Command build = new CommandBuild(x, y, type);
            if(DevelopmentFactory.containsKnowledge(type)) {
            	build.execute();
            	return build;
            }
        }
		else if(command.equalsIgnoreCase("tax")) {
            int amount = Integer.parseInt(dataline.substring(space1+1));
        	CommandTax tax = new CommandTax(amount);
        	tax.execute();
        	return tax;
        }
		else if(command.equalsIgnoreCase("replay")) {
			try {
				FileReader inStream = new FileReader(dataline.substring(space1+1));
				new CommandReplay(new BufferedReader(inStream));
			}
			catch (IOException ex) {
				System.out.println("IO Error:  " + ex.getMessage());
				ex.printStackTrace();
			}		
		}
		else if(command.equalsIgnoreCase("end")) {
        	CommandEndTurn end = new CommandEndTurn();
        	return end;
        }
		else if(command.equalsIgnoreCase("buyfood")) {
			int amount = Integer.parseInt(dataline.substring(space1+1));
        	CommandBuyFood buyFood = new CommandBuyFood(amount);
        	buyFood.execute();
        	return buyFood;
        }
		else if(command.equalsIgnoreCase("sellfood")) {
			int amount = Integer.parseInt(dataline.substring(space1+1));
			CommandSellFood sellFood = new CommandSellFood(amount);
			sellFood.execute();
        	return sellFood;
        }
		else if(command.equalsIgnoreCase("buygoods")) {
			int amount = Integer.parseInt(dataline.substring(space1+1));
			CommandBuyGoods buyGoods = new CommandBuyGoods(amount);
			buyGoods.execute();
        	return buyGoods;
        }
		else if(command.equalsIgnoreCase("sellgoods")) {
			int amount = Integer.parseInt(dataline.substring(space1+1));
			CommandSellGoods sellGoods = new CommandSellGoods(amount);
			sellGoods.execute();
        	return sellGoods;
        }
		return null;
	}
}
