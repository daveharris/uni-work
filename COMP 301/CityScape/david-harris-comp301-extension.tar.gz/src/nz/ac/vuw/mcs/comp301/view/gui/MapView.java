/*
This file is part of the SMSCS VUW Comp301 CityScape GUI library.

SMSCS VUW Comp301 CityScape GUI ibrary is free software; you can redistribute it
and/or modify it under the terms of version 2 of the GNU General Public License as
published by the Free Software Foundation.

The SMSCS VUW Comp301 CityScape GUI library is distributed in the hope that it will 
be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General
Public License for more details.

You should have received a copy of the GNU General Public License along with
SMSCS VUW Comp301 CityScape GUI library; if not, write to the Free Software Foundation,
Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
*/

package nz.ac.vuw.mcs.comp301.view.gui;

import java.util.List;
import java.util.Hashtable;
import java.util.Vector;
import java.util.Iterator;
import javax.swing.JComponent;
import javax.swing.Scrollable;
import java.awt.Graphics;
import java.awt.Polygon;
import java.awt.Point;
import java.awt.Color;
import java.awt.Paint;
import java.awt.AlphaComposite;
import java.awt.Dimension;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.awt.AWTEvent;
import nz.ac.vuw.mcs.comp301.model.events.DevelopmentListener;
import nz.ac.vuw.mcs.comp301.model.events.EnvironmentalListener;
import nz.ac.vuw.mcs.comp301.model.events.LandListener;
import nz.ac.vuw.mcs.comp301.model.development.Development;
import nz.ac.vuw.mcs.comp301.model.events.DevelopmentEvent;
import nz.ac.vuw.mcs.comp301.model.events.EnvironmentalEvent;
import nz.ac.vuw.mcs.comp301.model.events.LandEvent;
import java.awt.event.MouseEvent;

import nz.ac.vuw.mcs.comp301.view.gui.events.MapListener;
import nz.ac.vuw.mcs.comp301.view.gui.events.MapEvent;

/**
 * <p>A MapView shows a map of hexagonal nodes that represents the city.</p>
 * <p>The MapView maintains three different aspects: a view of the land and the developments
 * that exist in the city, a view of the pollution at the different nodes in the city, and a
 * view of the social worth at the different nodes in the city. The land and development aspect
 * is always visible. The pollution aspect and the social worth aspect can be toggled 
 * on and off.  
 * </p>
 * <p>
 * The three different aspects are stored as Images that are overlayed, using alpha composition 
 * to allow one to be seen through another. MapView implements the LandListener, DevelopmentListener, 
 * and EnvironmentListener interfaces so that it can informed of any changes to the city that may 
 * affect these three aspects. 
 * </p>
 * <p>
 * The MapView implements javax.swing.Scrollable so that the map size can be handled by 
 * the containing user interface.
 * </p>
 * 
 * @version $Revision: 1.2 $
 * @author $Author: harrisdavi3 $, $Date: 2005/05/05 09:31:05 $
 * @see java.awt.Image
 */
public class MapView extends JComponent implements DevelopmentListener, LandListener, EnvironmentalListener, Scrollable {

	public final static long serialVersionUID = 1;
	
	public MapView() {
		this._listeners = new Vector();
		this._polygons = new Hashtable();
		this._showPollution = false;
		this._showSocialWorth = false;
		this.setMapSize(MapView.WIDTH, MapView.HEIGHT);
		this.enableEvents(AWTEvent.MOUSE_EVENT_MASK);
		return;
	}

	private void setMapSize(int width, int height) { 
		this._width = width;
		this._height = height;
		this.setPreferredSize(new Dimension(width, height));
		this._map = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);
		this._pollution = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);
		this._socialWorth = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);
		return;
	}
	
	public void addMapListener(MapListener listener) {
		this._listeners.add(listener);
		return;
	}
	
	/** 
	 * <p>
	 * Determines the type of environmental event that has occurred, and updates
	 * the aspects if they have been affected. The MapView only cares about changes
	 * to individual nodes, and ignores events that are to do with changes in 
	 * city-wide averages. 
	 * </p>
	 * @param event An environmental update about the city. 
	 * @see nz.ac.vuw.mcs.comp301.model.events.EnvironmentalListener#environmentModified(nz.ac.vuw.mcs.comp301.model.events.EnvironmentalEvent)
	 */
	public void environmentModified(EnvironmentalEvent event) {
		int x = event.getXLocation();
		int y = event.getYLocation();
		int amount = event.getAmount();
		int type = event.getType();
		
		switch (type) {
			case EnvironmentalEvent.POLLUTION:
				this.handlePollution(x, y, amount);
				break;
			case EnvironmentalEvent.SOCIAL_WORTH:
				this.handleSocialWorth(x, y, amount);
				break;
		}
		return;
	}
	
	/**
	 * <p>
	 * Reacts to land being created being created by adding a polygon to the 
	 * map image. Currently does nothing if land is removed. 
	 * </p>
	 * <p>
	 * This method delegates responsibility for calculating where the vertices of the 
	 * polygon should be.
	 * </p>
	 * 
	 * @param event An object that identifies which node the land has been created in or removed from. 
	 * The coordinates are relative to the city's layout, rather than measured in screen pixels.
	 * @see nz.ac.vuw.mcs.comp301.model.events.LandListener#landModified(nz.ac.vuw.mcs.comp301.model.events.LandEvent)
	 */
	public void landModified(LandEvent event) {
		int type = event.getType();
		int x = event.getXLocation();
		int y = event.getYLocation();
		Graphics2D graphics = (Graphics2D)this._map.getGraphics();
		
		switch (type) {
			case LandEvent.ADDED:
				int[] xPoints = this.getXPoints(x);
				int[] yPoints = this.getYPoints(x, y);
				Polygon landShape = new Polygon(xPoints, yPoints, 6);
				this._polygons.put(new PolygonID(x, y), landShape);
				graphics.draw(landShape);
				break;
			case LandEvent.REMOVED:
				break;
		}
		this.repaint();
		return;
	}
	
	/** 
	 * <p>
	 * Reacts to the building of a development on a land node by updating the map image 
	 * to show the image of the development at the correct location. Currently does not handle
	 * deleting developments, as when existing developments are destroyed they are always 
	 * replaced by other developments (even if it is only "undeveloped").
	 * </p>
	 * 
	 * @param event An object representing the development that has been added or deleted from the city.
	 * @see nz.ac.vuw.mcs.comp301.model.events.DevelopmentListener#developmentModified(nz.ac.vuw.mcs.comp301.model.events.DevelopmentEvent)
	 */
	public void developmentModified(DevelopmentEvent event) {
		int type = event.getType();
		int x = event.getXLocation();
		int y = event.getYLocation();
		Development development = event.getDevelopment();
		String developmentName = development.getName();
		
		switch (type) {
			case DevelopmentEvent.ADDED:
				Polygon landShape = (Polygon)this._polygons.get(new PolygonID(x, y));
				Graphics2D graphics = (Graphics2D)this._map.getGraphics();
				this.paintImage(graphics, landShape, developmentName);
				break;
			case DevelopmentEvent.REMOVED:
				break;
		}
		this.repaint();
		return;
	}
	
	/**
	 * @param setVisible true if the pollution image should be overlaid on the map image.
	 */
	public void showPollution(boolean setVisible) {
		this._showPollution = setVisible;
		this.repaint();
		return;
	}
	
	/**
	 * @param setVisible true if the social worth image should be overlaid on the map image.
	 */
	public void showSocialWorth(boolean setVisible) {
		this._showSocialWorth = setVisible;
		this.repaint();
		return;
	}
	
	/** 
	 * <p>
	 * Displays the map of land nodes and developments, and uses alpha composition to 
	 * add in the pollution and social worth images if their respective filters have been 
	 * turned on.
	 * </p>
	 * 
	 * @param graphics The graphics context for this component.
	 * @see java.awt.Component#paint(java.awt.Graphics)
	 */
	public void paint(Graphics graphics) {
		graphics.setColor(Color.blue);
		graphics.fillRect(0, 0, this._width, this._height);
		graphics.drawImage(this._map, 0, 0, this._width, this._height, null);
		
		Graphics2D extnGraphics = (Graphics2D)graphics;
		extnGraphics.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_ATOP, (float)0.5));
		if (this._showPollution) {
			graphics.drawImage(this._pollution, 0, 0, this._width, this._height, null);
		}
		
		if (this._showSocialWorth) {
			graphics.drawImage(this._socialWorth, 0, 0, this._width, this._height, null);
		}
		return;
	}
	
	
	/* 
	 * <p>
	 * Tells any containing scrollpanes how much of the component should be shown at any one time.
	 * </p>
	 * 
	 * @see javax.swing.Scrollable#getPreferredScrollableViewportSize()
	 */
	public Dimension getPreferredScrollableViewportSize() {
		return new Dimension(400, 400);
	}

	/** 
	 * @see javax.swing.Scrollable#getScrollableUnitIncrement(java.awt.Rectangle, int, int)
	 */
	public int getScrollableUnitIncrement(Rectangle visibleRect,
			int orientation, int direction) {
		return MapView.POLYGON_EDGE_LENGTH;
	}

	/** 
	 * @see javax.swing.Scrollable#getScrollableBlockIncrement(java.awt.Rectangle, int, int)
	 */
	public int getScrollableBlockIncrement(Rectangle visibleRect,
			int orientation, int direction) {
		return MapView.POLYGON_EDGE_LENGTH;
	}

	/**
	 * @see javax.swing.Scrollable#getScrollableTracksViewportWidth()
	 */
	public boolean getScrollableTracksViewportWidth() {
		return false;
	}

	/**
	 * @see javax.swing.Scrollable#getScrollableTracksViewportHeight()
	 */
	public boolean getScrollableTracksViewportHeight() {
		return false;
	}

	/**
	 * <p>
	 * Intercepts mouse events that occur on the map. If a mouse event is identified as a 
	 * left mouse click, then a new MapEvent object is created with the x and y location of the 
	 * node where the mouse event occured. This event is then sent to MapListeners if the 
	 * node where the mouse event occured currently contains land.
	 * </p>
	 * 
	 * @param event An object that identifies the type of mouse action, and where it took place (measured in pixels).
	 */
	public void processMouseEvent(MouseEvent event) {
		int type = event.getID();
		int button = event.getButton();
		
		if ((type == MouseEvent.MOUSE_RELEASED) && (button == MouseEvent.BUTTON1)) {
			Point location = event.getPoint();
			Point newLocation = this.findPolygon(location);
			if (newLocation == null) {
				return;
			}
			int newX = newLocation.x;
			int newY = newLocation.y;
			MapEvent newEvent = new MapEvent(newX, newY); 
			this.notifyMapListeners(newEvent);
		} 
		return;
	}
	
	private void notifyMapListeners(MapEvent event) {
		Iterator listeners = this._listeners.iterator();
		while (listeners.hasNext()) {
			MapListener listener = (MapListener)listeners.next();
			listener.mapClicked(event);
		}
		return;
	}
	
	/**
	 * <p>
	 * Translates a position on the screen into the identifier of a node in the city's map.
	 * </p>
	 * 
	 * @param location An x and y location measured in pixels.
	 * @return A new Point object that contains x and y locations measured in terms of the 
	 * city's layout.
	 */
	private Point findPolygon(Point location) {
		Iterator iterator = this._polygons.keySet().iterator();
		while (iterator.hasNext()) {
			PolygonID polygonID = (PolygonID)iterator.next();
			Polygon polygon = (Polygon)this._polygons.get(polygonID);
			if (polygon.contains(location)) {
				return new Point(polygonID.getX(), polygonID.getY()); 
			}
	
		}
		return null;
	}
	
	/**
	 * @param x The column that this node is in with respect to the city's map.
	 * @return The x locations of the vertices in the new node's polygon, measured in pixels. 
	 */
	private int[] getXPoints(int x) {
		double angle = Math.toRadians(60);
		double dx = Math.cos(angle) * MapView.POLYGON_EDGE_LENGTH; 
		int x1 = (int)(x * (dx + MapView.POLYGON_EDGE_LENGTH)) + MapView.CORNER_OFFSET;
		int x2 = (int)(x1 + dx);
		int x3 = (int)(x2 + MapView.POLYGON_EDGE_LENGTH);
		int x4 = (int)(x3 + dx);
		int x5 = (int)(x3);
		int x6 = (int)(x2);
		int[] points = {x1, x2, x3, x4, x5, x6};
		return points;
	}
	
	/**
	 * @param x The column that this node is in with respect to the city's map. As the nodes are represented as 
	 * regular hexagons, the row also affects the vertical position of the node.
	 * @param y The row that this node is in with respect to the city's map.
	 * @return The y locations of the vertices in the new node's polygon, measured in pixels. 
	 */
	private int[] getYPoints(int x, int y) {
		double angle = Math.toRadians(60);
		double dy = Math.sin(angle) * MapView.POLYGON_EDGE_LENGTH; 
		int y1 = (int)((y * dy * 2) - (((x % 2) == 0) ? dy : 0)) + MapView.CORNER_OFFSET;
		int y2 = (int)(y1 - dy);
		int y3 = (int)(y1 - dy);
		int y4 = (int)(y1);
		int y5 = (int)(y1 + dy);
		int y6 = (int)(y1 + dy);
		int[] points = {y1, y2, y3, y4, y5, y6};
		return points;
	}
	
	/**
	 * <p>
	 * Fills the polygon identified by the x and y coordinates (relative to the city's layout).
	 * The colour the polygon is filled with is affected by the amount of pollution in that node.
	 * The more pollution there is, the darker the polygon gets.
	 * </p>
	 * 
	 * @param x The column the node is in relative to the city's layout.
	 * @param y The row the node is in relative to the city's layout.
	 * @param pollution The amount of pollution in this node.
	 */
	private void handlePollution(int x, int y, int pollution) {
		Polygon landShape = (Polygon)this._polygons.get(new PolygonID(x, y));
		if (landShape != null) {
			Graphics2D graphics = (Graphics2D)this._pollution.getGraphics();
			int pollutionFactor = Math.max(255 - (pollution * 10), 0);
			graphics.setColor(new Color(pollutionFactor, pollutionFactor, pollutionFactor));
			graphics.fill(landShape);
			this.repaint();
		}
		return;
	}
	
	/**
	 * <p>
	 * Fills the polygon identified by the x and y coordinates (relative to the city's layout).
	 * The colour the polygon is filled with is affected by the degree of social worth in that node.
	 * The more social worth there is, the purpler the polygon gets.
	 * </p>
	 * 
	 * @param x The column the node is in relative to the city's layout.
	 * @param y The row the node is in relative to the city's layout.
	 * @param socialWorth The degree of social worth in this node.
	 */
	private void handleSocialWorth(int x, int y, int socialWorth) {
		Polygon landShape = (Polygon)this._polygons.get(new PolygonID(x, y));
		if (landShape != null) {
			Graphics2D graphics = (Graphics2D)this._socialWorth.getGraphics();
			int socialFactor = Math.max(255 - (socialWorth * 10), 0);
			graphics.setColor(new Color(255, socialFactor, 255));
			graphics.fill(landShape);
			this.repaint();
		}
		return;
	}
	
	/**
	 * <p>
	 * Paints an image representing a development into the polygon where that 
	 * development has been built. Uses the GUIUtilities class to get a reference to 
	 * the correct Paint that should be used to fill the land's polygon. 
	 * </p>
	 * <p>
	 * The name of the development is then written over the top of the paint.
	 * </p>
	 * 
	 * @param graphics The graphics context for the place where the image will be drawn.
	 * @param landShape The polygon representing the land node where the development will be drawn.
	 * @param development The name of the development that is to be drawn.
	 * @see nz.ac.vuw.mcs.comp301.view.gui.GUIUtilities
	 */
	private void paintImage(Graphics2D graphics, Polygon landShape, String development) {
		Paint developmentImage = GUIUtilities.getGUIUtilities().getPaint(development);
		Rectangle bounds = landShape.getBounds();
		int x = (int)bounds.getX();
		int y = (int)bounds.getY();
		int width = (int)bounds.getWidth();
		int height = (int)bounds.getHeight();
		x += (width / 4);
		y += (height / 2);
		graphics.setPaint(developmentImage);
		graphics.fill(landShape);
		graphics.setColor(Color.black);
		graphics.drawString(development, x, y);
		graphics.drawPolygon(landShape);
		return;
	}
	
	private int _width;
	private int _height;
	private Hashtable _polygons;
	private Image _map;
	private Image _pollution;
	private Image _socialWorth;
	private boolean _showPollution;
	private boolean _showSocialWorth;
	private List _listeners;
	private static final int POLYGON_EDGE_LENGTH = 40;
	private static final int CORNER_OFFSET = 100;
	private static final int WIDTH = 1000;
	private static final int HEIGHT = 1000;
	
}

class PolygonID {
	
	public PolygonID(int x, int y) {
		this._x = x;
		this._y = y;
		return;
	}
	
	public int getX() {
		return this._x;
	}
	
	public int getY() {
		return this._y;
	}
	
	public boolean equals(Object obj) {
		PolygonID id = (PolygonID)obj;
		return (this._x == id._x) && (this._y == id._y);
	}
	
	public int hashCode() {
		return this._x + this._y;
	}
	
	private int _x;
	private int _y;
	
}
