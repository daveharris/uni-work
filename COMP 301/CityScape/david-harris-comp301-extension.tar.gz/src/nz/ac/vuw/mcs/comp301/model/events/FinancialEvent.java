/*
This file is part of the SMSCS VUW Comp301 CityScape GUI library.

SMSCS VUW Comp301 CityScape GUI ibrary is free software; you can redistribute it
and/or modify it under the terms of version 2 of the GNU General Public License as
published by the Free Software Foundation.

The SMSCS VUW Comp301 CityScape GUI library is distributed in the hope that it will 
be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General
Public License for more details.

You should have received a copy of the GNU General Public License along with
SMSCS VUW Comp301 CityScape GUI library; if not, write to the Free Software Foundation,
Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
*/

package nz.ac.vuw.mcs.comp301.model.events;

import java.io.Serializable;

/**
 * <p>An object representing a new value for one aspect of the treasury.</p>
 *
 * @version $Revision: 1.1 $
 * @author $Author: harrisdavi3 $, $Date: 2005/04/04 03:41:58 $
 * @see nz.ac.vuw.mcs.comp301.view.gui.TreasuryView
 * @see nz.ac.vuw.mcs.comp301.model.events.FinancialListener
 *  
 */
public class FinancialEvent implements Serializable {

	public final static long serialVersionUID = 1;
	
	public static final int BALANCE = 1;
	public static final int TAX_RATE = 2;
	public static final int UPKEEP = 3;
	
	public FinancialEvent(int newAmount, int type) {
		this._amount = newAmount;
		this._type = type;
		return;
	}
	
	public int getAmount() {
		return this._amount;
	}
	
	public int getType() {
		return this._type;
	}
	
	private int _amount;
	private int _type;
	
}
