/*
 * Created on Apr 27, 2005
 */
package nz.ac.vuw.mcs.comp301.model.development;


/**
 * Holds information about the AgricultralDevelopment, and the 'farm' object and has get methods
 * to access these fields for some given level
 * @author harrisdavi3
 */
public class AgriculturalDevelopment implements Development {
	
	private String _name;
	private int _level;
	private static int _count;
	private static int _highestlevel = 1;
	
	private static final int[] costArray = {6,12,16,20,22};
	private static final int[] upkeepArray = {1,2,3,4,5};
	private static final int[] pollutionArray = {3,4,5,4,3};
	private static final int[] socialWorthArray = {3,4,4,5,6};
	private static final int[] jobsArray = {5,10,25,10,5};
	private static final int[] foodsOutputArray = {5,10,20,35,50};
	
	/**
	 * Creates a new AgricultralDevelopment given a name and level
	 * @param name The name of the new development being built
	 * @param level The level which this development is at
	 */
	public AgriculturalDevelopment(String name, int level) {
		this._name = name;
		this._level = level;
		if(level > _highestlevel)
			_highestlevel = level;
		_count = 0;
	}

	public String getName() {
		return _name;
	}

	public int getLevel() {
		return _level;
	}

	/**
	 * Returns the cost of the development at the given level
	 * @param level The level which this development is at
	 */
	public int getCost(int level) {
		return costArray[level-1];
	}

	
	/**
	 * Returns the upkeep of the development at the given level
	 * @param level The level which this development is at
	 */
	public int getUpkeep(int level) {
		return upkeepArray[level-1];
	}

	/**
	 * Returns the pollution of the development at the given level
	 * @param level The level which this development is at
	 */
	public int getPollution(int level) {
		return pollutionArray[level-1];
	}

	/**
	 * Returns the social worth of the development at the given level
	 * @param level The level which this development is at
	 */
	public int getSocialWorth(int level) {
		return socialWorthArray[level-1];
	}

	/**
	 * Returns the jobs of the development at the given level
	 * @param level The level which this development is at
	 */
	public int getJobs(int level) {
		return jobsArray[level-1];
	}
	
	/**
	 * Returns the food output of the development at the given level
	 * @param level The level which this development is at
	 */
	public int getFoodOutput(int level) {
		return foodsOutputArray[level-1];
	}
	
	/**
	 * Increases the level counter
	 * used for upgrading developments
	 */
	public void incrementCounter() {
		_count++;
	}
	
	public void advanceCounter() {
		_count = 10;
	}
	
	/**
	 * Checks if a new development is available,
	 * and if so then allow the next level to be built
	 */
	public String upgradeDevelopment() {
		int level = Integer.parseInt(_name.substring(_name.length()-1));
		
		if(_count%100 == 10) {
			level = (_count/100)+(level+1);			
		}
		if(level >= 6) {
			return _name;
		}
		String newName = _name.substring(0, _name.length()-1);
		return newName + level;		
	}

	public String getClassification() {
		return "development";
	}
	
	public int getHighestLevel() {
		return _highestlevel;
	}
}
