/*
 * Created on Apr 27, 2005
 */
package nz.ac.vuw.mcs.comp301.model.development;

/**Holds information about the IndustrialDevelopment, and the 'factory' object and has get methods
 * to access these fields for some given level
 * @author harrisdavi3
 */
public class IndustrialDevelopment implements Development {
	
	private String _name;
	private int _level;
	private static int _count;
	private static int _highestlevel = 1;
	
	private static final int[] costArray = {10,20,28,35,40};
	private static final int[] upkeepArray = {1,2,3,4,5};
	private static final int[] pollutionArray = {15,20,25,28,30};
	private static final int[] socialWorthArray = {3,4,4,5,6};
	private static final int[] jobsArray = {30,40,45,48,50};
	private static final int[] goodsOutputArray = {5,7,10,15,25};
	
	/**
	 * Creates a new IndustrialDevelopment given a name and level
	 * @param name The name of the new development being built
	 * @param level The level which this development is at
	 */
	public IndustrialDevelopment(String name, int level) {
		this._name = name;
		this._level = level;
		if(level > _highestlevel)
			_highestlevel = level;
		_count = 0;
	}

	public String getName() {
		return _name;
	}


	public int getLevel() {
		return _level;
	}

	/**
	 * Returns the cost of the development at the given level
	 * @param level The level which this development is at
	 */
	public int getCost(int level) {
		return costArray[level-1];
	}

	/**
	 * Returns the upkeep of the development at the given level
	 * @param level The level which this development is at
	 */
	public int getUpkeep(int level) {
		return upkeepArray[level-1];
	}

	/**
	 * Returns the pollution of the development at the given level
	 * @param level The level which this development is at
	 */
	public int getPollution(int level) {
		return pollutionArray[level-1];
	}

	/**
	 * Returns the social worth of the development at the given level
	 * @param level The level which this development is at
	 */
	public int getSocialWorth(int level) {
		return socialWorthArray[level-1];
	}

	/**
	 * Returns the jobs of the development at the given level
	 * @param level The level which this development is at
	 */
	public int getJobs(int level) {
		return jobsArray[level-1];
	}
	
	/**
	 * Returns the goods output of the development at the given level
	 * @param level The level which this development is at
	 */
	public int getGoodsOutput(int level) {
		return goodsOutputArray[level-1];
	}

	/**
	 * Increases the level counter
	 * used for upgrading developments
	 */
	public void incrementCounter() {
		_count++;		
	}
	
	public void advanceCounter() {
		_count = 10;
	}

	/**
	 * Checks if a new development is available,
	 * and if so then allow the next level to be built
	 */
	public String upgradeDevelopment() {
		int level = Integer.parseInt(_name.substring(_name.length()-1));
		
		if(_count%100 == 10) {
			level = (_count/100)+(level+1);			
		}
		if(level >= 6) {
			return _name;
		}
		String newName = _name.substring(0, _name.length()-1);
		return newName + level;		
	}
	
	public String getClassification() {
		return "development";
	}
	
	public int getHighestLevel() {
		return _highestlevel;
	}

}
