/*
This file is part of the SMSCS VUW Comp301 CityScape GUI library.

SMSCS VUW Comp301 CityScape GUI ibrary is free software; you can redistribute it
and/or modify it under the terms of version 2 of the GNU General Public License as
published by the Free Software Foundation.

The SMSCS VUW Comp301 CityScape GUI library is distributed in the hope that it will 
be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General
Public License for more details.

You should have received a copy of the GNU General Public License along with
SMSCS VUW Comp301 CityScape GUI library; if not, write to the Free Software Foundation,
Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
*/


package nz.ac.vuw.mcs.comp301.controller;

import java.io.PrintStream;

/**
 * <p>
 * An interpreter that handles command objects. The interpreter is responsible 
 * for ensuring that commands are executed are in the correct order, and that the commands 
 * can be manipulated as needed by the player's interactions with the game. 
 * </p>
 * 
 * @version $Revision: 1.2 $
 * @author $Author: harrisdavi3 $, $Date: 2005/04/05 06:21:14 $
 * @see nz.ac.vuw.mcs.comp301.controller.Command
 */
public class CommandInterpreter {

	/**
	 * <p>
	 * Sets up an output stream so that commands can be logged to an external location.
	 * </p>
	 * 
	 * @param output An output stream to print commands to.
	 */
	public CommandInterpreter(PrintStream output) {
		this._log = output;
		return;
	}
	
	public void executeCommand(Command command) {
		command.execute();
	}
	
	/**
	 * <p>
	 * Prints a message to an external location, so that the game's actions can be logged
	 * and investigated at a later point.
	 * </p>
	 * 
	 * @param message A message that is to be logged on the output stream.
	 */
	private void outputLog(String message) {
		if (this._log != null) {
			this._log.println(message);
		}
		return;
	}

		/**
	 * An output stream that sends messages to an external location. 
	 */
	private PrintStream _log;
}
