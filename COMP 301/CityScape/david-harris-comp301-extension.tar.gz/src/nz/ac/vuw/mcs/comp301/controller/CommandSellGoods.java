/*
 * Created on Apr 4, 2005

 */
package nz.ac.vuw.mcs.comp301.controller;

import nz.ac.vuw.mcs.comp301.model.CityState;
import nz.ac.vuw.mcs.comp301.model.ModelData;

/**
 * Changes the values when goods are sold
 * @author harrisdavi3
 */
public class CommandSellGoods extends Command {
	
	int _amount;
	
	/**
	 * Initalises the amount to the amount wanting to be sold
	 * @param amount The amount of goods wanting to be sold
	 */
	public CommandSellGoods(int amount) {
		this._amount = amount;
	}

	/**
	 * Calculates the values when goods are sold
	 */
	public void execute() {
		ModelData.setStoreGoods(ModelData.getStoreGoods() - _amount);
		ModelData.setBalance(ModelData.getBalance() + _amount);
		CityState.update();
	}
}
