/*
 * Created on May 1, 2005
 */
package nz.ac.vuw.mcs.comp301.model;

import nz.ac.vuw.mcs.comp301.controller.CommandBuyFood;
import nz.ac.vuw.mcs.comp301.controller.CommandBuyGoods;
import nz.ac.vuw.mcs.comp301.controller.CommandSellFood;
import nz.ac.vuw.mcs.comp301.controller.CommandSellGoods;
import nz.ac.vuw.mcs.comp301.model.development.AgriculturalDevelopment;
import nz.ac.vuw.mcs.comp301.model.development.Development;
import nz.ac.vuw.mcs.comp301.model.development.GovernmentDevelopment;
import nz.ac.vuw.mcs.comp301.model.development.IndustrialDevelopment;
import nz.ac.vuw.mcs.comp301.model.development.ResidentialDevelopment;


/**
 * Holds all the data of the city
 * If any other class needs some information, they can directly access it from this class.
 * Has set and get methods to access fields 
 * @author harrisdavi3
 */
public class ModelData {
	
	private static int _population = 50;
	private static int _health = 0;
	private static int _jobs = 0;
	private static int _livingSpaces = 0;
	private static int _enjoyment = 0;
	private static int _law = 0;
	
	private static int _avgAgrPollution = 0;
	private static int _avgResPollution = 0;
	private static int _avgResSocialWorth = 1;
	
	private static int _taxRate = 20;
	private static int _balance = 100;
	private static int _upkeep = 0;
	
	private static int _storeGoods = 50;
	private static int _storeFood = 50;
	private static int _maxGoods = 0;
	private static int _maxFood = 0;
	
	private static int _happiness = 0;
	private static double _effiency = 0;
	private static int _income = 0;
	
	private static boolean _random = false;
	
	private static double _randomNum = 1;
	
	
	public static int getAvgAgrPollution() {
		return _avgAgrPollution;
	}
	public static void setAvgAgrPollution(int agrPollution) {
		_avgAgrPollution = agrPollution;
	}
	public static int getAvgResPollution() {
		return _avgResPollution;
	}
	public static void setAvgResPollution(int resPollution) {
		_avgResPollution = resPollution;
	}
	public static int getAvgResSocialWorth() {
		return _avgResSocialWorth;
	}
	public static void setAvgResSocialWorth(int resSocialWorth) {
		_avgResSocialWorth = resSocialWorth;
	}
	public static int getBalance() {
		return _balance;
	}
	public static void setBalance(int balance) {
		_balance = balance;
	}	
	public static double getEffiency() {
		return _effiency;
	}
	public static void setEffiency(double effiency) {
		_effiency = effiency;
	}
	public static int getEnjoyment() {
		return _enjoyment;
	}
	public static void setEnjoyment(int enjoyment) {
		_enjoyment = enjoyment;
	}
	public static int getHappiness() {
		return _happiness;
	}
	public static void setHappiness(int happiness) {
		_happiness = happiness;
	}
	public static int getHealth() {
		return _health;
	}
	public static void setHealth(int health) {
		_health = _health + health;
	}
	public static int getIncome() {
		return _income;
	}
	public static void setIncome(int income) {
		_income = income;
	}
	public static int getJobs() {
		return _jobs;
	}
	public static void setJobs(int jobs) {
		_jobs = jobs;
	}
	public static int getLaw() {
		return _law;
	}
	public static void setLaw(int law) {
		_law = law;
	}
	public static int getLivingSpaces() {
		return _livingSpaces;
	}
	public static void setLivingSpaces(int spaces) {
		_livingSpaces = spaces;
	}
	public static int getMaxFood() {
		return _maxFood;
	}
	public static void setMaxFood(int food) {
		_maxFood = food;
	}
	public static int getMaxGoods() {
		return _maxGoods;
	}
	public static void setMaxGoods(int goods) {
		_maxGoods = goods;
	}
	public static int getPopulation() {
		return _population;
	}
	public static void setPopulation(int population) {
		_population = population;
	}
	public static int getStoreFood() {
		return _storeFood;
	}
	public static void setStoreFood(int food) {
		_storeFood = food;
	}
	public static int getStoreGoods() {
		return _storeGoods;
	}
	public static void setStoreGoods(int goods) {
		_storeGoods = goods;
	}
	public static int getTaxRate() {
		return _taxRate;
	}
	public static void setTaxRate(int rate) {
		_taxRate = rate;
	}
	public static int getUpkeep() {
		return _upkeep;
	}
	public static void setUpkeep(int upkeep) {
		_upkeep = upkeep;
	}
	public static boolean randomMode() {
		return _random;
	}
	public static void setRandom(boolean random) {
		_random = random;
	}
	
	/**
	 * Gets a random number for random calculations
	 * @param boundary the range of values
	 * @return Returns a random number beween -0.5*booundary and 0.5*boundary
	 */
	public static double randomNumGenerator(int boundary) {
		_randomNum = (int) ((Math.random())*boundary - (boundary/2));
		return _randomNum;
	}
	
	/**
	 * Calculates the cities efficency
	 * @return the efficency
	 */
	public static double calculateEffiency() {
		setEffiency(Math.min(1, ((_population + 0.0)/Math.max(1, _jobs))*(1+(_law/100.0))));
		return _effiency;
	}
	
	/**
	 * Calculates cities income
	 * @return the income
	 */
	public static int calculateIncome() {
		if(_random)
			randomNumGenerator(20);
		setIncome((int) ((_effiency*_jobs*_avgResSocialWorth*_taxRate/100)*_randomNum));
		return _income;
	}
	
	/**
	 * Calculates the cities health
	 * used to calulate population changes
	 * @return the health
	 */
	public static int calculateHealth() {
		int newHealth = 10 - _avgResPollution;
		if(_population > _livingSpaces)
			newHealth = newHealth-(_population/Math.max(1, _livingSpaces));
		if(_random) {
			randomNumGenerator(30);
			_population = (int) (_population + newHealth*(_randomNum/100));
			setHealth((int) (newHealth - newHealth*(_randomNum/100)));
			return newHealth;
		}
		
		else {
			_population = (int) (_population + (newHealth)/100);
			setHealth(newHealth);		
			return newHealth;
		}
	}
	
	/**
	 * Calculates the populations happiness
	 * @return the happiness
	 */
	public static int calculateHappiness() {
		setHappiness((_enjoyment-_taxRate) + (5*_health));
		return _happiness;
	}
	
	/**
	 * Calculates the current food level when a farm is built
	 * @param development The AgricultralDevelopment that is being added
	 * @return The current food level
	 */	
	public static int calculateFood(Development development) {
		AgriculturalDevelopment agDev = (AgriculturalDevelopment) development;
		int level = Integer.parseInt(agDev.getName().substring(agDev.getName().length()-1));
		int newFood = (int)ModelData.getEffiency()*(ModelData.getStoreFood() + agDev.getFoodOutput(level)) - _population;
		if(_random) {
			randomNumGenerator(30);
			ModelData.setStoreFood((int) (newFood - newFood*(_randomNum/100)));
		}
		else
			ModelData.setStoreFood(newFood);
		
		CityState.storeUpdate();
		return getStoreFood();
	
	}
	
	/**
	 * Calculates the current goods level when a factory is built 
	 * @param development The IndustrialDevelopment that is being added
	 * @return The current goods level
	 */
	public static int calculateGoods(Development development) {
		IndustrialDevelopment indDev = (IndustrialDevelopment) development;
		int level = Integer.parseInt(indDev.getName().substring(indDev.getName().length()-1));
		int newGoods = (int)getEffiency()*(getStoreGoods() + indDev.getGoodsOutput(level));
		if(_random) {
			randomNumGenerator(30);
			ModelData.setStoreGoods((int) (newGoods - newGoods*(_randomNum/100)));
		}
		
		else 
			ModelData.setStoreGoods(newGoods);
		
		CityState.storeUpdate();
		return getStoreGoods();		
	}
	
	/**
	 * Calculates the current living spaces when a house is built 
	 * @param development The ResidentialDevelopment that is being added
	 * @return The current number of living spaces
	 */
	public static int calculateLivingSpaces(Development development) {
		
		ResidentialDevelopment resDev = (ResidentialDevelopment) development;
		int level = Integer.parseInt(resDev.getName().substring(resDev.getName().length()-1));
		int newLS = getLivingSpaces() + resDev.getLivingSpaces(level);
		if(_random) {
			randomNumGenerator(30);
			ModelData.setLivingSpaces((int) (newLS - newLS*(_randomNum/100)));
		}
		
		else 
			ModelData.setLivingSpaces(newLS);
		
		CityState.populationUpdate();
		return getLivingSpaces();
	}
	
	/**
	 * Calculates the current law increase when a townhall is built 
	 * @param development The GovernmentDevelopment that is being added
	 * @return The current number of living spaces
	 */
	public static int calculateLaws(Development development) {
		
		GovernmentDevelopment govtDev = (GovernmentDevelopment) development;
		int level = Integer.parseInt(govtDev.getName().substring(govtDev.getName().length()-1));
		int newLaws = getLaw() + govtDev.getLawOutput(level);
		ModelData.setLivingSpaces(newLaws);
		
		CityState.populationUpdate();
		return getLivingSpaces();
	}
	
	/**
	 * Creates a new command object with the amount to be bought
	 * @param amount The amount of goods wanting to be bought
	 */
	public static void buyGoods(int amount) {
		CommandBuyGoods buyGoods = new CommandBuyGoods(amount);
	}
	/**
	 * Creates a new command object with the amount to be bought
	 * @param amount The amount of food wanting to be bought
	 */
	public static void buyFood(int amount) {
		CommandBuyFood buyFood = new CommandBuyFood(amount);
	}
	/**
	 * Creates a new command object with the amount to be bought
	 * @param amount The amount of goods wanting to be sold
	 */
	public static void sellGoods(int amount) {
		CommandSellGoods sellGoods = new CommandSellGoods(amount);
	}
	/**
	 * Creates a new command object with the amount to be bought
	 * @param amount The amount of food wanting to be sold
	 */
	public static void sellFood(int amount) {
		CommandSellFood sellFood = new CommandSellFood(amount);
	}
	
}
