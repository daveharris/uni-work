/*
 * Created on May 16, 2005
 */
package nz.ac.vuw.mcs.comp301.model;

import java.util.Iterator;
import java.util.Vector;

import nz.ac.vuw.mcs.comp301.controller.CityScapePlay;
import nz.ac.vuw.mcs.comp301.model.development.Development;
import nz.ac.vuw.mcs.comp301.model.development.Wonder;
import nz.ac.vuw.mcs.comp301.model.events.KnowledgeEvent;

/**
 * This holds all knowledge that is available, and what has been built
 * A singleton class
 * @author harrisdavi3
 */
public class KnowledgeWonderStore {
	
	private static Vector knowledgeAvailableWonder = new Vector();
	private static Vector knowledgeBuiltWonder = new Vector();
		
	private static KnowledgeWonderStore kStore;
	
	/**
	 * If there is there is no current KnowledgeStore, then make a new one
	 */
	public static void createKnowledgeStore() {
		if (kStore != null) {
			kStore = new KnowledgeWonderStore();
		}
	}

	/**
	 * @return The current knowledge store, or makes a new one if one not available
	 */
	public static KnowledgeWonderStore getKnowledgeStore() {
		if (kStore != null) {
			return kStore;
		}
		else {
			kStore = new KnowledgeWonderStore();
			return kStore;
		}
	}
	
	/**
	 * Checks if the knowledge of the wonder if available
	 * @param knowledge The string of the new knowldge
	 * @return True if the knowledge is available 
	 */
	public boolean knowledgeAvailable(String knowledge) {
		if(knowledgeAvailableWonder.contains(knowledge))
			return true;
		return false;
	}
	
	/**
	 * Adds the knowledge to the available wonder list
	 * @param knowledge The string of the new knowledge
	 */
	public void addAvailableWonder(String knowledge) {
		if(!knowledgeAvailable(knowledge)) {
			knowledgeAvailableWonder.addElement(knowledge);
		}
	}
	
	/**
	 * Removes the wonder from the available list
	 * @param knowledge The string of the knowledge to be removed
	 */
	public void removeAvailableWonder(String knowledge) {
		if(knowledgeAvailable(knowledge)) {
			CityScapePlay.getListeners().notifyKnowledgeListeners(new KnowledgeEvent(knowledge, KnowledgeEvent.REMOVE));
		}
	}
	
	
	/**
	 * Checks if the knowledge of the wonder has been built
	 * @param wonderName The name of the wonder
	 * @return True if the wonder is in the built list
	 */
	public boolean knowledgeBuilt(String wonderName) {
		if(knowledgeBuiltWonder.contains(wonderName))
			return true;
		return false;
	}
	
	/**
	 * Add the new wonder to the built list
	 * @param wonder The wonder that is being built
	 */
	public void addBuiltWonder(Wonder wonder) {
		Development dev = (Development) wonder;
		knowledgeBuiltWonder.addElement(wonder);	
	}
	
	/**
	 * Removes the wonder from the built list
	 * @param wonder the wonder to be deleted
	 */
	public void removeBuiltWonder(Wonder wonder) {
		Development dev = (Development) wonder;
		if(knowledgeBuilt(dev.getName())) {
			CityScapePlay.getListeners().notifyKnowledgeListeners(new KnowledgeEvent(dev.getName(), KnowledgeEvent.REMOVE));
		}
	}
	
	/**
	 * @return An iterator for the built list
	 */
	public Iterator getKnowledgeBuiltIterator() {
		return knowledgeBuiltWonder.iterator();
	}
}
