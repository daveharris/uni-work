/*
 * Created on May 19, 2005
 */
package nz.ac.vuw.mcs.comp301.model;

import nz.ac.vuw.mcs.comp301.controller.CityScapePlay;
import nz.ac.vuw.mcs.comp301.model.development.Development;
import nz.ac.vuw.mcs.comp301.model.events.EnvironmentalEvent;

/**
 * Handles the pollution for the node. It calculates the pollution for the current node
 * and the pollution of the nodes around it.
 * @author harrisdavi3
 */
public class Pollution {
	
	/**
	 * Calculate the pollution of the given node and the surrounding nodes
	 * @param x The x co-ordinate of the node
	 * @param y The y co-ordinate of the node
	 * @param development The type of development at the given node
	 */
	public static void showPollution(int x, int y, Development development) {
		int amount = development.getPollution(development.getLevel());
		//if x is odd
		if(x%2 == 1) {
			EnvironmentalEvent middle = new EnvironmentalEvent(x, y, amount, EnvironmentalEvent.POLLUTION);
			EnvironmentalEvent top = new EnvironmentalEvent(x, y-1, amount/2, EnvironmentalEvent.POLLUTION);
			EnvironmentalEvent topRight = new EnvironmentalEvent(x+1, y, amount/2, EnvironmentalEvent.POLLUTION);
			EnvironmentalEvent bottomRight = new EnvironmentalEvent(x+1, y+1, amount/2, EnvironmentalEvent.POLLUTION);
			EnvironmentalEvent bottom = new EnvironmentalEvent(x, y+1, amount/2, EnvironmentalEvent.POLLUTION);
			EnvironmentalEvent bottomLeft = new EnvironmentalEvent(x-1, y+1, amount/2, EnvironmentalEvent.POLLUTION);
			EnvironmentalEvent topLeft = new EnvironmentalEvent(x-1, y, amount/2, EnvironmentalEvent.POLLUTION);
			
			CityScapePlay.getListeners().notifyEnvironmentalListeners(middle);
			CityScapePlay.getListeners().notifyEnvironmentalListeners(top);
			CityScapePlay.getListeners().notifyEnvironmentalListeners(topRight);
			CityScapePlay.getListeners().notifyEnvironmentalListeners(bottomRight);
			CityScapePlay.getListeners().notifyEnvironmentalListeners(bottom);
			CityScapePlay.getListeners().notifyEnvironmentalListeners(bottomLeft);
			CityScapePlay.getListeners().notifyEnvironmentalListeners(topLeft);
		}
		//or if its even
		else {
			EnvironmentalEvent middle = new EnvironmentalEvent(x, y, amount, EnvironmentalEvent.POLLUTION);
			EnvironmentalEvent top = new EnvironmentalEvent(x, y-1, amount/2, EnvironmentalEvent.POLLUTION);
			EnvironmentalEvent topRight = new EnvironmentalEvent(x+1, y-1, amount/2, EnvironmentalEvent.POLLUTION);
			EnvironmentalEvent bottomRight = new EnvironmentalEvent(x+1, y, amount/2, EnvironmentalEvent.POLLUTION);
			EnvironmentalEvent bottom = new EnvironmentalEvent(x, y+1, amount/2, EnvironmentalEvent.POLLUTION);
			EnvironmentalEvent bottomLeft = new EnvironmentalEvent(x-1, y, amount/2, EnvironmentalEvent.POLLUTION);
			EnvironmentalEvent topLeft = new EnvironmentalEvent(x-1, y-1, amount/2, EnvironmentalEvent.POLLUTION);
			
			CityScapePlay.getListeners().notifyEnvironmentalListeners(middle);
			CityScapePlay.getListeners().notifyEnvironmentalListeners(top);
			CityScapePlay.getListeners().notifyEnvironmentalListeners(topRight);
			CityScapePlay.getListeners().notifyEnvironmentalListeners(bottomRight);
			CityScapePlay.getListeners().notifyEnvironmentalListeners(bottom);
			CityScapePlay.getListeners().notifyEnvironmentalListeners(bottomLeft);
			CityScapePlay.getListeners().notifyEnvironmentalListeners(topLeft);
		}		
	}
}
