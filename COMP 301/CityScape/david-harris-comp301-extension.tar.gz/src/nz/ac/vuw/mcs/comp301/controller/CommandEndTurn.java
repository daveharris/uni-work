/*
 * Created on Apr 4, 2005
 */
package nz.ac.vuw.mcs.comp301.controller;

import java.util.Iterator;

import nz.ac.vuw.mcs.comp301.model.CityState;
import nz.ac.vuw.mcs.comp301.model.KnowledgeWonderStore;
import nz.ac.vuw.mcs.comp301.model.MarketState;
import nz.ac.vuw.mcs.comp301.model.ModelData;
import nz.ac.vuw.mcs.comp301.model.events.GameStateEvent;
import nz.ac.vuw.mcs.comp301.model.events.MarketEvent;
import nz.ac.vuw.mcs.comp301.view.gui.GUIController;
import nz.ac.vuw.mcs.comp301.model.development.*;


/**
 * Calculates the endturn figures, and checks to see if
 * the player has won or lost
 * @author harrisdavi3
 * @see nz.ac.vuw.mcs.comp301.model.ModelData
 */
public class CommandEndTurn extends Command {
	
	public CommandEndTurn() {
		
	}
	
	/**
	 * Calculates the various figures
	 */
	public void execute() {
		double effiency = ModelData.calculateEffiency();
		ModelData.calculateIncome();
		
		if(MarketState.getFood() < 1)
			MarketState.setFood(1);
		else if(MarketState.getGoods() < 1)
			MarketState.setGoods(1);
		
		ModelData.setStoreFood((int) (ModelData.getStoreFood() + ModelData.getMaxFood()*effiency));
		ModelData.setStoreGoods((int) (ModelData.getStoreGoods() + ModelData.getMaxGoods()*effiency));
		ModelData.setStoreFood(ModelData.getStoreFood() - ModelData.getPopulation());
		
		MarketState.setGoods((int) (MarketState.getGoods() + ModelData.getMaxGoods()*MarketState.getGoodsExchangeRate()));
		MarketState.calculateGoodsExchangeRate();
		MarketEvent setGoodsExchangeRate = new MarketEvent(MarketState.getGoodsExchangeRate(),
				MarketEvent.GOODS_X_RATE);
		CityScapePlay.getListeners().notifyMarketListeners(setGoodsExchangeRate);
		
		MarketState.calculateFoodExchangeRate();
		MarketState.setFood((int) (MarketState.getFood() + ModelData.getMaxFood()*MarketState.getFoodExchangeRate()));
		MarketEvent setFoodExchangeRate1 = new MarketEvent(MarketState.getFoodExchangeRate(),
				MarketEvent.FOOD_X_RATE);
		CityScapePlay.getListeners().notifyMarketListeners(setFoodExchangeRate1);
		
		MarketState.calculateFoodExchangeRate();
		MarketState.setFood( (int) (MarketState.getFood() - ModelData.getPopulation()*MarketState.getFoodExchangeRate()));
		MarketEvent setFoodExchangeRate2 = new MarketEvent(MarketState.getFoodExchangeRate(),
				MarketEvent.FOOD_X_RATE);
		CityScapePlay.getListeners().notifyMarketListeners(setFoodExchangeRate2);		
		
		MarketState.setBalance(MarketState.getBalance() - ModelData.getUpkeep());
		MarketState.setBalance(MarketState.getBalance() + ModelData.getIncome());
				
		int store = ModelData.getStoreGoods();
		if(store < 0) {
			ModelData.setBalance(ModelData.getBalance() + store);
			ModelData.setStoreGoods(0);
		}
		
		ModelData.setStoreFood(ModelData.getStoreFood() - ModelData.getPopulation());
		store = ModelData.getStoreFood();
		if(store < 0) {
			ModelData.setBalance(ModelData.getBalance() + store);
			ModelData.setStoreFood(0);
		}
		
		int health = ModelData.calculateHealth();
		ModelData.setPopulation(ModelData.getPopulation() + ModelData.getPopulation()*health/100);
		ModelData.calculateHappiness();

		KnowledgeWonderStore kStore = KnowledgeWonderStore.getKnowledgeStore();
		Iterator knowledge = kStore.getKnowledgeBuiltIterator();
		while (knowledge.hasNext()) {
			Development dev = (Development) knowledge.next();
			Wonder wonder = (Wonder) dev;
			wonder.endTurnEffect();
		}
		
		CityState.update();
		
		if(ModelData.getBalance() < -1000 || ModelData.getHappiness() < -90) {
			GameStateEvent gameEvent = new GameStateEvent(GameStateEvent.LOST, GUIController.getPlayerName());
			CityScapePlay.getListeners().notifyGameListeners(gameEvent);
		}
		else if(ModelData.getBalance() > 10000 || ModelData.getHappiness() > 90) {
			GameStateEvent gameEvent = new GameStateEvent(GameStateEvent.WON, GUIController.getPlayerName());
			CityScapePlay.getListeners().notifyGameListeners(gameEvent);
		}
	}
}
