/*
This file is part of the SMSCS VUW Comp301 CityScape GUI library.

SMSCS VUW Comp301 CityScape GUI ibrary is free software; you can redistribute it
and/or modify it under the terms of version 2 of the GNU General Public License as
published by the Free Software Foundation.

The SMSCS VUW Comp301 CityScape GUI library is distributed in the hope that it will 
be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General
Public License for more details.

You should have received a copy of the GNU General Public License along with
SMSCS VUW Comp301 CityScape GUI library; if not, write to the Free Software Foundation,
Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
*/


package nz.ac.vuw.mcs.comp301.view.gui;

import java.awt.Color;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import javax.swing.border.EtchedBorder;

import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JPanel;
import javax.swing.JComboBox;
import nz.ac.vuw.mcs.comp301.model.events.MarketEvent;
import nz.ac.vuw.mcs.comp301.model.events.MarketListener;
import nz.ac.vuw.mcs.comp301.view.gui.events.TradeListener;
import nz.ac.vuw.mcs.comp301.view.gui.events.TradeEvent;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import java.util.List;
import java.util.Vector;
import java.util.Iterator;

/**
 * <p>A view that displays up to date information regarding the game's market. Implements the 
 * MarketListener interface so that it can told of changes to the market. Implements the ActionListener 
 * interface so that it can react when players attempt to buy or sell food or goods.</p>
 * <p>Displays the current exchange rates for food and goods, and also provides input capabilities
 *  to specify an action (i.e. buy or sell), a target (i.e food or goods), and an amount.</p>
 * 
 * @version $Revision: 1.2 $
 * @author $Author: harrisdavi3 $, $Date: 2005/05/19 05:17:04 $
 * @see nz.ac.vuw.mcs.comp301.model.events.MarketListener
 */
public class MarketView extends JPanel implements MarketListener, ActionListener {

	public final static long serialVersionUID = 1; 
	
	public MarketView() {
		super();
		
		GridBagLayout layout = new GridBagLayout();
		GUIUtilities utilities = GUIUtilities.getGUIUtilities();
		Color foreground = utilities.getColour("market");
		Color background = utilities.getColour("background");
		this.setBorder(new EtchedBorder(Color.black, Color.red));
		this.setBackground(background);
		this.setLayout(layout);
		
		utilities.createHeader(this, "Market", foreground);
		this._foodExchange = utilities.createLabel(this, "Food Exchange Rate:", foreground);
		this._goodsExchange = utilities.createLabel(this, "Goods Exchange Rate:", foreground);
		this.setupTradeOption();
		
		this._listeners = new Vector();
		
		this.setVisible(true);
		return;
	}
	
	
	/** 
	 * <p>
	 * React to the player entering in an amount of some item that they want to buy or sell.
	 * Determines the nature of the player's request, and then creates a corresponding 
	 * TradeEvent object that is passed to TradeListeners for further parsing.
	 * </p>
	 * 
	 * @see java.awt.event.ActionListener#actionPerformed(java.awt.event.ActionEvent)
	 * @see nz.ac.vuw.mcs.comp301.view.gui.events.TradeListener
	 * @see nz.ac.vuw.mcs.comp301.view.gui.events.TradeEvent
	 */
	public void actionPerformed(ActionEvent event) {
		String action = (String)this._action.getSelectedItem();
		String target = (String)this._target.getSelectedItem();
		int amount = Integer.parseInt(this._amount.getText());
		TradeEvent tradeEvent = null;
		
		if (action.equals("Buy")) {
			if (target.equals("Food")) {
				tradeEvent = new TradeEvent(amount, TradeEvent.BUY, TradeEvent.FOOD);				
			} 
			else if (target.equals("Goods")) {
				tradeEvent = new TradeEvent(amount, TradeEvent.BUY, TradeEvent.GOODS);
			}
		} 
		else if (action.equals("Sell")) {
			if (target.equals("Food")) {
				tradeEvent = new TradeEvent(amount, TradeEvent.SELL, TradeEvent.FOOD);				
			} 
			else if (target.equals("Goods")) {
				tradeEvent = new TradeEvent(amount, TradeEvent.SELL, TradeEvent.GOODS);
			}
		}
		
		if (tradeEvent != null) {
			this.notifyListeners(tradeEvent);	
		}
		return;
	}
	
	/**
	 * @param listener A new listener to register, and to inform when TradeEvents are created.
	 */
	public void addTradeListener(TradeListener listener) {
		this._listeners.add(listener);
		return;
	}
	
	/**
	 * <p>
	 * Sets up the interface necessary for specifying the buying or selling of goods.
	 * </p>
	 * <p>
	 * Creates two combo boxes that are used to specify the action and the target, and also creates 
	 * a text field for inputing the amount. The interface reacts to the trade request when the player hits the return key 
	 * in the text field.
	 * </p>
	 */
	public void setupTradeOption() {
		this._action = new JComboBox();
		this._target = new JComboBox();
		this._amount = new JTextField(10);
			
		this._action.addItem("Buy");
		this._action.addItem("Sell");
		this._target.addItem("Food");
		this._target.addItem("Goods");
		this._amount.setText("0");
			
		GridBagLayout layout = (GridBagLayout)this.getLayout();
		GridBagConstraints constraints = new GridBagConstraints();
			
		this._amount.setOpaque(true);
		constraints.fill = GridBagConstraints.BOTH;
		constraints.weightx = 1.0;
		constraints.gridwidth = 1;
		layout.setConstraints(this._action, constraints);
		layout.setConstraints(this._target, constraints);
		constraints.gridwidth = GridBagConstraints.REMAINDER;
		layout.setConstraints(this._amount, constraints);
		this.add(this._action);
		this.add(this._target);
		this.add(this._amount);
	
		this._amount.addActionListener(this);
		
		return;
	}
	
	/**
	 * <p>
	 * React to a change to the market's exchange rates by displaying the up to date 
	 * rate in the correct label on the screen.
	 * </p>
	 * 
	 * @param event An object representing a single change to a single rate in the market.  
	 * @see nz.ac.vuw.mcs.comp301.model.events.MarketListener#marketModified(nz.ac.vuw.mcs.comp301.model.events.MarketEvent)
	 */
	public void marketModified(MarketEvent event) {
		int eventType = event.getType();
		double newRate = event.getRate();
		switch (eventType) {
			case MarketEvent.FOOD_X_RATE:
				this._foodExchange.setText(Double.toString(newRate));
				break;
			case MarketEvent.GOODS_X_RATE:
				this._goodsExchange.setText(Double.toString(newRate));
				break;
			}
		return;
	}

	private void notifyListeners(TradeEvent event) {
		Iterator listeners = this._listeners.iterator();
		while (listeners.hasNext()) {
			TradeListener listener = (TradeListener)listeners.next();
			listener.tradeRequested(event);
		}
		return;
	}
	
	private JLabel _goodsExchange;
	private JLabel _foodExchange;
	private JTextField _amount;
	private JComboBox _action;
	private JComboBox _target;
	private List _listeners;
	
}

