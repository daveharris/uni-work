/*
 * Created on Apr 4, 2005
 */
package nz.ac.vuw.mcs.comp301.controller;

/**
 * Un-implemented
 * @author harrisdavi3

 */
public class CommandParse extends Command {
	
	public CommandParse() {
		
	}

	public void execute() {

	}

	public void addSubCommand(Command subCommand) {

	}

	public void removeSubCommand(Command subCommand) {


	}
}
