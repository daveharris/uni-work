/*
 * Created on Apr 4, 2005
 */
package nz.ac.vuw.mcs.comp301.controller;

import nz.ac.vuw.mcs.comp301.model.events.FinancialEvent;

/**
 * Sets the taxrate to be used and displayed
 * @author harrisdavi3
 */
public class CommandTax extends Command {
	
	private int _taxRate;
	
	/**
	 * Initalises the taxrate
	 * @param taxRate The new tax rate
	 */
	public CommandTax(int taxRate) {
		this._taxRate = taxRate;
	}

	/**
	 * Creates a new taxrate FinancialEvent and then
	 * notifies listeners
	 */
	public void execute() {
		FinancialEvent fEvent = new FinancialEvent(this._taxRate, FinancialEvent.TAX_RATE);
		CityScapePlay.getListeners().notifyFinancialListeners(fEvent);
	}
}
