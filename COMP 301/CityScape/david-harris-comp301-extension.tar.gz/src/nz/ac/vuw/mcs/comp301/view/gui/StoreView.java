/*
This file is part of the SMSCS VUW Comp301 CityScape GUI library.

SMSCS VUW Comp301 CityScape GUI ibrary is free software; you can redistribute it
and/or modify it under the terms of version 2 of the GNU General Public License as
published by the Free Software Foundation.

The SMSCS VUW Comp301 CityScape GUI library is distributed in the hope that it will 
be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General
Public License for more details.

You should have received a copy of the GNU General Public License along with
SMSCS VUW Comp301 CityScape GUI library; if not, write to the Free Software Foundation,
Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
*/


package nz.ac.vuw.mcs.comp301.view.gui;

import java.awt.Color;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import javax.swing.border.EtchedBorder;

import javax.swing.JLabel;
import javax.swing.JPanel;
import nz.ac.vuw.mcs.comp301.model.events.StoreEvent;
import nz.ac.vuw.mcs.comp301.model.events.StoreListener;

/**
 * <p>A view of the city's store. The view provides information on the amount of 
 * goods and food that the city has, and on the maximum amount of goods and food that 
 * the existing industrial and agricultural developments can create per turn. This view 
 * implements the StoreListener interface so that it can be told about updates to the city's 
 * store.
 * </p>
 *
 * @version $Revision: 1.1 $
 * @author $Author: harrisdavi3 $, $Date: 2005/04/04 03:41:58 $
 * @see nz.ac.vuw.mcs.comp301.model.events.StoreListener
 */
public class StoreView extends JPanel implements StoreListener {

	public final static long serialVersionUID = 1;
	
	/**
	 * <p>
	 * A constructor that sets up the view to contain the relevant labels.
	 * Uses GUIUtilities
	 * </p>
	 * 
	 * @see nz.ac.vuw.mcs.comp301.view.gui.GUIUtilities
	 */
	public StoreView() {
		super();
		
		GridBagLayout layout = new GridBagLayout();
		GridBagConstraints constraints = new GridBagConstraints();
		GUIUtilities utilities = GUIUtilities.getGUIUtilities();
		Color foreground = utilities.getColour("store");
		Color background = utilities.getColour("background");
		this.setBorder(new EtchedBorder(Color.black, Color.red));
		this.setBackground(background);
		this.setLayout(layout);
		
		utilities.createHeader(this, "Store", foreground);
		this._goods = utilities.createLabel(this, "Goods:", foreground);
		this._food = utilities.createLabel(this, "Food:", foreground);
		this._maxGoods = utilities.createLabel(this, "Max Goods / Turn:", foreground);
		this._maxFood = utilities.createLabel(this, "Max Food / Turn:", foreground);
		this.setVisible(true);
		return;
	}
	
	/* 
	 * <p>
	 * Reacts to a change in one aspect of the city store by changing the value displayed in the associated label.
	 * </p>
	 * 
	 * @param event An object that represents a single change to a single aspect of the city' store.
	 * @see nz.ac.vuw.mcs.comp301.model.events.StoreListener#storeModified(nz.ac.vuw.mcs.comp301.model.events.StoreEvent)
	 */
	public void storeModified(StoreEvent event) {
		int eventType = event.getType();
		int newAmount = event.getAmount();
		switch (eventType) {
			case StoreEvent.GOODS:
				this._goods.setText(Integer.toString(newAmount));
				break;
			case StoreEvent.FOOD:
				this._food.setText(Integer.toString(newAmount));
				break;
			case StoreEvent.MAX_FOOD:
				this._maxFood.setText(Integer.toString(newAmount));
				break;
			case StoreEvent.MAX_GOODS:
				this._maxGoods.setText(Integer.toString(newAmount));
				break;
			}
		return;
	}

	private JLabel _goods;
	private JLabel _food;
	private JLabel _maxGoods;
	private JLabel _maxFood;
	
}
