/*
 * Created on May 15, 2005

 */
package nz.ac.vuw.mcs.comp301.model.development;

import nz.ac.vuw.mcs.comp301.controller.CityScapePlay;
import nz.ac.vuw.mcs.comp301.model.ModelData;
import nz.ac.vuw.mcs.comp301.model.events.WonderEvent;

/**
 * Holds the information and variables to do with hospital.
 * It implements the wonder interface, which implements the development interface 
 * @author harrisdavi3
 */
public class HospitalWonder implements Wonder {

	private boolean _used;
	private String _name;
	
	private int _cost;
	private int _upkeep;
	private int _pollution;
	private int _socialWorth;
	private int _jobs;
	
	/**
	 * Initalises the variables to the correct values
	 */
	public HospitalWonder() {
		_used = true;
		_name = "Hospital";
		
		_cost = 250;
		_upkeep = 50;
		_pollution = 5;
		_socialWorth = 15;
		_jobs = 50;
	}
	
	public String getName() {
		return _name;
	}
	public int getLevel() {
		return 1;
	}
	public int getCost(int level) {
		return _cost;
	}
	public int getUpkeep(int level) {
		return _upkeep;
	}
	public int getPollution(int level) {
		return _pollution;
	}
	public int getSocialWorth(int level) {
		return _socialWorth;
	}
	public int getJobs(int level) {
		return _jobs;
	}
	/**
	 * Calculates the endturn effect of building a hopsital wonder
	 * Creates a WonderEvent based on thses, and notifies the listeners
	 */
	public void endTurnEffect() {
		int top = 100;
		int bottom = 10;
		int randomNum = (int)(Math.random()*(top-bottom))+bottom;
		ModelData.setPopulation(ModelData.getPopulation() + randomNum);
		WonderEvent event = new WonderEvent("The Hospital has saved " + randomNum + " lives",
				randomNum, WonderEvent.PEOPLE);
		CityScapePlay.getListeners().notifyWonderListeners(event);
	}

	public void incrementCounter() {
	}
	
	public void advanceCounter() {
	}

	public String upgradeDevelopment() {
		return "Hospital";
	}
	
	public String getClassification() {
		return "wonder";
	}
	
	public int getHighestLevel() {
		return 1;
	}
}
