/*
 * Created on Apr 4, 2005
 */
package nz.ac.vuw.mcs.comp301.controller;

import java.io.*;

import nz.ac.vuw.mcs.comp301.model.CityState;
import nz.ac.vuw.mcs.comp301.model.development.*;
import nz.ac.vuw.mcs.comp301.model.events.*;

/**
 * Creates the map and creates empty developments
 * at every node at the positions as specified in the map
 * @author harrisdavi3
 */
public class CommandStart extends Command {
	private String _playerName;
	private String _mapName;
	private int width;
	private int height;
	
	/**
	 * Initalises values
	 * @param playerName The playername
	 * @param mapName The location of the map to be read in
	 */
	public CommandStart(String playerName, String mapName) {
		this._playerName = playerName;
		this._mapName = mapName;
	}
	
	/**
	 * Registers and notifies listeners
	 * Read in map and then create empty developments
	 * and then add then to the array of objects
	 */
	public void execute() {
		try {
			CityScapePlay.registerListeners();
			CityScapePlay.notifyListeners();
			int space;
			FileReader inStream = new FileReader(this._mapName);
			BufferedReader ins = new BufferedReader(inStream);
			
			String dataline = ins.readLine();
			
			space = dataline.indexOf(' ');
			width = Integer.parseInt(dataline.substring(0, space));
			height = Integer.parseInt(dataline.substring(space+1, dataline.length()));
			CommandBuild.setSize(width, height);
			dataline = ins.readLine();
			
			for(int i=0; i<width; i++) {
				for(int j=0; j<height;j++) {
					Development waterDevelopemnt = new WaterDevelopment();
					CommandBuild.addDevelopment(i, j, waterDevelopemnt);
				}					
			}
			
			while(dataline != null) {
				space = dataline.indexOf(' ');
				int x = Integer.parseInt(dataline.substring(0, space));
				int y = Integer.parseInt(dataline.substring(space+1));
				if(x <= width && y <= height) {
					LandEvent newLandEvent = new LandEvent(x, y, LandEvent.ADDED);
					CityScapePlay.getListeners().notifyLandListeners(newLandEvent);
					
					Development emptyDevelopment = new EmptyDevelopment();
					DevelopmentEvent newDevelopmentEvent = new DevelopmentEvent(emptyDevelopment, x, y, DevelopmentEvent.ADDED);
					CityScapePlay.getListeners().notifyDevelopmentListeners(newDevelopmentEvent);
					
					EnvironmentalEvent pollution = new EnvironmentalEvent(x, y, 0, EnvironmentalEvent.POLLUTION);
					CityScapePlay.getListeners().notifyEnvironmentalListeners(pollution);
					
					CommandBuild.addDevelopment(x, y, emptyDevelopment);					
				}
				dataline = ins.readLine();
			}
			MarketEvent setGoodsExchangeRate = new MarketEvent(1.0, MarketEvent.GOODS_X_RATE);
			MarketEvent setFoodExchangeRate = new MarketEvent(1.0, MarketEvent.FOOD_X_RATE);
			CityScapePlay.getListeners().notifyMarketListeners(setGoodsExchangeRate);
			CityScapePlay.getListeners().notifyMarketListeners(setFoodExchangeRate);
			
			ins.close();
			CityState.update();
		}
		
		catch (IOException ex) {
			System.out.println("IO Error:  " + ex.getMessage());
			ex.printStackTrace();
		}		
	}
}
