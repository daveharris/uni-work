/*
This file is part of the SMSCS VUW Comp301 CityScape GUI library.

SMSCS VUW Comp301 CityScape GUI ibrary is free software; you can redistribute it
and/or modify it under the terms of version 2 of the GNU General Public License as
published by the Free Software Foundation.

The SMSCS VUW Comp301 CityScape GUI library is distributed in the hope that it will 
be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General
Public License for more details.

You should have received a copy of the GNU General Public License along with
SMSCS VUW Comp301 CityScape GUI library; if not, write to the Free Software Foundation,
Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
*/


package nz.ac.vuw.mcs.comp301.view.gui;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.EtchedBorder;

import nz.ac.vuw.mcs.comp301.model.ModelData;
import nz.ac.vuw.mcs.comp301.model.events.FinancialEvent;
import nz.ac.vuw.mcs.comp301.model.events.FinancialListener;
import javax.swing.JSlider;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.awt.Color;

/**
 * <p>A view of the city's finances. This view provides information on the amount of money the city has, 
 * the total amount of upkeep payable per turn, and the current tax rate. The player may modify the tax rate. 
 * This view implements the FinancialListener interface so that it can told about updates to the city's treasury.
 * </p>
 * <p>
 * This view uses GUIUtilities to create the labels.
 * </p>
 *
 * @version $Revision: 1.3 $
 * @author $Author: harrisdavi3 $, $Date: 2005/05/02 09:49:23 $
 * @see nz.ac.vuw.mcs.comp301.model.events.FinancialListener
 * @see nz.ac.vuw.mcs.comp301.view.gui.GUIUtilities
 */
public class TreasuryView extends JPanel implements FinancialListener {

	public final static long serialVersionUID = 1;
	
	/**
	 * <p>This constructor sets up the view's interface, and registers the GUIController object as a 
	 * listener to the tax rate slider.</p>
	 * 
	 * @param controller The GUIController object that will react to the player modifying the tax 
	 * rate slider. 
	 */
	public TreasuryView(GUIController controller) {
		super();
		
		this._controller = controller;
		
		GridBagLayout layout = new GridBagLayout();
		GridBagConstraints constraints = new GridBagConstraints();
		GUIUtilities utilities = GUIUtilities.getGUIUtilities();
		Color foreground = utilities.getColour("treasury");
		Color background = utilities.getColour("background");
		this.setBorder(new EtchedBorder(Color.black, Color.red));
		this.setBackground(background);
		this.setLayout(layout);
		
		utilities.createHeader(this, "Treasury", foreground);
		this._taxRate = utilities.createLabel(this, "Tax Rate:", foreground);
		
		constraints.weightx = 1.0;
		constraints.fill = GridBagConstraints.HORIZONTAL;
		constraints.gridwidth = GridBagConstraints.REMAINDER;
		this._taxRateSelector = new JSlider(0, 100, 20);
		this._taxRateSelector.addChangeListener(this._controller);
		layout.setConstraints(this._taxRateSelector, constraints);
		this.add(this._taxRateSelector);
		
		this._balance = utilities.createLabel(this, "Balance:", foreground);
		this._upkeep = utilities.createLabel(this, "Upkeep:", foreground);
		
		this.setVisible(true);
		return;
	}
	
	/* 
	 * <p>
	 * Reacts to updates from the city's treasury by updating the amount that is displayed on the 
	 * screen.
	 * </p>
	 * <p>
	 * If we modify the value of the tax rate selector, then it will fire off an event to the 
	 * listeners. We do not want them to be notified, since this is an update from the engine and not 
	 * from the player. We remove the only known listener before the change, and add them back again 
	 * after the change. This is a nasty hack, since the disableEvents method didn't seem to have 
	 * any effect.
	 * </p>
	 * 
	 * @param event An object representing a single change to a single aspect of the city's treasury.
	 * @see nz.ac.vuw.mcs.comp301.model.events.FinancialListener#financesModified(nz.ac.vuw.mcs.comp301.model.events.FinancialEvent)
	 */
	public void financesModified(FinancialEvent event) {
		int eventType = event.getType();
		int newAmount = event.getAmount();
		switch (eventType) {
			case FinancialEvent.BALANCE:
				this._balance.setText(Integer.toString(newAmount));
				ModelData.setBalance(newAmount);
				break;
			case FinancialEvent.TAX_RATE:
				this._taxRate.setText(Integer.toString(newAmount));
				this._taxRateSelector.removeChangeListener(this._controller);
				this._taxRateSelector.setValue(newAmount);
				this._taxRateSelector.addChangeListener(this._controller);
				ModelData.setTaxRate(newAmount);
				break;
			case FinancialEvent.UPKEEP:
				this._upkeep.setText(Integer.toString(newAmount));
				ModelData.setUpkeep(newAmount);
				break;
		}
		return;
	}

	private JLabel _taxRate;
	private JLabel _balance;
	private JLabel _upkeep;
	private JSlider _taxRateSelector;
	private GUIController _controller;
	
}
