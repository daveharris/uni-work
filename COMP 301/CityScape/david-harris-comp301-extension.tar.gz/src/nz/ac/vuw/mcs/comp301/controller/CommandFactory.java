/*
This file is part of the SMSCS VUW Comp301 CityScape GUI library.

SMSCS VUW Comp301 CityScape GUI ibrary is free software; you can redistribute it
and/or modify it under the terms of version 2 of the GNU General Public License as
published by the Free Software Foundation.

The SMSCS VUW Comp301 CityScape GUI library is distributed in the hope that it will 
be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General
Public License for more details.

You should have received a copy of the GNU General Public License along with
SMSCS VUW Comp301 CityScape GUI library; if not, write to the Free Software Foundation,
Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
*/

package nz.ac.vuw.mcs.comp301.controller;

import java.io.BufferedReader;

/**
 * <p>
 * An interface for a factory that creates commands. There is a single method for 
 * each type of command that can be created. Commands are typically created by 
 * supplying context-dependent parameters. However, the factory should also be able 
 * to construct commands from a String that is correctly formatted in a particular fashion. 
 * </p>
 * 
 * @version $Revision: 1.1 $
 * @author $Author: harrisdavi3 $, $Date: 2005/04/04 03:41:59 $
 * @see nz.ac.vuw.mcs.comp301.controller.Command
 */
public interface CommandFactory {
	
	/**
	 * <p>
	 * Constructs a command that will cause this player to exit the game.
	 * </p>
	 * 
	 * @return A command object representing the exit instruction.
	 */
	public abstract Command createExitCommand();

	/**
	 * <p>
	 * Constructs a command that will result in a development being built at a 
	 * particular node in the map.
	 * </p>
	 * 
	 * @param x The x location of the map node.
	 * @param y The y location of the map node.
	 * @param developmentName The name of the development to be built.
	 * @return A command object representing the build instruction.
	 */
	public abstract Command createBuildCommand(int x, int y, String developmentName);

	
	/**
	 * <p>
	 * Constructs a command that will result in the player finishing their turn.
	 * </p>
	 * 
	 * @return A command object representing the end turn instruction.
	 */
	public abstract Command createEndTurnCommand();
	
	/**
	 * <p>
	 * Constructs a command that will result in the player starting a new game. 
	 * </p>
	 * 
	 * @param playerName The name of the player.
	 * @param mapName The name of the file that contains the map information for the new city.
	 * @return A command object representing the start instruction.
	 */
	public abstract Command createStartCommand(String playerName, String mapName);
	
	/**
	 * <p>
	 * Constructs a command that will modify the tax rate for the player's city.
	 * </p>
	 * 
	 * @param taxRate The new tax rate: should be between 0-100.
	 * @return A command object representing the set tax rate instruction.
	 */
	public abstract Command createTaxCommand(int taxRate);

	/**
	 * <p>
	 * Constructs a command that will replay a sequence of commands encoded in an input stream.
	 * </p>
	 * 
	 * @param input The input stream that contains a sequence of formatted strings that in turn represent commands.
	 * @return A command object representing the replay instruction. 
	 */
	public abstract Command createReplayCommand(BufferedReader input);
	
	/**
	 * <p>
	 * Constructs a command that will undo the last command performed, if that last command is undoable.
	 * </p>
	 * 
	 * @return A command object representing the undo instruction.
	 */
	public abstract Command createUndoCommand();

	/**
	 * <p>
	 * Constructs a command that will result in an amount of goods being bought at the market and placed in the city's store.
	 * </p>
	 * 
	 * @param amount The amount of goods to purchase.
	 * @return A command object representing the buy goods instruction.
	 */
	public abstract Command createBuyGoodsCommand(int amount);
	
	/**
	 * <p>
	 * Constructs a command that will result in an amount of goods being taken from the city's store and sold in the market.
	 * </p>
	 * 
	 * @param amount The amount of goods to sell.
	 * @return A command object representing the sell goods instruction.
	 */
	public abstract Command createSellGoodsCommand(int amount);
	
	/**
	 * <p>
	 * Constructs a command that will result in an amount of food being bought from the market and placed in the city's store.
	 * </p>
	 * 
	 * @param amount The amount of food to purchase.
	 * @return A command object representing the buy food instruction.
	 */
	public abstract Command createBuyFoodCommand(int amount);
	
	/**
	 * <p>
	 * Constructs a command that will result in an amount of food being taken from the city's store and sold at the market.
	 * </p>
	 * 
	 * @param amount The amount of food to sell.
	 * @return A command object representing the sell food instruction.
	 */
	public abstract Command createSellFoodCommand(int amount);
	
	
	/**
	 * <p>
	 * Constructs a command based on information extracted from a String object. The String must be 
	 * structured in a particular way, and this is described in more detail in the online game documentation.
	 * </p>
	 * 
	 * @param message A string formatted to represent one of the above commands.
	 * @return An object representing the command encoded into the message string.
	 */
	public abstract Command parseCommand(String message);
	
}