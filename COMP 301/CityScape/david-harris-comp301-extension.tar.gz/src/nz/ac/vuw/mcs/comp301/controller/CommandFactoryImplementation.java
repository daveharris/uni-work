/*
 * Created on Apr 5, 2005
 */
package nz.ac.vuw.mcs.comp301.controller;

import java.io.BufferedReader;

/**
 * Implements CommandFactory.
 * Creates new Command objects depending on what type is required
 * @author harrisdavi3
 */
public class CommandFactoryImplementation implements CommandFactory {

	/**
	 * Returns a new commandExit object
	 */
	public Command createExitCommand() {
		return new CommandExit();
	}

	/**
	 * Returns a new commandBuild object
	 */
	public Command createBuildCommand(int x, int y, String developmentName) {
		return new CommandBuild(x, y, developmentName);
	}

	/**
	 * Returns a new commandStart object
	 */
	public Command createEndTurnCommand() {
		return new CommandEndTurn();
	}

	/**
	 * Returns a new commandStart object
	 */
	public Command createStartCommand(String playerName, String mapName) {
		return new CommandStart(playerName, mapName);
	}

	/**
	 * Returns a new commandTax object
	 */
	public Command createTaxCommand(int taxRate) {
		return new CommandTax(taxRate);
	}
	/**
	 * Returns a new commandReplay object
	 * Un-implemented
	 */
	public Command createReplayCommand(BufferedReader input) {
		return new CommandReplay(input);
	}

	/**
	 * Returns a new commandUndo object
	 * Unimplemented
	 */
	public Command createUndoCommand() {
		return new CommandUndo();
	}

	/**
	 * Returns a new commandBuyGoods object
	 * Un-implemented
	 */
	public Command createBuyGoodsCommand(int amount) {
		return new CommandBuyGoods(amount);
	}

	/**
	 * Returns a new commandSellGoods object
	 * Un-implemented
	 */
	public Command createSellGoodsCommand(int amount) {
		return new CommandSellGoods(amount);
	}

	/**
	 * Returns a new commandBuyFood object
	 * Un-implemented
	 */
	public Command createBuyFoodCommand(int amount) {
		return new CommandBuyFood(amount);
	}

	/**
	 * Returns a new commandSellFood object
	 * Un-implemented
	 */
	public Command createSellFoodCommand(int amount) {
		return new CommandSellFood(amount);
	}

	/**
	 * Un-implemented, kept for consistency
	 */
	public Command parseCommand(String message) {
		return null;
	}

}
