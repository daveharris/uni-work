/*
 * Created on Apr 4, 2005
 */
package nz.ac.vuw.mcs.comp301.controller;

import nz.ac.vuw.mcs.comp301.model.CityState;
import nz.ac.vuw.mcs.comp301.model.MarketState;
import nz.ac.vuw.mcs.comp301.model.ModelData;

/**
 * Calculates the new figures when food is bought from the market
 * @author harrisdavi3
 */
public class CommandSellFood extends Command {
	
	int _amount;
	
	/**
	 * Initalises the amount to how much is wanting to be bought
	 * @param amount The amount wnating to be bought
	 */
	public CommandSellFood(int amount) {
		this._amount = amount;
	}

	/**
	 * Calculates the new values of food and balance
	 */
	public void execute() {
		ModelData.setStoreFood(ModelData.getStoreFood() - _amount);
		ModelData.setBalance(ModelData.getBalance() + _amount);
		CityState.update();
	}
}
