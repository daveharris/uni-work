/*
 * Created on May 18, 2005
 */
package nz.ac.vuw.mcs.comp301.model;

/**
 * This keeps information about the market, and methods to interact with the varibales
 * @author harrisdavi3
 */
public class MarketState {
	
	static int _goods = 1000;
	static int _food = 1000;
	static int _balance = 1000;
	
	static double _goodsExchangeRate = 1.0;
	static double _foodExchangeRate = 1.0;
		
	/**
	 * @return Returns the food.
	 */
	public static int getFood() {
		return _food;
	}
	/**
	 * @param food The food to set.
	 */
	public static void setFood(int food) {
		_food = food;
	}
	/**
	 * @return Returns the goods.
	 */
	public static int getGoods() {
		return _goods;
	}
	/**
	 * @param goods The goods to set.
	 */
	public static void setGoods(int goods) {
		_goods = goods;
	}
	/**
	 * @return Returns the foodExchangeRate.
	 */
	public static double getFoodExchangeRate() {
		return _foodExchangeRate;
	}
	/**
	 * Calculates the food exchange rate
	 */
	public static void calculateFoodExchangeRate() {
		_foodExchangeRate = ((double) (_balance)/(_food));
		System.out.println("balance: " + _balance + " food: " + _food + " food exchange rate: " + _foodExchangeRate);
	}
	/**
	 * @return Returns the goodsExchangeRate.
	 */
	public static double getGoodsExchangeRate() {
		return _goodsExchangeRate;
	}
	/**
	 * Calculates the goods exchange rate
	 */
	public static void calculateGoodsExchangeRate() {
		_goodsExchangeRate = ((double) (_balance)/(_goods));
		System.out.println("balance: " + _balance + " goods: " + _goods + " good exchange rate: " + _goodsExchangeRate);
	}
	
	/**
	 * @return Returns the balance.
	 */
	public static int getBalance() {
		return _balance;
	}
	/**
	 * @param balance The balance to set.
	 */
	public static void setBalance(int balance) {
		_balance = balance;
	}
}
