/*
 * Created on May 2, 2005
 */
package nz.ac.vuw.mcs.comp301.model;

import nz.ac.vuw.mcs.comp301.controller.CityScapePlay;
import nz.ac.vuw.mcs.comp301.model.events.FinancialEvent;
import nz.ac.vuw.mcs.comp301.model.events.PopulationEvent;
import nz.ac.vuw.mcs.comp301.model.events.StoreEvent;

/**
 * This updates the store, financial and population listeners and events.
 * Each time it is called, it ceates notifies the listeners so that the GUI is up-tp-date with the actual state
 * @author harrisdavi3
 * @see nz.ac.vuw.mcs.comp301.model.events
 */
public class CityState {
	
	/**
	 * Constructor, that only calls the update method
	 * This is done so that all listeners can be updtaed by calling the update method
	 */
	public CityState () {
		update();
	}
	
	/**
	 * Calls the three types methods which create and update the listeners
	 */
	public static void update() {
		financialUpdate();
		populationUpdate();
		storeUpdate();
	}
	
	/**
	 * Update the taxrate, the upkeep and the balance 
	 * Notifies listeners
	 */
	public static void financialUpdate() {
		FinancialEvent balanceFEvent = new FinancialEvent(ModelData.getBalance(), FinancialEvent.BALANCE);
		FinancialEvent upkeepFEvent = new FinancialEvent(ModelData.getUpkeep(), FinancialEvent.UPKEEP);
		FinancialEvent taxFEvent = new FinancialEvent(ModelData.getTaxRate(), FinancialEvent.TAX_RATE);
		
		CityScapePlay.getListeners().notifyFinancialListeners(balanceFEvent);
		CityScapePlay.getListeners().notifyFinancialListeners(upkeepFEvent);
		CityScapePlay.getListeners().notifyFinancialListeners(taxFEvent);
	}
	
	/**
	 * Updates the city statistics
	 * Notifies listeners
	 */
	public static void populationUpdate() {
		PopulationEvent peoplePEvent = new PopulationEvent(ModelData.getPopulation(), PopulationEvent.PEOPLE);
		PopulationEvent jobsPEvent = new PopulationEvent(ModelData.getJobs(), PopulationEvent.JOBS);
		PopulationEvent livingSpacePEvent = new PopulationEvent(ModelData.getLivingSpaces(), PopulationEvent.LIVING_SPACE);
		PopulationEvent happinessPEvent = new PopulationEvent(ModelData.getHappiness(), PopulationEvent.HAPPINESS);
		PopulationEvent healthPEvent = new PopulationEvent(ModelData.getHealth(), PopulationEvent.HEALTH);
		PopulationEvent lawPEvent = new PopulationEvent(ModelData.getLaw(), PopulationEvent.LAW);
		PopulationEvent enjoymentPEvent = new PopulationEvent(ModelData.getEnjoyment(), PopulationEvent.ENJOYMENT);
		
		CityScapePlay.getListeners().notifyPopulationListeners(peoplePEvent);
		CityScapePlay.getListeners().notifyPopulationListeners(jobsPEvent);
		CityScapePlay.getListeners().notifyPopulationListeners(livingSpacePEvent);
		CityScapePlay.getListeners().notifyPopulationListeners(happinessPEvent);
		CityScapePlay.getListeners().notifyPopulationListeners(healthPEvent);
		CityScapePlay.getListeners().notifyPopulationListeners(lawPEvent);
		CityScapePlay.getListeners().notifyPopulationListeners(enjoymentPEvent);
	}
	
	/**
	 * Updates the amount of food and goods in store
	 * Notifies listeners
	 */
	public static void storeUpdate() {
		StoreEvent goodsSEvent = new StoreEvent(ModelData.getStoreGoods(), StoreEvent.GOODS);
		StoreEvent foodSEvent = new StoreEvent(ModelData.getStoreFood(), StoreEvent.FOOD);
		StoreEvent maxGoodsSEvent = new StoreEvent(ModelData.getMaxGoods(), StoreEvent.MAX_GOODS);
		StoreEvent maxFoodSEvent = new StoreEvent(ModelData.getMaxFood(), StoreEvent.MAX_FOOD);
		
		CityScapePlay.getListeners().notifyStoreListeners(goodsSEvent);
		CityScapePlay.getListeners().notifyStoreListeners(foodSEvent);
		CityScapePlay.getListeners().notifyStoreListeners(maxGoodsSEvent);
		CityScapePlay.getListeners().notifyStoreListeners(maxFoodSEvent);
	}
}
