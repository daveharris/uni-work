/*
 * Created on Apr 4, 2005
 */
package nz.ac.vuw.mcs.comp301.controller;

import nz.ac.vuw.mcs.comp301.model.CityState;
import nz.ac.vuw.mcs.comp301.model.ModelData;

/**
 * Calculates the figures when goods are bought
 * @author harrisdavi3
 */
public class CommandBuyGoods extends Command {
	
	int _amount;
	
	/**
	 * Initalises the amount to the amount of goods wanting to be bought 
	 * @param amount The amount of goods wanting to be built
	 */
	public CommandBuyGoods(int amount) {
		this._amount = amount;
	}

	/**
	 * Calculates the various figures when buying goods
	 */
	public void execute() {
		ModelData.setStoreGoods(ModelData.getStoreGoods() + _amount);
		ModelData.setBalance(ModelData.getBalance() - _amount);
		CityState.update();
	}
}
