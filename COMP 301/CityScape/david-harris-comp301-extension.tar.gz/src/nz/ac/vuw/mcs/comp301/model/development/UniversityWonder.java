/*
 * Created on May 15, 2005
 */
package nz.ac.vuw.mcs.comp301.model.development;

/**
 * Holds the information and variables to do with universities.
 * It implements the wonder interface, which implements the development interface 
 * @author harrisdavi3
 */
public class UniversityWonder implements Wonder {
	
	private boolean _used;
	private String _name;
	
	private int _cost;
	private int _upkeep;
	private int _pollution;
	private int _socialWorth;
	private int _jobs;
	private int _research;
	
	/**
	 * Initalises the variables to the correct values
	 */
	public UniversityWonder() {
		_used = true;
		_name = "University";
		
		_cost = 250;
		_upkeep = 50;
		_pollution = 10;
		_socialWorth = 15;
		_jobs = 50;
		_research = 0;		
	}
	
	public String getName() {
		return _name;
	}
	public int getLevel() {
		return 1;
	}
	public int getCost(int level) {
		return _cost;
	}
	public int getUpkeep(int level) {
		return _upkeep;
	}
	public int getPollution(int level) {
		return _pollution;
	}
	public int getSocialWorth(int level) {
		return _socialWorth;
	}
	public int getJobs(int level) {
		return _jobs;
	}
	public int getResearch() {
		return _research;
	}
	/**
	 * Calculates the endturn effect of building an university wonder
	 * Creates a WonderEvent based on thses, and notifies the listeners
	 */
	public void endTurnEffect() {
		if(Math.random() <= 0.04) {
			DevelopmentFactory.upgrade();
		}
	}

	public void incrementCounter() {
	}
	
	public void advanceCounter() {
	}

	public String upgradeDevelopment() {
		return "University";
	}
	
	public String getClassification() {
		return "wonder";
	}
	
	public int getHighestLevel() {
		return 1;
	}
}
