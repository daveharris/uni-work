/*
 * Created on Apr 29, 2005
 */
package nz.ac.vuw.mcs.comp301.model.development;

import java.util.HashMap;
import java.util.Vector;

import nz.ac.vuw.mcs.comp301.controller.CityScapePlay;
import nz.ac.vuw.mcs.comp301.model.CityState;
import nz.ac.vuw.mcs.comp301.model.MarketState;
import nz.ac.vuw.mcs.comp301.model.ModelData;
import nz.ac.vuw.mcs.comp301.model.events.KnowledgeEvent;
import nz.ac.vuw.mcs.comp301.model.events.WonderEvent;
import nz.ac.vuw.mcs.comp301.model.events.WonderListener;

/**
 * Creates the actual developments and adds then to the hashmap
 * Deals with everything to do with developments being added to the map.
 * @author harrisdavi3
 */
public class DevelopmentFactory implements WonderListener {
	
	static Development _development = null;
	private static HashMap _developmentsMap = new HashMap();
	private static Vector knowledge = new Vector();
	static int level = 1;
	
	/**
	 * Works out what type of development is wanting to be built,
	 * and then checks if its in the hasmap, or needs to be upgraded
	 * and then notifies the listeners 
	 * @param developmentName The name of the new development being built
	 * @return Returns the new Development
	 */
	public static Development store(String developmentName) {
		if (developmentName.equals("empty")) {
			_development = new EmptyDevelopment();
			return _development;
		}
		
		//If development was not found in the map already, create a new one, and add to map
		if (!_developmentsMap.containsKey(developmentName)) {
			//System.out.println("development was not found in the map already, create a new one");
			if(developmentName.startsWith("factory")) {
				level = Integer.parseInt(developmentName.substring(developmentName.length()-1));
				_development = new IndustrialDevelopment(developmentName, level);
				_developmentsMap.put(developmentName, _development);
				return _development;
			}
			else if (developmentName.startsWith("farm")) {
				level = Integer.parseInt(developmentName.substring(developmentName.length()-1));
				_development = new AgriculturalDevelopment(developmentName, level);
				_developmentsMap.put(developmentName, _development);
				return _development;
			}
			else if (developmentName.startsWith("houses")) {
				level = Integer.parseInt(developmentName.substring(developmentName.length()-1));
				_development = new ResidentialDevelopment(developmentName, level);
				_developmentsMap.put(developmentName, _development);
				return _development;
			}
			else if (developmentName.startsWith("park")) {
				level = Integer.parseInt(developmentName.substring(developmentName.length()-1));
				_development = new RecreationalDevelopment(developmentName, level);
				_developmentsMap.put(developmentName, _development);
				return _development;
			}
			else if (developmentName.startsWith("townhall")) {
				level = Integer.parseInt(developmentName.substring(developmentName.length()-1));
				_development = new GovernmentDevelopment(developmentName, level);
				_developmentsMap.put(developmentName, _development);
				return _development;
			}
			else if(developmentName.equalsIgnoreCase("University")) {
				_development = new UniversityWonder();
				return _development;
			}
			else if(developmentName.equalsIgnoreCase("Parliament")) {
				_development = new ParliamentWonder();
				return _development;
			}
			else if(developmentName.equalsIgnoreCase("Stadium")) {
				_development = new StadiumWonder();
				return _development;
			}
			else if(developmentName.equalsIgnoreCase("Gardens")) {
				_development = new GardenWonder();
				return _development;
			}
			else if(developmentName.equalsIgnoreCase("Hospital")) {
				_development = new HospitalWonder();
				return _development;
			}
			else if(developmentName.equalsIgnoreCase("Apartments")) {
				_development = new ApartmentWonder();
				return _development;
			}
			return null;
		}
		
		//If development was found in the map already, retrieve and link to the current one.
		else {
			//System.out.println("development was in the map already");
			level = Integer.parseInt(developmentName.substring(developmentName.length()-1));
			_development = (Development) _developmentsMap.get(developmentName);
			//update(_development);
			return _development;			
		}
	}
	
	/**
	 * Updates the storeGoods, upkeep and jobs after the addition of the new development
	 * @param development The newly created development
	 */	
	public static void update(Development development) {
		ModelData.setStoreGoods((int) (ModelData.getStoreGoods() - (development.getCost(development.getLevel()))));
		MarketState.setGoods(MarketState.getGoods() - (development.getCost(development.getLevel())));
		ModelData.setUpkeep((int) (ModelData.getUpkeep() + (development.getUpkeep(development.getLevel()))));
		ModelData.setJobs((int) (ModelData.getJobs() + ((development.getJobs(development.getLevel())))));
		
		CityState.update();		
	}
	
	/**
	 * As this class implements WonderListener, it has to define the wonderOccurred method
	 * This method decides what action to take depending on the type of event passed
	 *  @param event The event that is created
	 */
	public void wonderOccurred(WonderEvent event) {
		int type = event.getType();
		if(type == 1) {
			ModelData.setBalance(ModelData.getBalance() + event.getAmount());
		}
		else if(type == 3) {
			ModelData.setPopulation(ModelData.getPopulation() + event.getAmount());
		}
		else if(type == 4) {
			ModelData.setLaw(ModelData.getLaw() + event.getAmount());
		}
	}
	
	/**
	 * Method used for the university endturn calculations.
	 * It is used to make the next highest developments of all types	 *
	 */
	public static void upgrade() {
		int highest = 1;
		String names[] = {"farm", "factory", "park", "townhall", "houses"};
		for (int i = 0; i < names.length; i++) {
			for(int j=1; j<6; j++) {
				Development newDev = null;
				newDev = (Development) _developmentsMap.get(names[i]+j);
				if(newDev == null) {
					newDev = (Development) _developmentsMap.get(names[i]+(j-1));
					newDev.advanceCounter();
					String newName = newDev.upgradeDevelopment();
					store(newName);
					KnowledgeEvent event = new KnowledgeEvent(newName, KnowledgeEvent.ADD);
					CityScapePlay.getListeners().notifyKnowledgeListeners(event);
					break;
				}
			}			
		}		
	}
	
	/**
	 * Checks to see if the name is currently in the map
	 * @param name The name of the knowledge to check
	 * @return True if the map does contain the name
	 */
	public static boolean containsKnowledge(String name) {
		return (_developmentsMap.containsKey(name));			
	}
}

