/*
This file is part of the SMSCS VUW Comp301 CityScape GUI library.

SMSCS VUW Comp301 CityScape GUI ibrary is free software; you can redistribute it
and/or modify it under the terms of version 2 of the GNU General Public License as
published by the Free Software Foundation.

The SMSCS VUW Comp301 CityScape GUI library is distributed in the hope that it will 
be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General
Public License for more details.

You should have received a copy of the GNU General Public License along with
SMSCS VUW Comp301 CityScape GUI library; if not, write to the Free Software Foundation,
Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
*/

package nz.ac.vuw.mcs.comp301.view.gui;

import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JComponent;
import javax.swing.border.EtchedBorder;

import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.image.BufferedImage;
import nz.ac.vuw.mcs.comp301.model.events.PopulationListener;
import nz.ac.vuw.mcs.comp301.model.events.PopulationEvent;


/**
 * <p>This view is responsible for showing the different aspects of the city's population.
 * The view uses a smiley face to convey the population's happiness (or lack thereof). This view implements
 * the PopulationListener interface so that it can be informed of any changes to the city's population.</p>
 * 
 * @version $Revision: 1.1 $
 * @author $Author: harrisdavi3 $, $Date: 2005/04/04 03:41:58 $
 * @see nz.ac.vuw.mcs.comp301.model.events.PopulationListener
 */
public class PopulationView extends JPanel implements PopulationListener {

	public final static long serialVersionUID = 1;
	
	public PopulationView() {
		super();
		GridBagLayout layout = new GridBagLayout();
		GridBagConstraints constraints = new GridBagConstraints();
		GUIUtilities utilities = GUIUtilities.getGUIUtilities();
		Color foreground = utilities.getColour("population");
		Color background = utilities.getColour("background");
		this.setBorder(new EtchedBorder(Color.black, Color.red));
		this.setBackground(background);
		this.setLayout(layout);
		
		utilities.createHeader(this, "Population", foreground);
		
		constraints.gridwidth = GridBagConstraints.REMAINDER;
		constraints.fill = GridBagConstraints.NONE;
		constraints.weighty = 1.0;
		constraints.weightx = 1.0;
		this._face = new FaceComponent();
		layout.setConstraints(this._face, constraints);
		this.add(this._face);
		
		this._people = utilities.createLabel(this, "People:", foreground);
		this._health = utilities.createLabel(this, "Health:", foreground);
		this._jobs = utilities.createLabel(this, "Jobs:", foreground);
		this._livingSpaces = utilities.createLabel(this, "Living Spaces:", foreground);
		this._happiness = utilities.createLabel(this, "Happiness:", foreground);
		this._enjoyment = utilities.createLabel(this, "Enjoyment:", foreground);
		this._law = utilities.createLabel(this, "Law:", foreground);
		
		this._face.drawFace(0);
		this.setVisible(true);
		return;
	}
	
	/**
	 * <p>
	 * Reacts to a change in a single aspect of population by updating the relevant field.
	 * In the case of a modification to the population's happiness, the smiley face is also 
	 * redrawn to have the correct facial impression. 
	 * </p>
	 * 
	 * @see nz.ac.vuw.mcs.comp301.model.events.PopulationListener#populationModified(nz.ac.vuw.mcs.comp301.model.events.PopulationEvent)
	 */
	public void populationModified(PopulationEvent event) {
		int eventType = event.getType();
		int newAmount = event.getAmount();
		switch (eventType) {
			case PopulationEvent.HAPPINESS:
				this._face.drawFace(newAmount);
				this._happiness.setText(Integer.toString(newAmount));
				break;
			case PopulationEvent.HEALTH:
				this._health.setText(Integer.toString(newAmount));
				break;
			case PopulationEvent.JOBS:
				this._jobs.setText(Integer.toString(newAmount));
				break;
			case PopulationEvent.LIVING_SPACE:
				this._livingSpaces.setText(Integer.toString(newAmount));
				break;
			case PopulationEvent.PEOPLE:
				this._people.setText(Integer.toString(newAmount));
				break;
			case PopulationEvent.LAW:
				this._law.setText(Integer.toString(newAmount));
				break;
			case PopulationEvent.ENJOYMENT:
				this._enjoyment.setText(Integer.toString(newAmount));
				break;
		}
		return;
	}
	
	private FaceComponent _face;
	private JLabel _people;
	private JLabel _jobs;
	private JLabel _livingSpaces;
	private JLabel _health;
	private JLabel _happiness;
	private JLabel _law;
	private JLabel _enjoyment;
	
}

class FaceComponent extends JComponent {

	public final static long serialVersionUID = 1;
	
	public FaceComponent() {
		this.setPreferredSize(new Dimension(100, 100));
		this._buffer = new BufferedImage(100, 100, BufferedImage.TYPE_INT_RGB);
		this.drawFace(-80);
		return;
	}
	
	/**
	 * <p>
	 * Draws a smiley face, with the smile (or frown) dependent on how happy the population is.
	 * Uses an arc, and determines how much of the circumference of the circle to use in drawing the 
	 * mouth by using the happiness figure to control the final angles of the mouth ends.
	 * </p>
	 * 
	 * @param happiness The degree of happiness that the city's population has. Should be between -90 and 90.
	 */
	public void drawFace(int happiness) {
		int width = this.getWidth();
		int height = this.getHeight();
		int angle = Math.min(80, Math.abs(happiness));
		Graphics2D graphics = (Graphics2D)this._buffer.getGraphics();
		graphics.setColor(GUIUtilities.getGUIUtilities().getColour("background"));
		graphics.fillRect(0, 0, width, height);
		graphics.setColor(Color.yellow);
		graphics.fillOval(0, 0, width, height);
		graphics.setColor(Color.black);
		graphics.fillOval((int)(width * 0.25), (int)(height * 0.25), (int)(width * 0.1), (int)(width * 0.1));
		graphics.fillOval((int)(width * 0.65), (int)(height * 0.25), (int)(width * 0.1), (int)(width * 0.1));
		int dy = 0;
		double hypothenus = Math.abs(((width * 0.35) / Math.sin(Math.toRadians(angle))));
		double diameter = (hypothenus) * 2;
		int endDegrees = 0 - (angle * 2);
		if (happiness < 0) {
			int startDegrees = 90 - angle;
			graphics.drawArc((int)((width / 2) - hypothenus), (int)(height * 0.8), (int)diameter, (int)diameter, startDegrees, 0 - endDegrees);
		} else if (happiness > 0) {
			int startDegrees = 270 + angle;
			graphics.drawArc((int)((width / 2) - hypothenus), (int)((height * 0.8) - diameter), (int)diameter, (int)diameter, startDegrees, endDegrees);	
		} else if (happiness == 0) {
			graphics.drawLine((int)(width * 0.25), (int)(height * 0.8), (int)(width * 0.75), (int)(height * 0.8));
		}
		this.repaint();
		return;
	}
		
	public void paint(Graphics graphics) {
		int width = this.getWidth();
		int height = this.getHeight();
		graphics.drawImage(this._buffer, 0, 0, width, height, null) ;
		return;
	}
	
	private Image _buffer;
	
}
