/*
 * Created on Apr 4, 2005
 */
package nz.ac.vuw.mcs.comp301.controller;

/**
 * Class not needed, but kept for consistency
 * @author harrisdavi3
 * @see  nz.ac.vuw.mcs.comp301.view.gui.GUIController
 */
public class CommandExit extends Command {
	
	public CommandExit() {
		
	}

	public void execute() {

	}	
}
