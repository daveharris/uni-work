/*
This file is part of the SMSCS VUW Comp301 CityScape GUI library.

SMSCS VUW Comp301 CityScape GUI ibrary is free software; you can redistribute it
and/or modify it under the terms of version 2 of the GNU General Public License as
published by the Free Software Foundation.

The SMSCS VUW Comp301 CityScape GUI library is distributed in the hope that it will 
be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General
Public License for more details.

You should have received a copy of the GNU General Public License along with
SMSCS VUW Comp301 CityScape GUI library; if not, write to the Free Software Foundation,
Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
*/

package nz.ac.vuw.mcs.comp301.model.events;

import nz.ac.vuw.mcs.comp301.model.development.Development;
import java.io.Serializable;

/**
 * <p>An object representing the addition or removal of a single development instance
 * from the map.</p>
 *
 * @version $Revision: 1.1 $
 * @author $Author: harrisdavi3 $, $Date: 2005/04/04 03:41:58 $
 * @see nz.ac.vuw.mcs.comp301.view.gui.MapView
 * @see nz.ac.vuw.mcs.comp301.model.events.DevelopmentListener
 * 
 */
public class DevelopmentEvent implements Serializable {

	public final static long serialVersionUID = 1;
	
	public final static int ADDED = 1;
	public final static int REMOVED = 2;
	
	public DevelopmentEvent(Development development, int x, int y, int type) {
		this._development = development;
		this._x = x;
		this._y = y;
		this._type = type;
		return;
	}
	
	public int getXLocation() {
		return this._x;
	}
	
	public int getYLocation() {
		return this._y;
	}
	
	public Development getDevelopment() {
		return this._development;
	}
	
	public int getType() {
		return this._type;
	}
	
	private int _type;
	private int _x;
	private int _y;
	private Development _development;
	
}
