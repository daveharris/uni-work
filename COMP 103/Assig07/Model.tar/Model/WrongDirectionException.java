public class WrongDirectionException extends Exception {
    public WrongDirectionException(String msg) {
	System.out.println(msg);
    }
}
