import java.awt.Color;

/** This class has been created for use with the first part of assignment 07
    it allows one to represent the different types of actions that may be 
    performed in the MiniDraw program. It should be noted that the fields 
    are public which allows them to be accessed by a program using the class */
public class Action {
    /** The position of the shape which the action is being performed on
       in the shapes Vector */
    public int pos;
    /** The shape which the action is being performed on */
    public Shape shape;
    /** The action type, this is a string describing the type of action. i.e.
       "Move", "Delete", "Line", etc. */
    public String actionType;

    /** This field only applies to the move action, it holds the difference in
       the x coordinate. i.e. newx - lastx. */
    public int mvx;
    /** This field only applies to the move action, it holds the difference in
    the y coordinate. i.e. newy - lasty. */
    public int mvy;

    /** This field only applies to the color changing action. It holds the 
    value of the previous colour */
    public Color col;

    /** This constructor may be used for constructing <tt>Action</tt> objects 
	corresponding to the action of creating a new shape "Oval", "Rect",
	"Line", "PolyLine" or "Text". It may also be used for "Delete" actions.
	The first argument is the position in the shape Vector, the second 
	argument is the shape, and the third is a describing string (as given 
	in the earlier sentence). */
    public Action(int p,Shape s,String at) {
	pos = p;shape = s;actionType = at;
    }

    /** This constructor may be used for constructing <tt>Action</tt> objects 
	corresponding to the "Move" action. The first argument is the position
	in the shape Vector, the second argument is the shape, the third is a 
	describing string viz. "Move", and the last two arguments should be the
	change in x and y positions (in that order) */
    public Action(int p,Shape s,String at,int x,int y) {
	pos = p;shape = s;actionType = at;mvx = x;mvy = y;
    }

    /** This constructor may be used for constructing <tt>Action</tt> objects 
	corresponding to the action of changing the colour. The first argument 
	should be the previous colour, the second should be a describing string
	viz. "Colour" */
    public Action(Color c,String at) {
	col = c;actionType = at;
    }
}
