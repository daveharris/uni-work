Due to problems with the synch.o given to us, I started using my own
synch.cc and synch.h from project 1.  

Thus, I have submitted my synch.cc and synch.h.  So, please use my
synch.cc and synch.h instead of the pre-compiled synch.o.

However, in order for program to compile and work properly,
a * make clean * must be done first.

David Harris
300069566
