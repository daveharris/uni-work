#include "copyright.h"
#include "addrspace.h"

void StartProcess(char *filename);
