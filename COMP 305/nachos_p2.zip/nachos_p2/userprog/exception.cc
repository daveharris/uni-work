// exception.cc 
//	Entry point into the Nachos kernel from user programs.
//	There are two kinds of things that can cause control to
//	transfer back to here from user code:
//
//	syscall -- The user code explicitly requests to call a procedure
//	in the Nachos kernel.  Right now, the only function we support is
//	"Halt".
//
//	exceptions -- The user code does something that the CPU can't handle.
//	For instance, accessing memory that doesn't exist, arithmetic errors,
//	etc.  
//
//	Interrupts (which can also cause control to transfer from user
//	code into the Nachos kernel) are handled elsewhere.
//
// For now, this only handles the Halt() system call.
// Everything else core dumps.
//
// Copyright (c) 1992-1993 The Regents of the University of California.
// All rights reserved.  See copyright.h for copyright notice and limitation 
// of liability and disclaimer of warranty provisions.

//TODO: * make read/write generic as possible
//      * look at optimising halt method

#include "copyright.h"
#include "system.h"
#include "syscall.h"

#ifdef CHANGED
void HaltSyscall();
void ExitSyscall();
void ReadSyscall();
void WriteSyscall();
void ForkSyscall();
void YieldSyscall();
void updatePC();
void forkPC(int);

#define arg1 4
#define arg2 5
#define arg3 6
#define arg4 7
#endif

//----------------------------------------------------------------------
// The InitExceptions function is used to initialize various useful things
//----------------------------------------------------------------------

void
InitExceptions() {
  ;
}


//----------------------------------------------------------------------
// ExceptionHandler
// 	Entry point into the Nachos kernel.  Called when a user program
//	is executing, and either does a syscall, or generates an addressing
//	or arithmetic exception.
//
// 	For system calls, the following is the calling convention:
//
// 	system call code -- r2
//		arg1 -- r4
//		arg2 -- r5
//		arg3 -- r6
//		arg4 -- r7
//
//	The result of the system call, if any, must be put back into r2. 
//
// And don't forget to increment the pc before returning. (Or else you'll
// loop making the same system call forever!
//
//	"which" is the kind of exception.  The list of possible exceptions 
//	are in machine.h.
//----------------------------------------------------------------------

#ifdef CHANGED

void ExceptionHandler(ExceptionType which) {
  updatePC();
  int type = machine->ReadRegister(2);
  if (which == SyscallException) {
    switch (type) {
      case SC_Halt:
        DEBUG('a', "Shutdown, initiated by user program.\n");
        HaltSyscall();
        break;
      case SC_Exit:
        DEBUG('a', "Exit, initiated by user program.\n");
        ExitSyscall();
        break;
      case SC_Read:
        DEBUG('a', "Read, initiated by user program.\n");
        ReadSyscall();
        break;
      case SC_Write:
        DEBUG('a', "Write, initiated by user program.\n");
        WriteSyscall();
        break;
     case SC_Fork:
        DEBUG('a', "Fork, initiated by user program.\n");
        ForkSyscall();
        break;
    case SC_Yield:
        DEBUG('a', "Yield, initiated by user program.\n");
        YieldSyscall();
        break;
      default:
        DEBUG('a', "\nUnexpected user mode exception %d %d\n", which, type);
        ASSERT(FALSE);
        break;
    }
  }
}

void HaltSyscall() {
  interrupt->Halt();
}

//----------------------------------------------------------------------
// ExitSyscall
//  If this is the last thread, then call halt
//  else finish the current thread and update thread counter etc
//----------------------------------------------------------------------
void ExitSyscall() {
  if(currentThread->space->GetThreadCount() == 1) {
    // Clean up any data structures
    delete currentThread->space;
    interrupt->Halt();
  }
  else {
    currentThread->space->UpdateCollection('-', currentThread);
    currentThread->Finish();    
  }
}

//----------------------------------------------------------------------
// ReadSyscall
//  Read in 'size' characters from the console into the buffer 
//----------------------------------------------------------------------
void ReadSyscall() {
  char* buffer = (char*) &machine->mainMemory[machine->ReadRegister(arg1)];
  int size = machine->ReadRegister(arg2);
  if(size > 0)
    SConsole->ReadLine(buffer, size);
  else
    DEBUG('a', "Size incorrect\n");
}

//----------------------------------------------------------------------
// WriteSyscall
//  Write 'size' characters from the buffer to the console
//----------------------------------------------------------------------
void WriteSyscall() {  
  char* buffer = (char*) &machine->mainMemory[machine->ReadRegister(arg1)];
  int size = machine->ReadRegister(arg2);
  //Make sure that the buffer is what we expect and that size is correct
  if(size > 0 && strlen(buffer) == size)
    SConsole->WriteLine(buffer, size);
  else
    DEBUG('a', "Size or buffer length incorrect\n");
}

//----------------------------------------------------------------------
// ForkSyscall
//  Fork a new thread with a random name, set stack and update the 'pcb' 
//----------------------------------------------------------------------
void ForkSyscall() {
  if(currentThread->space->EnsureSpace()) {
    double rand_num = Random();
    char* name;
    asprintf(&name, "Thread_%d", rand_num); 
    Thread* thread = new Thread(name);
    // Set the address space to the address space of the current thread
    thread->space = currentThread->space;
    thread->space->UpdateCollection('+', thread);
    thread->Fork(forkPC, machine->ReadRegister(arg1));
  }
}

void YieldSyscall() {
  currentThread->Yield();
}

//----------------------------------------------------------------------
// updatePC
//  Set the PrevPCReg, PCReg and NextPCReg 
//----------------------------------------------------------------------
void updatePC() {
  machine->WriteRegister(PrevPCReg, machine->ReadRegister(PCReg));
  machine->WriteRegister(PCReg, machine->ReadRegister(NextPCReg));
  machine->WriteRegister(NextPCReg, machine->ReadRegister(NextPCReg) + 4);  
}

//----------------------------------------------------------------------
// forkPC
//  Called when forking a new thread
//  Sets the PCReg and NextPCReg to the address of the user program and
//  sets the stack register
//----------------------------------------------------------------------
void forkPC(int userAddr) {  
  machine->WriteRegister(PCReg, userAddr);
  machine->WriteRegister(NextPCReg, (userAddr + 4));
  machine->WriteRegister(StackReg, currentThread->space->GetStackTop(
      currentThread->space->GetThreadCount()));
  machine->Run();
}

#endif
