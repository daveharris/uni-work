find . -exec cvs diff -r 1.1 {} \; 2>&1 | grep 'Index' | grep -v 'cvs diff' | sed 's/Index:\ //' | sed -e 's/^\.\///' | sort | uniq | grep -v coff | grep -v cvsignore | grep -v test
