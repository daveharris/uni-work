/* catfile.c
 *	Program to print a file on the console.
 */

#include "syscall.h"
#define BUFSIZE 100
int
main()
{
  OpenFileId fid;
  OpenFileId fid2;
  OpenFileId fid3;
  
  char buffer[BUFSIZE];
  int n;
  char buffer2[BUFSIZE];
  int n2;
  char buffer3[BUFSIZE];
  int n3;
  
  fid = Open("filesys/test/large");
  fid2 = Open("filesys/test/small");
  //fid3 = Open("filesys/test/small");
  
  Write("\nfid1\n", 6, ConsoleOutput);

  while ((n = Read(buffer, BUFSIZE, fid)) > 0) {
    Write(buffer, n, ConsoleOutput);
  }

  Write("\nfid2\n", 6, ConsoleOutput);
  
  while ((n2 = Read(buffer2, BUFSIZE, fid2)) > 0) {
    Write(buffer2, n2, ConsoleOutput);
  }
  
  /*Write("\nfid3\n", 6, ConsoleOutput);

  while ((n3 = Read(buffer3, BUFSIZE, fid3)) > 0) {
    Write(buffer3, n3, ConsoleOutput);
  }*/
  
  Close(fid);
  Close(fid2);
  //Close(fid3);
  Halt();
  /* not reached */
}
