/* forktest.c
 *	Simple program to see if we can fork a user thread.
 */

/*#include "syscall.h"

void secondThread() {
  Write("Goodbye World\n", 14, ConsoleOutput);
  Yield();
  Exit(0);
}

int
main()
{
  Fork(&secondThread);
  Write("Hello World\n", 12, ConsoleOutput);
  Yield();
  Write("Hello World\n", 12, ConsoleOutput);
  Exit(0);

}*/

 /* forktest.c
 * Simple program to see if our user-thread stacks really are implemented correctly
 */

#include "syscall.h"
 
// Returns x to the power of n, recursively
int power(int x, int n)
{
 Yield(); // Don't remove this
 if (n == 1)
  return x;
 else
  return x * power(x,n-1);
}
 
void secondThread()  
{
  int x;
  x = power(3,4); // Should be 81
  if (x==81)
   Write("Thread2 answer correct\n", 23, ConsoleOutput);
  else
   Write("Thread2 answer wrong!\n", 22, ConsoleOutput);  
  Exit(0);
}

/*void thirdThread()  
{
  int x;
  x = power(5,3); // Should be 81
  if (x==125)
   Write("Thread3 answer correct\n", 23, ConsoleOutput);
  else
   Write("Thread3 answer wrong!\n", 22, ConsoleOutput);  
  Exit(0);
}*/
 
int
main()
{
  int x;  
  Fork(&secondThread);
  //Fork(&thirdThread);
  x = power(2,10); // should be 1024
  if (x = 1024)
   Write("Thread1 answer correct\n", 23, ConsoleOutput);
  else
   Write("Thread1 answer wrong!\n", 22, ConsoleOutput);  
  Exit(0);
  // not reached
} 

