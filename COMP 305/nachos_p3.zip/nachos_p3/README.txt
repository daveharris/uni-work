I have included the files that I modified for project 2 as well as for project 
3 so that project 3 compiles.  Therefore i have included my implentation of 
synch.cc and synch.h.  After the debacle over the provided synch.o, I have just
always kept my implementation and so ahve submitted it now.

David Harris
300069566
