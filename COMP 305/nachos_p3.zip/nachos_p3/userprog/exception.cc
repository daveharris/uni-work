// exception.cc 
//	Entry point into the Nachos kernel from user programs.
//	There are two kinds of things that can cause control to
//	transfer back to here from user code:
//
//	syscall -- The user code explicitly requests to call a procedure
//	in the Nachos kernel.  Right now, the only function we support is
//	"Halt".
//
//	exceptions -- The user code does something that the CPU can't handle.
//	For instance, accessing memory that doesn't exist, arithmetic errors,
//	etc.  
//
//	Interrupts (which can also cause control to transfer from user
//	code into the Nachos kernel) are handled elsewhere.
//
// For now, this only handles the Halt() system call.
// Everything else core dumps.
//
// Copyright (c) 1992-1993 The Regents of the University of California.
// All rights reserved.  See copyright.h for copyright notice and limitation 
// of liability and disclaimer of warranty provisions.

#include "copyright.h"
#include "system.h"
#include "syscall.h"
#include "filesys.h"

#ifdef CHANGED
#include <string>
#endif

void HaltSyscall();
void ExitSyscall();
void OpenSyscall();
void CloseSyscall();
void CreateSyscall();
void ReadSyscall();
void WriteSyscall();
void ForkSyscall();
void YieldSyscall();
void UpdatePC();
void ForkPC(int);

#define arg1 4
#define arg2 5
#define arg3 6
#define arg4 7

//----------------------------------------------------------------------
// The InitExceptions function is used to initialize various useful things
//----------------------------------------------------------------------

void
InitExceptions() {
  ;
}


//----------------------------------------------------------------------
// ExceptionHandler
// 	Entry point into the Nachos kernel.  Called when a user program
//	is executing, and either does a syscall, or generates an addressing
//	or arithmetic exception.
//
// 	For system calls, the following is the calling convention:
//
// 	system call code -- r2
//		arg1 -- r4
//		arg2 -- r5
//		arg3 -- r6
//		arg4 -- r7
//
//	The result of the system call, if any, must be put back into r2. 
//
// And don't forget to increment the pc before returning. (Or else you'll
// loop making the same system call forever!
//
//	"which" is the kind of exception.  The list of possible exceptions 
//	are in machine.h.
//----------------------------------------------------------------------
void ExceptionHandler(ExceptionType which) {
  UpdatePC();
  int type = machine->ReadRegister(2);
  if (which == SyscallException) {
    switch (type) {
      case SC_Halt:
        DEBUG('a', "Shutdown, initiated by user program.\n");
        HaltSyscall();
        break;
      case SC_Exit:
        DEBUG('a', "Exit, initiated by user program.\n");
        ExitSyscall();
        break;
      #ifdef CHANGED
      case SC_Create:
        DEBUG('a', "Create, initiated by user program.\n");
        CreateSyscall();
        break;
      case SC_Open:
        DEBUG('a', "Open, initiated by user program.\n");
        OpenSyscall();
        break;
      case SC_Close:
        DEBUG('a', "Close, initiated by user program.\n");
        CloseSyscall();
        break;
      case SC_Read:
        DEBUG('a', "Read, initiated by user program.\n");
        ReadSyscall();
        break;
      case SC_Write:
        DEBUG('a', "Write, initiated by user program.\n");
        WriteSyscall();
        break;
      #endif
      case SC_Fork:
        DEBUG('a', "Fork, initiated by user program.\n");
        ForkSyscall();
        break;
      case SC_Yield:
        DEBUG('a', "Yield, initiated by user program.\n");
        YieldSyscall();
        break;
      default:
        DEBUG('a', "\nUnexpected user mode exception %d %d\n", which, type);
        ASSERT(FALSE);
        break;
    }
  }
}

void HaltSyscall() {
  interrupt->Halt();
}


//----------------------------------------------------------------------
// ExitSyscall
//  If this is the last thread, then call halt
//  else finish the current thread and update thread counter etc
//----------------------------------------------------------------------
void ExitSyscall() {
  if(currentThread->space->GetThreadCount() == 1) {
    // Clean up any data structures
    delete currentThread->space;
    interrupt->Halt();
  }
  else {
    currentThread->space->UpdatePCB('-', currentThread);
    currentThread->Finish();    
  }
  printf("In ExitSyscall()\n");
}


//----------------------------------------------------------------------
// CreateSyscall
//  Create a new file 
//----------------------------------------------------------------------
void CreateSyscall() {
  string name = "";
  int count = 0;
  int c = 1;
  while((char) c != '\0') {
    machine->ReadMem(machine->ReadRegister(arg1) + count, 1, &c);
    name += (char) c;
    count++;
  }
  fileSystem->Create((char*) name.c_str(), 0);
}


#ifdef CHANGED
//----------------------------------------------------------------------
// OpenSyscall
//  Open the file for reading/writing
//----------------------------------------------------------------------
void OpenSyscall() {
  string name = "";
  int count = 0;
  int c = 1;
  while((char) c != '\0') {
    //Use ReadMem to read the memory across page boundaries, one byte
    //at a time, checking each one for null.
    machine->ReadMem(machine->ReadRegister(arg1) + count, 1, &c);
    name += (char) c;
    count++;
  }

  OpenFile* file = fileSystem->Open((char*) name.c_str());
  //Check to see if the file is found
  if(file == NULL) {
    //Then the file is not found
    printf("File '%s' not found!!!\n", name.c_str());
    machine->WriteRegister(2, -1);
  }
  else {
    //Add the file to the filetable and find the id
    currentThread->space->fileTable->UpdateFileTable('+', file);
    OpenFileId id = currentThread->space->fileTable->GetFileId(file);
    
    machine->WriteRegister(2, id);
  }
}


//----------------------------------------------------------------------
// CloseSyscall
//  Close the file when finished
//----------------------------------------------------------------------
void CloseSyscall() {
  int id = machine->ReadRegister(arg1);
  
  //Check to see if the file is found
  if(id == -1) {
    //File does not exist
    machine->WriteRegister(2, 0);
    return;
  }
  
  //Find the id, then remove it from the filetable
  OpenFile* file = currentThread->space->fileTable->GetFile(id);
  currentThread->space->fileTable->UpdateFileTable('-', file);
}


//----------------------------------------------------------------------
// ReadSyscall
//  Read in 'size' characters from the console into the buffer 
//----------------------------------------------------------------------
void ReadSyscall() {
  int size = machine->ReadRegister(arg2);
  OpenFileId id = machine->ReadRegister(arg3);
  
  //Check to see if file exists
  if(id == -1) {
    //File does not exist
    machine->WriteRegister(2, 0);
    return;
  }
  
  //Create space for the data that's going to be read
  char* buffer = new char[size+1];
  buffer[size]='\0';
  
  if(id == ConsoleInput || id == ConsoleOutput) {
    if(size > 0) {
      SConsole->ReadLine(buffer, size);
    }
    else
      DEBUG('a', "Size incorrect\n");
  }
  else {
    //Find the fileid and call the Read method to actually write the file
    OpenFile* file = currentThread->space->fileTable->GetFile(id);
    int numBytesRead = file->Read(buffer, size);
    machine->WriteRegister(2, numBytesRead);
  }
  
  //Use memWrite to write data, in paged memory
  currentThread->space->memWrite(buffer, machine->ReadRegister(arg1), size);
  
  //Cleanup
  delete buffer;
}

//----------------------------------------------------------------------
// WriteSyscall
//  Write 'size' characters to the buffer to the console/file
//----------------------------------------------------------------------
void WriteSyscall() {  
  int size = machine->ReadRegister(arg2);
  OpenFileId id = machine->ReadRegister(arg3);
 
  //Check to see if file exists
  if(id == -1) {
    //File does not exist
    machine->WriteRegister(2, 0);
    return;
  }
  
  //Create space for the data that's going to be read
  char* buffer = new char[size+1];
  buffer[size]='\0';

  //Call memRead to read the contents of the file in paged memory
  currentThread->space->memRead(buffer, machine->ReadRegister(arg1), size);

  if(id == ConsoleInput || id == ConsoleOutput) {
    //Make sure that the buffer is what we expect and that size is correct
    if(size > 0 && strlen(buffer) == size) {
      SConsole->WriteLine(buffer, size);
    }
    else
      DEBUG('a', "Size or buffer length incorrect\n");
  }
  else {
    //Find the fileid and write the data to the file
    OpenFile* file = currentThread->space->fileTable->GetFile(id);
    file->Write(buffer, size);
  }
  //Cleanup
  delete buffer;
}
#endif

//----------------------------------------------------------------------
// ForkSyscall
//  Fork a new thread with a random name, set stack and update the 'pcb' 
//----------------------------------------------------------------------
void ForkSyscall() {
  if(currentThread->space->EnsureSpace()) {
    double rand_num = Random();
    char* name;
    asprintf(&name, "Thread_%d", rand_num); 
    Thread* thread = new Thread(name);
    // Set the address space to the address space of the current thread
    thread->space = currentThread->space;
    thread->space->UpdatePCB('+', thread);
    thread->Fork(ForkPC, machine->ReadRegister(arg1));
  }
}

void YieldSyscall() {
  currentThread->Yield();
}

//----------------------------------------------------------------------
// UpdatePC
//  Set the PrevPCReg, PCReg and NextPCReg 
//----------------------------------------------------------------------
void UpdatePC() {
  machine->WriteRegister(PrevPCReg, machine->ReadRegister(PCReg));
  machine->WriteRegister(PCReg, machine->ReadRegister(NextPCReg));
  machine->WriteRegister(NextPCReg, machine->ReadRegister(NextPCReg) + 4);  
}

//----------------------------------------------------------------------
// ForkPC
//  Called when forking a new thread
//  Sets the PCReg and NextPCReg to the address of the user program and
//  sets the stack register
//----------------------------------------------------------------------
void ForkPC(int userAddr) {  
  machine->WriteRegister(PCReg, userAddr);
  machine->WriteRegister(NextPCReg, (userAddr + 4));
  machine->WriteRegister(StackReg, currentThread->space->GetStackTop(
      currentThread->space->GetThreadCount()));
  machine->Run();
}
