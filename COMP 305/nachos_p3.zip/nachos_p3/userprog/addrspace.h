// addrspace.h 
//	Data structures to keep track of executing user programs 
//	(address spaces).
//
//	For now, we don't keep any information about address spaces.
//	The user level CPU state is saved and restored in the thread
//	executing the user program (see thread.h).
//
// Copyright (c) 1992-1993 The Regents of the University of California.
// All rights reserved.  See copyright.h for copyright notice and limitation 
// of liability and disclaimer of warranty provisions.

#ifndef ADDRSPACE_H
#define ADDRSPACE_H

#include "copyright.h"
#include "filesys.h"
#include "translate.h"

#include "thread.h"
#include "syscall.h"

#ifdef CHANGED
#include <map>
using namespace std;
#endif

// Each thread has this much stack space
#define ThreadStackSize  256

// Each process has this much stack space
#define UserStackSize		1024

#ifdef CHANGED
// The number of active files
#define MaxFileNum 16

#define OFFSET 2

// Needed for forward declaration
class FileTable;
#endif
class Thread;

class AddrSpace {
  public:
    #ifdef CHANGED
    FileTable* fileTable;
    #endif
  
    AddrSpace(OpenFile *executable);	// Create an address space,
					// initializing it with the program
					// stored in the file "executable"
    ~AddrSpace();			// De-allocate an address space

    void InitRegisters();		// Initialize user-level CPU registers,
					// before jumping to user code

    void SaveState();			// Save/restore address space-specific

    void RestoreState();		// info on a context switch 
    // Add/remove thread from array
    void UpdatePCB(char operand, Thread* thread);  
    // Return number of active threads
    int GetThreadCount(){ return (threadCount); }
    // Return the top of a newly-forked thread's stack
    int GetStackTop(int threadNum); 
    // Ensure that we don't run out of space
    bool EnsureSpace();
    
    #ifdef CHANGED
    void memRead(char* buffer, int virtAddr, int size);
    void memWrite(char* buffer, int virtAddr, int size);
    #endif    

  private:
    TranslationEntry *pageTable;	// Assume linear page table translation
					// for now!
    unsigned int numPages;		// Number of pages in the virtual 
					// address space
    int threadCount;     // Number of active threads 
    Thread* threads[UserStackSize/ThreadStackSize];
    
    #ifdef CHANGED
    // CHANGED BY IAN TO ADD LOADING
    int LoadProg(int, int, OpenFile*, int);
    // END CHANGED BY IAN TO ADD LOADING

};


class FileTable {
  public:
    FileTable() {fileCount = 0;}
    ~FileTable() { fileTable.clear(); }
    // Add/remove files from filetable
    void UpdateFileTable(char operand, OpenFile* file);
    OpenFile* GetFile(OpenFileId id);
    OpenFileId GetFileId(OpenFile* file);
  private:
    int fileCount;   //Number of open files
    // Array of active threads
    //  OpenFile* fileTable[MaxFileNum];
    map<OpenFileId, OpenFile*> fileTable;  
};
    #endif

#endif // ADDRSPACE_H
