#include <iostream>
#include <fstream>

#include "book.h"
#include "bucket.h"
#include "mapfile.h"

using namespace std;

void displayMenu();
void readFromFile(char* filename);
void leave(int quit = 0);

Mapfile* mapfile;

int main() {

  char command;
  int resultok;

  displayMenu();

  while(1) {

    cin >> command;
    cin.ignore();
    cin.clear();
    command = tolower(command);

    if(command == 'e') {
      leave();
    }
    
    else if(command == 'n') {
      int numBuckets;
      cout << "Enter the number of buckets you wish to have:" << endl;
      cin >> numBuckets;
      cin.ignore();
      cin.clear();
      mapfile = new Mapfile(numBuckets);
    }

    else if(command == 'c') {
      Book book;
      mapfile->insert(book);
    }

    else if(command == 'f') {
      char bookId[7];
      cout << "Enter a book id to find" << endl;
      cin >> bookId;
      cin.ignore();
      cin.clear();
      bookId[6] = '\0';
      Book *foundBook;
      mapfile->retrieve(foundBook, bookId);
      //Call the print method
    }

    else if(command == 'd') {
      break;
    }

    else if(command == 's') {
      break;
    }
 
    else if(command == 'l') {
      resultok = mapfile->openFile("file.dat");
      if (resultok) 
	cout << "File opened ok.\n";
      else {
	cout << "Unable to open file!\n";
	leave(1);
      }     
    }
      
    else if(command == 'r') {
      char filename[256];
      cout << "Enter the filename to read from" << endl;
      cin >> filename;
      readFromFile(filename);
      displayMenu();
    }

    else
      displayMenu();
  }
}

void displayMenu() {

  cout <<"\n----------------------------------------------------" << endl;
  cout << "Welcome to the Victoria University Library System" << endl;
  cout << "                 By David Harris" << endl;
  cout <<"----------------------------------------------------" << endl;
  cout << "Please choose from the below options:" << endl;
  cout << "-------------------------------------" << endl;
  cout << "(N)ew mapfile" << endl;
  cout << "(C)reate new book" << endl;
  cout << "(F)ind a book" << endl;
  cout << "(D)elete a book" << endl;
  cout << "(S)ave to file" << endl;
  cout << "(L)oad from binary file" << endl;
  cout << "(R)ead from text file" << endl;
  cout << "(E)xit to system" << endl;
  cout << "-------------------------------------" << endl;
  cout << "Choose (slrfcde):  ";

}


void readFromFile(char* filename) {

  char id[7], title[30], author[12], callcode[12];
  char buffer[256];
  ifstream inputFile;
  inputFile.open(filename);
  if(!inputFile) {
    cout << "\""<< filename << "\"" << " was not found" << endl;
    return;
  }
  if(inputFile.fail()) {
    cout << "Unable to open " << filename << endl;
    return;
  }
  
  cout << "File Reading in progress..." << endl;
  while(inputFile.good()) {

    inputFile.get(buffer, 7);
    strcpy(id, buffer);
    id[7] = '\0';

    inputFile.get(buffer, 31);
    strcpy(title, buffer);
    title[31] = '\0';

    inputFile.get(buffer, 13);
    strcpy(author, buffer);
    author[13] = '\0';

    inputFile.get(buffer, 255);
    strcpy(callcode, buffer);
    callcode[13] = '\0';

    Book book(id, title, author, callcode);
    mapfile->insert(book);

    inputFile.getline(buffer, 256);
  }

  cout << "\""<< filename << "\"" << " was successfully read in" << endl;
  inputFile.close();
}

void leave(int quit) {
  delete mapfile;
  exit(quit);
}
